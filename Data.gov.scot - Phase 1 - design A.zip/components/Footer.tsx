import svgPaths from "../imports/svg-tmym2azjca";

export function Footer() {
  return (
    <footer className="sg-footer">
      <div className="sg-footer-container">
        {/* Footer links */}
        <div className="sg-footer-links">
          <a href="/privacy" className="sg-footer-link">Privacy</a>
          <a href="/accessibility" className="sg-footer-link">Accessibility statement</a>
          <a href="#/contact" className="sg-footer-link">Contact</a>
          <a href="#/help" className="sg-footer-link">How to use this site</a>
        </div>

        {/* Footer content */}
        <div className="sg-footer-content">
          <div className="flex items-center gap-4">
            <a
              href="https://www.nationalarchives.gov.uk/doc/open-government-licence/version/3/"
              className="flex items-center gap-2 cursor-pointer"
            >
              <div className="w-8 h-3 relative">
                <svg
                  className="block w-full h-full"
                  fill="none"
                  preserveAspectRatio="none"
                  viewBox="0 0 32 13"
                >
                  <g clipPath="url(#clip0_1_243)">
                    <path
                      d={svgPaths.p1e54e5f0}
                      fill="#333333"
                    />
                    <path
                      d={svgPaths.p3e4bb300}
                      fill="#333333"
                    />
                  </g>
                  <defs>
                    <clipPath id="clip0_1_243">
                      <rect fill="white" height="12.9587" width="32" />
                    </clipPath>
                  </defs>
                </svg>
              </div>
            </a>
            <span className="sg-footer-text">
              All content is available under the{" "}
              <a
                href="https://www.nationalarchives.gov.uk/doc/open-government-licence/version/3/"
                className="sg-footer-link"
              >
                Open Government Licence v3.0
              </a>
              , except for graphic assets and where otherwise stated
            </span>
          </div>

          <a href="https://www.gov.scot/" className="flex items-center cursor-pointer">
            <div className="w-40 h-8 relative">
              <svg
                className="block w-full h-full"
                fill="none"
                preserveAspectRatio="none"
                viewBox="0 0 160 31"
              >
                <g clipPath="url(#clip0_1_235)">
                  <path
                    d={svgPaths.p2a6a7000}
                    fill="#333E48"
                  />
                  <path
                    d={svgPaths.p19ce0400}
                    fill="white"
                  />
                  <path
                    d={svgPaths.pa664b00}
                    fill="#0065BD"
                  />
                </g>
                <defs>
                  <clipPath id="clip0_1_235">
                    <rect fill="white" height="30.3939" width="160" />
                  </clipPath>
                </defs>
              </svg>
            </div>
          </a>
        </div>

        {/* Additional footer info - compressed spacing */}
        <div className="mt-4 pt-4 border-t border-gray-300">
          <div className="flex items-center justify-between flex-wrap gap-4">
            <div>
              <span className="sg-footer-powered">Powered by </span>
              <a href="https://github.com/ckan/ckan" className="sg-footer-link font-bold">
                CKAN
              </a>
            </div>
            <span className="sg-footer-text">© Crown Copyright</span>
          </div>
        </div>
      </div>
    </footer>
  );
}