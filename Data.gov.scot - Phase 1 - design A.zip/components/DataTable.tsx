import { useState, useEffect } from "react";
import { ChevronDown, ChevronUp, Search, Maximize2, Minimize2 } from "lucide-react";

interface DataRow {
  id: number;
  indicator: string;
  sex: string;
  year: string;
}

interface DataTableProps {
  sexFilter?: string[];
  isFullScreen?: boolean;
  onFullScreenToggle?: () => void;
}

// Mock data for the table
const mockData: DataRow[] = [
  { id: 1, indicator: "Physical Activity - Meets recommendations", sex: "All", year: "2023" },
  { id: 2, indicator: "Physical Activity - Meets recommendations", sex: "Male", year: "2023" },
  { id: 3, indicator: "Physical Activity - Meets recommendations", sex: "Female", year: "2023" },
  { id: 4, indicator: "BMI - Normal weight", sex: "All", year: "2023" },
  { id: 5, indicator: "BMI - Normal weight", sex: "Male", year: "2023" },
  { id: 6, indicator: "BMI - Normal weight", sex: "Female", year: "2023" },
  { id: 7, indicator: "Smoking - Current smoker", sex: "All", year: "2023" },
  { id: 8, indicator: "Smoking - Current smoker", sex: "Male", year: "2023" },
  { id: 9, indicator: "Smoking - Current smoker", sex: "Female", year: "2023" },
  { id: 10, indicator: "Alcohol - Hazardous drinking", sex: "All", year: "2023" },
  { id: 11, indicator: "Alcohol - Hazardous drinking", sex: "Male", year: "2023" },
  { id: 12, indicator: "Alcohol - Hazardous drinking", sex: "Female", year: "2023" },
  { id: 13, indicator: "Mental Wellbeing - Low score", sex: "All", year: "2022" },
  { id: 14, indicator: "Mental Wellbeing - Low score", sex: "Male", year: "2022" },
  { id: 15, indicator: "Mental Wellbeing - Low score", sex: "Female", year: "2022" },
  { id: 16, indicator: "Physical Activity - Meets recommendations", sex: "All", year: "2022" },
  { id: 17, indicator: "Physical Activity - Meets recommendations", sex: "Male", year: "2022" },
  { id: 18, indicator: "Physical Activity - Meets recommendations", sex: "Female", year: "2022" },
  { id: 19, indicator: "BMI - Overweight", sex: "All", year: "2022" },
  { id: 20, indicator: "BMI - Overweight", sex: "Male", year: "2022" },
];

export function DataTable({ sexFilter = [], isFullScreen = false, onFullScreenToggle }: DataTableProps) {
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage, setItemsPerPage] = useState(10); // Changed default from 20 to 10
  const [searchTerm, setSearchTerm] = useState("");
  const [sortColumn, setSortColumn] = useState<keyof DataRow | null>(null);
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('asc');

  // Reset to first page when filter changes
  useEffect(() => {
    setCurrentPage(1);
  }, [sexFilter]);

  // Filter data based on search term and sex filter
  const filteredData = mockData.filter(row => {
    const matchesSearch = row.indicator.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         row.sex.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         row.year.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesSexFilter = sexFilter.length === 0 || sexFilter.includes(row.sex);
    
    return matchesSearch && matchesSexFilter;
  });

  // Sort data
  const sortedData = [...filteredData].sort((a, b) => {
    if (!sortColumn) return 0;
    
    const aValue = a[sortColumn];
    const bValue = b[sortColumn];
    
    if (aValue < bValue) return sortDirection === 'asc' ? -1 : 1;
    if (aValue > bValue) return sortDirection === 'asc' ? 1 : -1;
    return 0;
  });

  // Calculate pagination
  const totalPages = Math.ceil(sortedData.length / itemsPerPage);
  const startIndex = (currentPage - 1) * itemsPerPage;
  const endIndex = startIndex + itemsPerPage;
  const paginatedData = sortedData.slice(startIndex, endIndex);

  const handleSort = (column: keyof DataRow) => {
    if (sortColumn === column) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
    } else {
      setSortColumn(column);
      setSortDirection('asc');
    }
  };

  const handlePageChange = (page: number) => {
    setCurrentPage(page);
  };

  const handleItemsPerPageChange = (items: number) => {
    setItemsPerPage(items);
    setCurrentPage(1);
  };

  const handleFullScreen = () => {
    if (onFullScreenToggle) {
      onFullScreenToggle();
    }
  };

  const SortIcon = ({ column }: { column: keyof DataRow }) => {
    if (sortColumn !== column) return null;
    return sortDirection === 'asc' ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />;
  };

  return (
    <div className="bg-white border border-[#b3b3b3] rounded-sm">
      {/* Table controls */}
      <div className="flex items-center justify-between p-4 bg-[#f8f8f8] border-b border-[#b3b3b3]">
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2">
            <span className="text-sm text-[#333333]">Show</span>
            <select 
              value={itemsPerPage}
              onChange={(e) => handleItemsPerPageChange(Number(e.target.value))}
              className="px-2 py-1 border border-[#b3b3b3] rounded text-sm bg-white"
            >
              <option value={10}>10</option>
              <option value={20}>20</option>
              <option value={50}>50</option>
              <option value={100}>100</option>
            </select>
            <span className="text-sm text-[#333333]">entries</span>
          </div>
        </div>
        
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2">
            <span className="text-sm text-[#333333]">Search:</span>
            <div className="relative">
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="px-3 py-1 border border-[#b3b3b3] rounded text-sm w-48"
                placeholder="Search..."
              />
              <Search className="absolute right-2 top-1/2 transform -translate-y-1/2 w-4 h-4 text-[#5e5e5e]" />
            </div>
          </div>
          
          <button
            onClick={handleFullScreen}
            className="flex items-center gap-1 px-3 py-1 text-sm border border-[#b3b3b3] rounded bg-white hover:bg-[#f8f8f8] transition-colors duration-200"
          >
            {isFullScreen ? (
              <>
                <Minimize2 className="w-4 h-4" />
                <span>Exit full screen</span>
              </>
            ) : (
              <>
                <Maximize2 className="w-4 h-4" />
                <span>Full screen</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Table */}
      <div className="overflow-x-auto">
        <table className="w-full">
          <thead className="bg-[#f8f8f8] border-b border-[#b3b3b3]">
            <tr>
              <th 
                className="px-4 py-3 text-left text-sm font-medium text-[#333333] cursor-pointer hover:bg-[#ebebeb] border-r border-[#b3b3b3]"
                onClick={() => handleSort('indicator')}
              >
                <div className="flex items-center gap-2">
                  Scottish Health Survey Indicator
                  <SortIcon column="indicator" />
                </div>
              </th>
              <th 
                className="px-4 py-3 text-left text-sm font-medium text-[#333333] cursor-pointer hover:bg-[#ebebeb] border-r border-[#b3b3b3]"
                onClick={() => handleSort('sex')}
              >
                <div className="flex items-center gap-2">
                  Sex
                  <SortIcon column="sex" />
                </div>
              </th>
              <th 
                className="px-4 py-3 text-left text-sm font-medium text-[#333333] cursor-pointer hover:bg-[#ebebeb]"
                onClick={() => handleSort('year')}
              >
                <div className="flex items-center gap-2">
                  Year
                  <SortIcon column="year" />
                </div>
              </th>
            </tr>
          </thead>
          <tbody>
            {paginatedData.map((row, index) => (
              <tr 
                key={row.id}
                className={`border-b border-[#b3b3b3] hover:bg-[#f8f8f8] ${index % 2 === 0 ? 'bg-white' : 'bg-[#f9f9f9]'}`}
              >
                <td className="px-4 py-3 text-sm text-[#333333] border-r border-[#b3b3b3]">
                  {row.indicator}
                </td>
                <td className="px-4 py-3 text-sm text-[#333333] border-r border-[#b3b3b3]">
                  {row.sex}
                </td>
                <td className="px-4 py-3 text-sm text-[#333333]">
                  {row.year}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Pagination */}
      <div className="flex items-center justify-between p-4 bg-[#f8f8f8] border-t border-[#b3b3b3]">
        <div className="text-sm text-[#333333]">
          Showing {startIndex + 1} to {Math.min(endIndex, sortedData.length)} of {sortedData.length} entries
        </div>
        
        <div className="flex items-center gap-2">
          <button
            onClick={() => handlePageChange(currentPage - 1)}
            disabled={currentPage === 1}
            className="px-3 py-1 text-sm border border-[#b3b3b3] rounded bg-white hover:bg-[#f8f8f8] disabled:opacity-50 disabled:cursor-not-allowed"
          >
            Previous
          </button>
          
          {Array.from({ length: Math.min(5, totalPages) }, (_, i) => {
            const pageNumber = i + 1;
            return (
              <button
                key={pageNumber}
                onClick={() => handlePageChange(pageNumber)}
                className={`px-3 py-1 text-sm border border-[#b3b3b3] rounded ${
                  currentPage === pageNumber
                    ? 'bg-[#0065bd] text-white border-[#0065bd]'
                    : 'bg-white hover:bg-[#f8f8f8]'
                }`}
              >
                {pageNumber}
              </button>
            );
          })}
          
          {totalPages > 5 && (
            <>
              <span className="text-sm text-[#333333]">...</span>
              <button
                onClick={() => handlePageChange(totalPages)}
                className={`px-3 py-1 text-sm border border-[#b3b3b3] rounded ${
                  currentPage === totalPages
                    ? 'bg-[#0065bd] text-white border-[#0065bd]'
                    : 'bg-white hover:bg-[#f8f8f8]'
                }`}
              >
                {totalPages}
              </button>
            </>
          )}
          
          <button
            onClick={() => handlePageChange(currentPage + 1)}
            disabled={currentPage === totalPages}
            className="px-3 py-1 text-sm border border-[#b3b3b3] rounded bg-white hover:bg-[#f8f8f8] disabled:opacity-50 disabled:cursor-not-allowed"
          >
            Next
          </button>
        </div>
      </div>
    </div>
  );
}