export function Hero() {
  return (
    <section className="sg-hero">
      <div className="sg-hero-container">
        <h1 className="sg-hero-title-homepage">
          Open access to Scotland&apos;s official data
        </h1>
        
        <div className="sg-hero-description">
          <p className="mb-0" style={{ maxWidth: '650px' }}>
            Welcome to the Scottish Government&apos;s official open data portal which provides public access to hundreds of datasets from a range of data producers.
          </p>
        </div>
      </div>
    </section>
  );
}