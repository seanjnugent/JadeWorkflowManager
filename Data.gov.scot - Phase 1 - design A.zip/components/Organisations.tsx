import { useState } from "react";
import { X } from "lucide-react";
import svgPaths from "../imports/svg-lxv4opcm4j";

export function Organisations() {
  const [searchValue, setSearchValue] = useState("");
  const [sortBy, setSortBy] = useState("A-Z");

  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchValue(e.target.value);
  };

  const clearSearch = () => {
    setSearchValue("");
  };

  const handleOrganisationClick = () => {
    window.location.hash = '#/data';
  };

  const handleButtonClick = (e: React.MouseEvent) => {
    e.stopPropagation(); // Prevent tile click when button is clicked
    window.location.hash = '#/data';
  };

  const organisations = [
    { name: "Accountant in Bankruptcy", datasets: 3 },
    { name: "Care Inspectorate", datasets: 7 },
    { name: "National Records of Scotland", datasets: 9 },
    { name: "Public Health Scotland", datasets: 5 },
    { name: "Registers of Scotland", datasets: 4 },
    { name: "Revenue Scotland", datasets: 2 },
    { name: "SEPA", datasets: 8 },
    { name: "Scottish Fire and Rescue Service", datasets: 6 },
    { name: "Scottish Government", datasets: 9 },
    { name: "Scottish Natural Heritage", datasets: 4 },
    { name: "Social Security Scotland", datasets: 3 },
    { name: "Transport Scotland", datasets: 7 },
    { name: "VisitScotland", datasets: 5 }
  ];

  return (
    <div className="min-h-screen bg-white">
      <div className="max-w-[1200px] mx-auto px-6 py-8">
        {/* Breadcrumb */}
        <nav className="mb-6">
          <div className="flex items-center gap-2 text-base">
            <a 
              href="#/" 
              className="text-[#0065bd] hover:text-[#004a9f] hover:no-underline underline cursor-pointer transition-colors duration-200"
            >
              Home
            </a>
            <span className="text-[#5e5e5e]">&gt;</span>
            <span className="text-[#333333]">Organisations</span>
          </div>
        </nav>

        <div className="flex gap-8">
          {/* Sidebar - 25% width */}
          <div className="w-1/4 shrink-0">
            {/* Page title */}
            <div className="mb-6">
              <h1 className="text-[44px] font-bold text-black leading-[50px] tracking-[0.15px] whitespace-nowrap">
                13 organisations found
              </h1>
            </div>

            {/* Search */}
            <div className="mb-6">
              <h2 className="text-[24px] font-bold text-black leading-[32px] tracking-[0.15px] mb-2">
                Search
              </h2>
              <div className="sg-data-search-container">
                <input
                  type="text"
                  placeholder="Search organisations..."
                  value={searchValue}
                  onChange={handleSearchChange}
                  className="sg-data-search-input"
                />
                {searchValue && (
                  <button
                    onClick={clearSearch}
                    className="absolute right-12 top-1/2 transform -translate-y-1/2 text-gray-500 hover:text-gray-700 p-1"
                    aria-label="Clear search"
                  >
                    <X className="w-4 h-4" />
                  </button>
                )}
                <button 
                  className="sg-data-search-button"
                  type="submit"
                  aria-label="Search organisations"
                >
                  <svg
                    className="w-6 h-6 text-white"
                    fill="none"
                    viewBox="0 0 48 48"
                  >
                    <path
                      d={svgPaths.p26efbc80}
                      fill="currentColor"
                    />
                  </svg>
                </button>
              </div>
            </div>
          </div>

          {/* Main content - 75% width */}
          <div className="w-3/4">
            {/* Sort by dropdown - positioned at top of content */}
            <div className="flex justify-end mb-6" style={{ marginTop: '46px' }}>
              <div className="flex items-center gap-2">
                <label className="text-base text-[#1a1a1a] tracking-[0.15px]">
                  Sort by:
                </label>
                <div className="relative">
                  <select 
                    value={sortBy} 
                    onChange={(e) => setSortBy(e.target.value)}
                    className="h-10 w-40 px-3 pr-10 bg-white border-2 border-black text-base appearance-none cursor-pointer"
                  >
                    <option>A-Z</option>
                    <option>Z-A</option>
                  </select>
                  <div className="absolute right-0 top-0 w-10 h-10 bg-[#0065bd] flex items-center justify-center pointer-events-none">
                    <div className="w-4 h-4 transform rotate-[315deg]">
                      <div className="border-white border-[0px_0px_3px_3px] w-3 h-3"></div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Organisation tiles */}
            <div className="space-y-6">
              {organisations.map((organisation, index) => (
                <div 
                  key={index}
                  className="sg-organisation-tile"
                  onClick={handleOrganisationClick}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' || e.key === ' ') {
                      e.preventDefault();
                      handleOrganisationClick();
                    }
                  }}
                  tabIndex={0}
                  role="button"
                  aria-label={`View data for ${organisation.name}`}
                >
                  <div className="flex items-center justify-between">
                    <h3 className="sg-dataset-title mb-0">
                      {organisation.name}
                    </h3>
                    <button
                      className="sg-view-datasets-button"
                      onClick={handleButtonClick}
                      aria-label={`View ${organisation.datasets} datasets for ${organisation.name}`}
                    >
                      {organisation.datasets} Datasets
                    </button>
                  </div>
                </div>
              ))}
            </div>

            {/* Pagination */}
            <div className="flex justify-center pt-6">
              <div className="w-10 h-10 bg-[#f8f8f8] border-b-2 border-black flex items-center justify-center">
                <span className="text-base text-black cursor-pointer">1</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}