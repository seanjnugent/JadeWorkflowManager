import { useState } from "react";
import { X, Search, Building, Folder, HelpCircle } from "lucide-react";
import svgPaths from "../imports/svg-tmym2azjca";

export function DataTiles() {
  const [searchValue, setSearchValue] = useState("");
  
  const commonSearches = [
    "Population", "Housing", "Education", "Transport", "Health"
  ];

  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchValue(e.target.value);
  };

  const clearSearch = () => {
    setSearchValue("");
  };

  const handleTagClick = (tag: string) => {
    setSearchValue(tag);
    // Navigate to data page with search term
    window.location.hash = '#/data';
  };

  return (
    <section className="bg-white">
      <div className="sg-tiles-container-2x2">
        {/* Search our data tile - Top left */}
        <div className="sg-tile sg-search-tile">
          <h2 className="flex items-center gap-2">
            <Search className="w-6 h-6" />
            Search our data
          </h2>
          
          {/* Search form - moved up, no description text */}
          <div className="sg-tile-search">
            <div className="relative flex mb-4">
              <input
                type="text"
                placeholder="Search data..."
                value={searchValue}
                onChange={handleSearchChange}
                className="sg-search-input flex-1 h-[44px] rounded-none border-r-0 pr-12"
              />
              {searchValue && (
                <button
                  onClick={clearSearch}
                  className="absolute right-12 top-1/2 transform -translate-y-1/2 text-gray-500 hover:text-gray-700 p-1"
                  aria-label="Clear search"
                >
                  <X className="w-4 h-4" />
                </button>
              )}
              <button 
                className="sg-search-button rounded-none border-2 border-l-0 border-gray-600"
                type="submit"
                aria-label="Search datasets"
                onClick={() => window.location.hash = '#/data'}
              >
                <svg
                  className="w-6 h-6 text-white"
                  fill="none"
                  viewBox="0 0 48 48"
                >
                  <path
                    d={svgPaths.p26efbc80}
                    fill="currentColor"
                  />
                </svg>
              </button>
            </div>
            
            {/* Common searches section */}
            <div>
              <h3 className="text-sm font-medium text-gray-700 mb-3">Common searches:</h3>
              <div className="flex flex-wrap gap-2">
                {commonSearches.map((tag) => (
                  <button
                    key={tag}
                    onClick={() => handleTagClick(tag)}
                    className="text-white text-sm px-3 py-1 rounded-sm transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 hover:underline"
                    style={{ 
                      backgroundColor: 'var(--sg-blue-dark)'
                    }}
                  >
                    {tag}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Browse organisations tile - Top right */}
        <a href="#/organisations" className="sg-tile">
          <h2 className="flex items-center gap-2">
            <Building className="w-6 h-6" />
            Browse organisations
          </h2>
          <p>Explore datasets by the organisations that publish Scotland&apos;s official statistics and data.</p>
        </a>

        {/* Browse themes tile - Bottom left */}
        <a href="#/themes" className="sg-tile">
          <h2 className="flex items-center gap-2">
            <Folder className="w-6 h-6" />
            Browse themes
          </h2>
          <p>Discover data categorised by themes such as health, education, economy and environment.</p>
        </a>

        {/* How to use this site tile - Bottom right */}
        <a href="#/help" className="sg-tile">
          <h2 className="flex items-center gap-2">
            <HelpCircle className="w-6 h-6" />
            How to use this site
          </h2>
          <p>Learn how to search, download, and work with the data available on this portal.</p>
        </a>
      </div>
    </section>
  );
}