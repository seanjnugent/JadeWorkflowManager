import { useState, useEffect } from "react";
import { Header } from "./components/Header";
import { Hero } from "./components/Hero";
import { DataTiles } from "./components/DataTiles";
import { Data } from "./components/Data";
import { Organisations } from "./components/Organisations";
import { Themes } from "./components/Themes";
import { HealthSurvey } from "./components/HealthSurvey";
import { DataBySex } from "./components/DataBySex";
import { Help } from "./components/Help";
import { About } from "./components/About";
import { Contact } from "./components/Contact";
import { Footer } from "./components/Footer";

export default function App() {
  const [currentPage, setCurrentPage] = useState('home');

  useEffect(() => {
    const handleHashChange = () => {
      const hash = window.location.hash;
      let newPage = 'home';
      
      if (hash === '#/data') {
        newPage = 'data';
      } else if (hash === '#/organisations') {
        newPage = 'organisations';
      } else if (hash === '#/themes') {
        newPage = 'themes';
      } else if (hash === '#/health-survey') {
        newPage = 'health-survey';
      } else if (hash === '#/data-by-sex') {
        newPage = 'data-by-sex';
      } else if (hash === '#/help') {
        newPage = 'help';
      } else if (hash === '#/about') {
        newPage = 'about';
      } else if (hash === '#/contact') {
        newPage = 'contact';
      }
      
      // Only scroll to top if the page actually changed
      if (newPage !== currentPage) {
        window.scrollTo(0, 0);
      }
      
      setCurrentPage(newPage);
    };

    // Check initial hash
    handleHashChange();
    
    // Listen for hash changes
    window.addEventListener('hashchange', handleHashChange);
    
    return () => {
      window.removeEventListener('hashchange', handleHashChange);
    };
  }, [currentPage]);

  return (
    <div className="min-h-screen bg-white">
      <Header currentPage={currentPage} />
      
      {currentPage === 'home' ? (
        <main>
          <Hero />
          <DataTiles />
        </main>
      ) : currentPage === 'data' ? (
        <main>
          <Data />
        </main>
      ) : currentPage === 'organisations' ? (
        <main>
          <Organisations />
        </main>
      ) : currentPage === 'themes' ? (
        <main>
          <Themes />
        </main>
      ) : currentPage === 'health-survey' ? (
        <main>
          <HealthSurvey />
        </main>
      ) : currentPage === 'data-by-sex' ? (
        <main>
          <DataBySex />
        </main>
      ) : currentPage === 'help' ? (
        <main>
          <Help />
        </main>
      ) : currentPage === 'about' ? (
        <main>
          <About />
        </main>
      ) : currentPage === 'contact' ? (
        <main>
          <Contact />
        </main>
      ) : (
        <main>
          <Hero />
          <DataTiles />
        </main>
      )}
      
      <Footer />
    </div>
  );
}