import svgPaths from "./svg-tmym2azjca";

function StrongMispelledLink() {
  return (
    <div
      className="absolute h-[17px] left-[698.41px] top-[167.5px] w-[66.13px]"
      data-name="Strong → Mispelled → Link"
    >
      <a
        className="absolute flex flex-col font-['Roboto:Bold',_sans-serif] font-bold h-[17px] justify-center leading-[0] left-0 text-[#ffffff] text-[16px] text-left top-[8.5px] tracking-[0.15px] translate-y-[-50%] w-[66.432px]"
        href="https://cobalt.sgdatacatalogue.net/datasets"
        style={{ fontVariationSettings: "'wdth' 100" }}
      >
        <p className="[text-decoration-line:underline] [text-decoration-style:solid] [text-underline-position:from-font] adjustLetterSpacing block cursor-pointer leading-[24px]">
          datasets
        </p>
      </a>
    </div>
  );
}

function StrongMispelledLink1() {
  return (
    <div
      className="absolute h-[17px] left-[392.5px] top-[191.5px] w-[47.89px]"
      data-name="Strong → Mispelled → Link"
    >
      <a
        className="absolute flex flex-col font-['Roboto:Bold',_sans-serif] font-bold h-[17px] justify-center leading-[0] left-0 text-[#ffffff] text-[16px] text-left top-[8.5px] tracking-[0.15px] translate-y-[-50%] w-[48.236px]"
        href="https://cobalt.sgdatacatalogue.net/themes"
        style={{ fontVariationSettings: "'wdth' 100" }}
      >
        <p className="[text-decoration-line:underline] [text-decoration-style:solid] [text-underline-position:from-font] adjustLetterSpacing block cursor-pointer leading-[24px]">
          theme
        </p>
      </a>
    </div>
  );
}

function StrongMispelledLink2() {
  return (
    <div
      className="absolute h-[17px] left-[464.11px] top-[191.5px] w-[106.86px]"
      data-name="Strong → Mispelled → Link"
    >
      <a
        className="absolute flex flex-col font-['Roboto:Bold',_sans-serif] font-bold h-[17px] justify-center leading-[0] left-0 text-[#ffffff] text-[16px] text-left top-[8.5px] tracking-[0.15px] translate-y-[-50%] w-[107.225px]"
        href="https://cobalt.sgdatacatalogue.net/organisations"
        style={{ fontVariationSettings: "'wdth' 100" }}
      >
        <p className="[text-decoration-line:underline] [text-decoration-style:solid] [text-underline-position:from-font] adjustLetterSpacing block cursor-pointer leading-[24px]">
          organisations
        </p>
      </a>
    </div>
  );
}

function StrongMispelledLink3() {
  return (
    <div
      className="absolute h-[17px] left-[655.19px] top-[191.5px] w-[33.5px]"
      data-name="Strong → Mispelled → Link"
    >
      <a
        className="absolute flex flex-col font-['Roboto:Bold',_sans-serif] font-bold h-[17px] justify-center leading-[0] left-0 text-[#ffffff] text-[16px] text-left top-[8.5px] tracking-[0.15px] translate-y-[-50%] w-[33.802px]"
        href="https://cobalt.sgdatacatalogue.net/help"
        style={{ fontVariationSettings: "'wdth' 100" }}
      >
        <p className="[text-decoration-line:underline] [text-decoration-style:solid] [text-underline-position:from-font] adjustLetterSpacing block cursor-pointer leading-[24px]">
          help
        </p>
      </a>
    </div>
  );
}

function StrongMispelledLink4() {
  return (
    <div
      className="absolute h-[17px] left-[940.36px] top-[191.5px] w-[81.53px]"
      data-name="Strong → Mispelled → Link"
    >
      <a
        className="absolute flex flex-col font-['Roboto:Bold',_sans-serif] font-bold h-[17px] justify-center leading-[0] left-0 text-[#ffffff] text-[16px] text-left top-[8.5px] tracking-[0.15px] translate-y-[-50%] w-[81.856px]"
        href="https://cobalt.sgdatacatalogue.net/contact"
        style={{ fontVariationSettings: "'wdth' 100" }}
      >
        <p className="[text-decoration-line:underline] [text-decoration-style:solid] [text-underline-position:from-font] adjustLetterSpacing block cursor-pointer leading-[24px]">
          contact us
        </p>
      </a>
    </div>
  );
}

function Container() {
  return (
    <div
      className="absolute h-[18px] left-3 overflow-clip right-[73px] top-[15px]"
      data-name="Container"
    >
      <div
        className="absolute flex flex-col font-['Roboto:Regular',_sans-serif] font-normal h-[17px] justify-center leading-[0] left-0 text-[#5e5e5e] text-[16px] text-left top-[8.5px] translate-y-[-50%] w-[114.236px]"
        style={{ fontVariationSettings: "'wdth' 100" }}
      >
        <p className="block leading-[normal]">Search our data</p>
      </div>
    </div>
  );
}

function Input() {
  return (
    <div className="absolute bg-[#f8f8f8] inset-0" data-name="Input">
      <div className="overflow-clip relative size-full">
        <Container />
      </div>
      <div className="absolute border-2 border-[#5e5e5e] border-solid inset-0 pointer-events-none" />
    </div>
  );
}

function Img() {
  return (
    <div className="absolute right-0 size-12 top-0" data-name="Img">
      <svg
        className="block size-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 48 48"
      >
        <g id="Img">
          <path
            d={svgPaths.p26efbc80}
            fill="var(--fill-0, white)"
            id="Vector"
          />
        </g>
      </svg>
    </div>
  );
}

function Button() {
  return (
    <div
      className="absolute bg-[#0065bd] left-[616px] size-12 top-0"
      data-name="Button"
    >
      <Img />
    </div>
  );
}

function Search() {
  return (
    <div className="absolute h-12 left-1 right-1 top-1" data-name="Search">
      <Input />
      <Button />
    </div>
  );
}

function Border() {
  return (
    <div
      className="absolute h-14 left-[392.5px] rounded-lg top-[252.5px] w-[672px]"
      data-name="Border"
    >
      <div className="absolute border-4 border-[#ffffff] border-solid inset-0 pointer-events-none rounded-lg" />
      <Search />
    </div>
  );
}

function Background() {
  return (
    <div
      className="absolute bg-[#005eb8] h-[355.5px] left-0 right-0 top-0"
      data-name="Background"
    >
      <div
        className="absolute flex flex-col font-['Roboto:Bold',_sans-serif] font-bold h-14 justify-center leading-[0] left-[392.5px] text-[#ffffff] text-[44px] text-left top-[60px] tracking-[0.15px] translate-y-[-50%] w-[665.74px]"
        style={{ fontVariationSettings: "'wdth' 100" }}
      >
        <p className="adjustLetterSpacing block leading-[56px]">{`Open access to Scotland's data`}</p>
      </div>
      <div
        className="absolute flex flex-col font-['Roboto:Regular',_sans-serif] font-normal h-[41px] justify-center leading-[24px] left-[392.5px] text-[#ffffff] text-[16px] text-left top-[124px] tracking-[0.15px] translate-y-[-50%] w-[724.687px]"
        style={{ fontVariationSettings: "'wdth' 100" }}
      >
        <p className="adjustLetterSpacing block mb-0">{`The Scottish Government’s official open data portal which provides public access to Scotland's data.`}</p>
        <p className="adjustLetterSpacing block">
          The site is managed by the Scottish Government on behalf of its data
          producers.
        </p>
      </div>
      <div
        className="absolute flex flex-col font-['Roboto:Regular',_sans-serif] font-normal h-[17px] justify-center leading-[0] left-[392.5px] text-[#ffffff] text-[16px] text-left top-44 tracking-[0.15px] translate-y-[-50%] w-[306.229px]"
        style={{ fontVariationSettings: "'wdth' 100" }}
      >
        <p className="adjustLetterSpacing block leading-[24px]">{`Explore, visualise and download over 300 `}</p>
      </div>
      <StrongMispelledLink />
      <div
        className="absolute flex flex-col font-['Roboto:Regular',_sans-serif] font-normal h-[17px] justify-center leading-[0] left-[764.53px] text-[#ffffff] text-[16px] text-left top-44 tracking-[0.15px] translate-y-[-50%] w-[328.255px]"
        style={{ fontVariationSettings: "'wdth' 100" }}
      >
        <p className="adjustLetterSpacing block leading-[24px]">{` from a range of producers. Start browsing by`}</p>
      </div>
      <StrongMispelledLink1 />
      <div
        className="absolute flex flex-col font-['Roboto:Regular',_sans-serif] font-normal h-[17px] justify-center leading-[0] left-[440.39px] text-[#ffffff] text-[16px] text-left top-[200px] tracking-[0.15px] translate-y-[-50%] w-[24.062px]"
        style={{ fontVariationSettings: "'wdth' 100" }}
      >
        <p className="adjustLetterSpacing block leading-[24px]">{` or `}</p>
      </div>
      <StrongMispelledLink2 />
      <div
        className="absolute flex flex-col font-['Roboto:Regular',_sans-serif] font-normal h-[17px] justify-center leading-[0] left-[570.97px] text-[#ffffff] text-[16px] text-left top-[200px] tracking-[0.15px] translate-y-[-50%] w-[84.55px]"
        style={{ fontVariationSettings: "'wdth' 100" }}
      >
        <p className="adjustLetterSpacing block leading-[24px]">{`. There are `}</p>
      </div>
      <StrongMispelledLink3 />
      <div
        className="absolute flex flex-col font-['Roboto:Regular',_sans-serif] font-normal h-[17px] justify-center leading-[0] left-[688.69px] text-[#ffffff] text-[16px] text-left top-[200px] tracking-[0.15px] translate-y-[-50%] w-[252.066px]"
        style={{ fontVariationSettings: "'wdth' 100" }}
      >
        <p className="adjustLetterSpacing block leading-[24px]">{` pages to get you started. You can `}</p>
      </div>
      <StrongMispelledLink4 />
      <div
        className="absolute flex flex-col font-['Roboto:Regular',_sans-serif] font-normal h-[17px] justify-center leading-[0] left-[1021.89px] text-[#ffffff] text-[16px] text-left top-[200px] tracking-[0.15px] translate-y-[-50%] w-[84.861px]"
        style={{ fontVariationSettings: "'wdth' 100" }}
      >
        <p className="adjustLetterSpacing block leading-[24px]">{` if you need`}</p>
      </div>
      <div
        className="absolute flex flex-col font-['Roboto:Regular',_sans-serif] font-normal h-[17px] justify-center leading-[0] left-[392.5px] text-[#ffffff] text-[16px] text-left top-56 tracking-[0.15px] translate-y-[-50%] w-[60.67px]"
        style={{ fontVariationSettings: "'wdth' 100" }}
      >
        <p className="adjustLetterSpacing block leading-[24px]">support.</p>
      </div>
      <Border />
    </div>
  );
}

function Heading2Link() {
  return (
    <a
      className="absolute block cursor-pointer h-[27px] left-4 overflow-visible right-[248.06px] top-[26px]"
      data-name="Heading 2 → Link"
      href="https://cobalt.sgdatacatalogue.net/datasets"
    >
      <div
        className="absolute flex flex-col font-['Roboto:Bold',_sans-serif] font-bold h-[27px] justify-center leading-[0] left-0 text-[#0065bd] text-[24px] text-left top-[13.5px] tracking-[0.15px] translate-y-[-50%] w-[101.627px]"
        role="link"
        style={{ fontVariationSettings: "'wdth' 100" }}
        tabIndex="0"
      >
        <p className="adjustLetterSpacing block cursor-pointer leading-[32px]">
          Datasets
        </p>
      </div>
    </a>
  );
}

function Article() {
  return (
    <div
      className="absolute h-[200px] left-0 right-0 top-0"
      data-name="Article"
    >
      <Heading2Link />
      <div
        className="absolute flex flex-col font-['Roboto:Regular',_sans-serif] font-normal h-[41px] justify-center leading-[24px] left-4 text-[#5e5e5e] text-[16px] text-left top-[95.5px] tracking-[0.15px] translate-y-[-50%] w-[320.889px]"
        style={{ fontVariationSettings: "'wdth' 100" }}
      >
        <p className="adjustLetterSpacing block mb-0">
          A wide range of datasets available for public
        </p>
        <p className="adjustLetterSpacing block">use.</p>
      </div>
    </div>
  );
}

function Item() {
  return (
    <div
      className="absolute bg-[#ffffff] bottom-0 left-0 right-[754.67px] shadow-[1px_1px_4px_0px_rgba(0,0,0,0.15)] top-0"
      data-name="Item"
    >
      <Article />
    </div>
  );
}

function Heading2Link1() {
  return (
    <a
      className="absolute block cursor-pointer h-[27px] left-4 overflow-visible right-[186px] top-[26px]"
      data-name="Heading 2 → Link"
      href="https://cobalt.sgdatacatalogue.net/organisations"
    >
      <div
        className="absolute flex flex-col font-['Roboto:Bold',_sans-serif] font-bold h-[27px] justify-center leading-[0] left-0 text-[#0065bd] text-[24px] text-left top-[13.5px] tracking-[0.15px] translate-y-[-50%] w-[163.657px]"
        role="link"
        style={{ fontVariationSettings: "'wdth' 100" }}
        tabIndex="0"
      >
        <p className="adjustLetterSpacing block cursor-pointer leading-[32px]">
          Organisations
        </p>
      </div>
    </a>
  );
}

function Article1() {
  return (
    <div
      className="absolute h-[200px] left-0 right-0 top-0"
      data-name="Article"
    >
      <Heading2Link1 />
      <div
        className="absolute flex flex-col font-['Roboto:Regular',_sans-serif] font-normal h-[41px] justify-center leading-[24px] left-4 text-[#5e5e5e] text-[16px] text-left top-[95.5px] tracking-[0.15px] translate-y-[-50%] w-[311.356px]"
        style={{ fontVariationSettings: "'wdth' 100" }}
      >
        <p className="adjustLetterSpacing block mb-0">{`Organisations publishing Scotland's official`}</p>
        <p className="adjustLetterSpacing block">statistics.</p>
      </div>
    </div>
  );
}

function Item1() {
  return (
    <div
      className="absolute bg-[#ffffff] bottom-0 left-[377.33px] right-[377.34px] shadow-[1px_1px_4px_0px_rgba(0,0,0,0.15)] top-0"
      data-name="Item"
    >
      <Article1 />
    </div>
  );
}

function Heading2Link2() {
  return (
    <a
      className="absolute block cursor-pointer h-[27px] left-4 overflow-visible right-[257.73px] top-[26px]"
      data-name="Heading 2 → Link"
      href="https://cobalt.sgdatacatalogue.net/themes"
    >
      <div
        className="absolute flex flex-col font-['Roboto:Bold',_sans-serif] font-bold h-[27px] justify-center leading-[0] left-0 text-[#0065bd] text-[24px] text-left top-[13.5px] tracking-[0.15px] translate-y-[-50%] w-[91.952px]"
        role="link"
        style={{ fontVariationSettings: "'wdth' 100" }}
        tabIndex="0"
      >
        <p className="adjustLetterSpacing block cursor-pointer leading-[32px]">
          Themes
        </p>
      </div>
    </a>
  );
}

function Article2() {
  return (
    <div
      className="absolute h-[200px] left-0 right-0 top-0"
      data-name="Article"
    >
      <Heading2Link2 />
      <div
        className="absolute flex flex-col font-['Roboto:Regular',_sans-serif] font-normal h-[41px] justify-center leading-[24px] left-4 text-[#5e5e5e] text-[16px] text-left top-[95.5px] tracking-[0.15px] translate-y-[-50%] w-[258.77px]"
        style={{ fontVariationSettings: "'wdth' 100" }}
      >
        <p className="adjustLetterSpacing block mb-0">
          Datasets by themes such as health,
        </p>
        <p className="adjustLetterSpacing block">education and economy.</p>
      </div>
    </div>
  );
}

function Item2() {
  return (
    <div
      className="absolute bg-[#ffffff] bottom-0 left-[754.66px] right-0 shadow-[1px_1px_4px_0px_rgba(0,0,0,0.15)] top-0"
      data-name="Item"
    >
      <Article2 />
    </div>
  );
}

function NavCategoryNavigationList() {
  return (
    <div
      className="absolute h-[200px] left-[392.5px] right-[392.5px] top-[419.5px]"
      data-name="Nav - Category navigation → List"
    >
      <Item />
      <Item1 />
      <Item2 />
    </div>
  );
}

function Link() {
  return (
    <div
      className="absolute bg-[#ebebeb] bottom-[-8px] left-[392.5px] rounded top-[691.5px] w-[124.08px]"
      data-name="Link"
    >
      <a
        className="absolute flex flex-col font-['Roboto:Medium',_sans-serif] font-medium h-4 justify-center leading-[0] left-4 text-[#0065bd] text-[14px] text-left top-[18px] tracking-[0.15px] translate-y-[-50%] w-[92.422px]"
        href="https://cobalt.sgdatacatalogue.net/results"
        style={{ fontVariationSettings: "'wdth' 100" }}
      >
        <p className="adjustLetterSpacing block cursor-pointer leading-[21px]">
          Demographics
        </p>
      </a>
    </div>
  );
}

function Link1() {
  return (
    <div
      className="absolute bg-[#ebebeb] bottom-[-8px] left-[524.58px] rounded top-[691.5px] w-[99.67px]"
      data-name="Link"
    >
      <a
        className="absolute flex flex-col font-['Roboto:Medium',_sans-serif] font-medium h-4 justify-center leading-[0] left-4 text-[#0065bd] text-[14px] text-left top-[18px] tracking-[0.15px] translate-y-[-50%] w-[68.912px]"
        href="https://cobalt.sgdatacatalogue.net/results"
        style={{ fontVariationSettings: "'wdth' 100" }}
      >
        <p className="adjustLetterSpacing block cursor-pointer leading-[21px]">
          Population
        </p>
      </a>
    </div>
  );
}

function Link2() {
  return (
    <div
      className="absolute bg-[#ebebeb] bottom-[-8px] left-[632.25px] rounded top-[691.5px] w-[112.25px]"
      data-name="Link"
    >
      <a
        className="absolute flex flex-col font-['Roboto:Medium',_sans-serif] font-medium h-4 justify-center leading-[0] left-4 text-[#0065bd] text-[14px] text-left top-[18px] tracking-[0.15px] translate-y-[-50%] w-[80.574px]"
        href="https://cobalt.sgdatacatalogue.net/results"
        style={{ fontVariationSettings: "'wdth' 100" }}
      >
        <p className="adjustLetterSpacing block cursor-pointer leading-[21px]">
          Environment
        </p>
      </a>
    </div>
  );
}

function Link3() {
  return (
    <div
      className="absolute bg-[#ebebeb] bottom-[-8px] left-[752.5px] rounded top-[691.5px] w-[73.38px]"
      data-name="Link"
    >
      <a
        className="absolute flex flex-col font-['Roboto:Medium',_sans-serif] font-medium h-4 justify-center leading-[0] left-4 text-[#0065bd] text-[14px] text-left top-[18px] tracking-[0.15px] translate-y-[-50%] w-[41.832px]"
        href="https://cobalt.sgdatacatalogue.net/results"
        style={{ fontVariationSettings: "'wdth' 100" }}
      >
        <p className="adjustLetterSpacing block cursor-pointer leading-[21px]">
          Health
        </p>
      </a>
    </div>
  );
}

function Link4() {
  return (
    <div
      className="absolute bg-[#ebebeb] bottom-[-8px] left-[833.88px] rounded top-[691.5px] w-[89.23px]"
      data-name="Link"
    >
      <a
        className="absolute flex flex-col font-['Roboto:Medium',_sans-serif] font-medium h-4 justify-center leading-[0] left-4 text-[#0065bd] text-[14px] text-left top-[18px] tracking-[0.15px] translate-y-[-50%] w-[57.606px]"
        href="https://cobalt.sgdatacatalogue.net/results"
        style={{ fontVariationSettings: "'wdth' 100" }}
      >
        <p className="adjustLetterSpacing block cursor-pointer leading-[21px]">
          Covid-19
        </p>
      </a>
    </div>
  );
}

function Link5() {
  return (
    <div
      className="absolute bg-[#ebebeb] bottom-[-8px] left-[931.11px] rounded top-[691.5px] w-[70.09px]"
      data-name="Link"
    >
      <a
        className="absolute flex flex-col font-['Roboto:Medium',_sans-serif] font-medium h-4 justify-center leading-[0] left-4 text-[#0065bd] text-[14px] text-left top-[18px] tracking-[0.15px] translate-y-[-50%] w-[38.406px]"
        href="https://cobalt.sgdatacatalogue.net/results"
        style={{ fontVariationSettings: "'wdth' 100" }}
      >
        <p className="adjustLetterSpacing block cursor-pointer leading-[21px]">
          Crime
        </p>
      </a>
    </div>
  );
}

function MainMain() {
  return (
    <div
      className="absolute bottom-[304px] left-0 right-0 top-[173px]"
      data-name="Main → Main"
    >
      <Background />
      <div
        className="absolute flex flex-col font-['Roboto:Bold',_sans-serif] font-bold h-8 justify-center leading-[0] left-[392.5px] text-[22px] text-[rgba(0,0,0,0.87)] text-left top-[395.5px] tracking-[0.15px] translate-y-[-50%] w-[115.438px]"
        style={{ fontVariationSettings: "'wdth' 100" }}
      >
        <p className="adjustLetterSpacing block leading-[32px]">Browse By</p>
      </div>
      <NavCategoryNavigationList />
      <div
        className="absolute flex flex-col font-['Roboto:Bold',_sans-serif] font-bold h-8 justify-center leading-[0] left-[392.5px] text-[22px] text-[rgba(0,0,0,0.87)] text-left top-[667.5px] tracking-[0.15px] translate-y-[-50%] w-[139.838px]"
        style={{ fontVariationSettings: "'wdth' 100" }}
      >
        <p className="adjustLetterSpacing block leading-[32px]">Popular Tags</p>
      </div>
      <Link />
      <Link1 />
      <Link2 />
      <Link3 />
      <Link4 />
      <Link5 />
    </div>
  );
}

function ItemLink() {
  return (
    <div
      className="absolute h-4 left-0 top-1 w-[46.95px]"
      data-name="Item → Link"
    >
      <a
        className="absolute flex flex-col font-['Roboto:Regular',_sans-serif] font-normal h-4 justify-center leading-[0] left-0 text-[#0065bd] text-[14px] text-left top-2 tracking-[0.15px] translate-y-[-50%] w-[47.294px]"
        href="https://cobalt.sgdatacatalogue.net/privacy"
        style={{ fontVariationSettings: "'wdth' 100" }}
      >
        <p className="[text-decoration-line:underline] [text-decoration-style:solid] [text-underline-position:from-font] adjustLetterSpacing block cursor-pointer leading-[24px]">
          Privacy
        </p>
      </a>
    </div>
  );
}

function ItemLink1() {
  return (
    <div
      className="absolute h-4 left-[70.95px] top-1 w-[145.06px]"
      data-name="Item → Link"
    >
      <a
        className="absolute flex flex-col font-['Roboto:Regular',_sans-serif] font-normal h-4 justify-center leading-[0] left-0 text-[#0065bd] text-[14px] text-left top-2 tracking-[0.15px] translate-y-[-50%] w-[148.636px]"
        href="https://cobalt.sgdatacatalogue.net/accessibility"
        style={{ fontVariationSettings: "'wdth' 100" }}
      >
        <p className="[text-decoration-line:underline] [text-decoration-style:solid] [text-underline-position:from-font] adjustLetterSpacing block cursor-pointer leading-[24px]">
          Accessibility statement
        </p>
      </a>
    </div>
  );
}

function ItemLink2() {
  return (
    <div
      className="absolute h-4 left-[240.02px] top-1 w-[49.31px]"
      data-name="Item → Link"
    >
      <a
        className="absolute flex flex-col font-['Roboto:Regular',_sans-serif] font-normal h-4 justify-center leading-[0] left-0 text-[#0065bd] text-[14px] text-left top-2 tracking-[0.15px] translate-y-[-50%] w-[49.963px]"
        href="https://cobalt.sgdatacatalogue.net/contact"
        style={{ fontVariationSettings: "'wdth' 100" }}
      >
        <p className="[text-decoration-line:underline] [text-decoration-style:solid] [text-underline-position:from-font] adjustLetterSpacing block cursor-pointer leading-[24px]">
          Contact
        </p>
      </a>
    </div>
  );
}

function ItemLink3() {
  return (
    <div
      className="absolute h-4 left-[313.33px] top-1 w-[124.39px]"
      data-name="Item → Link"
    >
      <a
        className="absolute flex flex-col font-['Roboto:Regular',_sans-serif] font-normal h-4 justify-center leading-[0] left-0 text-[#0065bd] text-[14px] text-left top-2 tracking-[0.15px] translate-y-[-50%] w-[125.747px]"
        href="https://cobalt.sgdatacatalogue.net/help"
        style={{ fontVariationSettings: "'wdth' 100" }}
      >
        <p className="[text-decoration-line:underline] [text-decoration-style:solid] [text-underline-position:from-font] adjustLetterSpacing block cursor-pointer leading-[24px]">
          How to use this site
        </p>
      </a>
    </div>
  );
}

function List() {
  return (
    <div
      className="absolute bottom-[183px] left-[392.5px] right-[392.5px] top-4"
      data-name="List"
    >
      <div className="absolute border-[#b3b3b3] border-[0px_0px_1px] border-solid inset-0 pointer-events-none" />
      <ItemLink />
      <ItemLink1 />
      <ItemLink2 />
      <ItemLink3 />
    </div>
  );
}

function Link6() {
  return (
    <div
      className="absolute h-[17px] left-[680.59px] top-[83px] w-[230.11px]"
      data-name="Link"
    >
      <a
        className="absolute flex flex-col font-['Roboto:Regular',_sans-serif] font-normal h-[17px] justify-center leading-[0] left-0 text-[#0065bd] text-[16px] text-left top-[8.5px] tracking-[0.15px] translate-y-[-50%] w-[230.489px]"
        href="https://www.nationalarchives.gov.uk/doc/open-government-licence/version/3/"
        style={{ fontVariationSettings: "'wdth' 100" }}
      >
        <p className="[text-decoration-line:underline] [text-decoration-style:solid] [text-underline-position:from-font] adjustLetterSpacing block cursor-pointer leading-[24px]">
          Open Government Licence v3.0
        </p>
      </a>
    </div>
  );
}

function Link7() {
  return (
    <div
      className="absolute h-[17px] left-[95.92px] top-0 w-[46.83px]"
      data-name="Link"
    >
      <a
        className="absolute flex flex-col font-['Roboto:Bold',_sans-serif] font-bold h-[17px] justify-center leading-[0] left-0 text-[#0065bd] text-[16px] text-left top-[8.5px] tracking-[0.15px] translate-y-[-50%] w-[47.173px]"
        href="https://github.com/ckan/ckan"
        style={{ fontVariationSettings: "'wdth' 100" }}
      >
        <p className="[text-decoration-line:underline] [text-decoration-style:solid] [text-underline-position:from-font] adjustLetterSpacing block cursor-pointer leading-[24px]">
          CKAN
        </p>
      </a>
    </div>
  );
}

function Strong() {
  return (
    <div
      className="absolute h-[17px] left-[440.5px] top-[147px] w-[142.75px]"
      data-name="Strong"
    >
      <div
        className="absolute flex flex-col font-['Roboto:Bold',_sans-serif] font-bold h-[17px] justify-center leading-[0] left-0 text-[16px] text-[rgba(0,0,0,0.87)] text-left top-[8.5px] tracking-[0.15px] translate-y-[-50%] w-[96.268px]"
        style={{ fontVariationSettings: "'wdth' 100" }}
      >
        <p className="adjustLetterSpacing block leading-[24px]">{`Powered by `}</p>
      </div>
      <Link7 />
    </div>
  );
}

function OglSvg() {
  return (
    <div
      className="absolute h-[12.959px] left-1/2 top-1/2 translate-x-[-50%] translate-y-[-50%] w-8"
      data-name="ogl.svg"
    >
      <svg
        className="block size-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 32 13"
      >
        <g clipPath="url(#clip0_1_243)" id="ogl.svg">
          <path
            d={svgPaths.p1e54e5f0}
            fill="var(--fill-0, #333333)"
            id="Vector"
          />
          <path
            d={svgPaths.p3e4bb300}
            fill="var(--fill-0, #333333)"
            id="Vector_2"
          />
        </g>
        <defs>
          <clipPath id="clip0_1_243">
            <rect fill="white" height="12.9587" width="32" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function OglSvgFill() {
  return (
    <div
      className="absolute h-[12.95px] left-0 overflow-clip top-0 w-8"
      data-name="ogl.svg fill"
    >
      <OglSvg />
    </div>
  );
}

function OpenGovernmentLicense() {
  return (
    <div
      className="absolute h-[12.95px] left-0 overflow-clip right-0 top-[4.05px]"
      data-name="Open Government License"
    >
      <OglSvgFill />
    </div>
  );
}

function Link8() {
  return (
    <a
      className="absolute block cursor-pointer h-6 left-[392.5px] overflow-visible top-[82px] w-8"
      data-name="Link"
      href="https://www.nationalarchives.gov.uk/doc/open-government-licence/version/3/"
    >
      <OpenGovernmentLicense />
    </a>
  );
}

function ScottishGovernmentMinSvg() {
  return (
    <div
      className="absolute h-[30.394px] left-1/2 top-1/2 translate-x-[-50%] translate-y-[-50%] w-40"
      data-name="scottish-government--min.svg"
    >
      <svg
        className="block size-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 160 31"
      >
        <g clipPath="url(#clip0_1_235)" id="scottish-government--min.svg">
          <g id="Clip path group">
            <mask
              height="31"
              id="mask0_1_235"
              maskUnits="userSpaceOnUse"
              style={{ maskType: "luminance" }}
              width="160"
              x="0"
              y="0"
            >
              <g id="b">
                <path
                  d="M0 0H160V30.3939H0V0Z"
                  fill="var(--fill-0, white)"
                  id="Vector"
                />
              </g>
            </mask>
            <g mask="url(#mask0_1_235)">
              <path
                d={svgPaths.p2a6a7000}
                fill="var(--fill-0, #333E48)"
                id="Vector_2"
              />
            </g>
          </g>
          <path
            d={svgPaths.p19ce0400}
            fill="var(--fill-0, white)"
            id="Vector_3"
          />
          <path
            d={svgPaths.pa664b00}
            fill="var(--fill-0, #0065BD)"
            id="Vector_4"
          />
        </g>
        <defs>
          <clipPath id="clip0_1_235">
            <rect fill="white" height="30.3939" width="160" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function ScottishGovernmentMinSvgFill() {
  return (
    <div
      className="absolute h-[30.39px] left-0 overflow-clip top-0 w-40"
      data-name="scottish-government--min.svg fill"
    >
      <ScottishGovernmentMinSvg />
    </div>
  );
}

function GovScot() {
  return (
    <div
      className="absolute h-[30.39px] left-0 overflow-clip right-0 top-0"
      data-name="gov.scot"
    >
      <ScottishGovernmentMinSvgFill />
    </div>
  );
}

function Link9() {
  return (
    <a
      className="absolute block cursor-pointer h-[30.39px] left-[1352.5px] overflow-visible right-[392.5px] top-20"
      data-name="Link"
      href="https://www.gov.scot/"
    >
      <GovScot />
    </a>
  );
}

function Footer() {
  return (
    <div
      className="absolute bg-[#ebebeb] bottom-0 left-0 right-0 top-[957.5px]"
      data-name="Footer"
    >
      <div className="absolute border-[#b3b3b3] border-[1px_0px_0px] border-solid inset-0 pointer-events-none" />
      <List />
      <div
        className="absolute flex flex-col font-['Roboto:Regular',_sans-serif] font-normal h-[17px] justify-center leading-[0] left-[440.5px] text-[16px] text-[rgba(0,0,0,0.87)] text-left top-[91.5px] tracking-[0.15px] translate-y-[-50%] w-[240.477px]"
        style={{ fontVariationSettings: "'wdth' 100" }}
      >
        <p className="adjustLetterSpacing block leading-[24px]">{`All content is available under the `}</p>
      </div>
      <Link6 />
      <div
        className="absolute flex flex-col font-['Roboto:Regular',_sans-serif] font-normal h-[17px] justify-center leading-[0] left-[910.7px] text-[16px] text-[rgba(0,0,0,0.87)] text-left top-[91.5px] tracking-[0.15px] translate-y-[-50%] w-[191.158px]"
        style={{ fontVariationSettings: "'wdth' 100" }}
      >
        <p className="adjustLetterSpacing block leading-[24px]">
          , except for graphic assets
        </p>
      </div>
      <div
        className="absolute flex flex-col font-['Roboto:Regular',_sans-serif] font-normal h-[17px] justify-center leading-[0] left-[440.5px] text-[16px] text-[rgba(0,0,0,0.87)] text-left top-[115.5px] tracking-[0.15px] translate-y-[-50%] w-[200.245px]"
        style={{ fontVariationSettings: "'wdth' 100" }}
      >
        <p className="adjustLetterSpacing block leading-[24px]">
          and where otherwise stated
        </p>
      </div>
      <Strong />
      <div
        className="absolute flex flex-col font-['Roboto:Regular',_sans-serif] font-normal h-6 justify-center leading-[0] left-[440.5px] text-[16px] text-[rgba(0,0,0,0.87)] text-left top-[196px] tracking-[0.15px] translate-y-[-50%] w-[138.257px]"
        style={{ fontVariationSettings: "'wdth' 100" }}
      >
        <p className="adjustLetterSpacing block leading-[24px]">
          © Crown Copyright
        </p>
      </div>
      <Link8 />
      <Link9 />
    </div>
  );
}

function Container1() {
  return (
    <div
      className="absolute h-[1197.5px] left-0 right-0 top-0"
      data-name="Container"
    >
      <MainMain />
      <Footer />
    </div>
  );
}

function ScottishGovernmentSvg() {
  return (
    <div
      className="absolute h-10 left-1/2 top-1/2 translate-x-[-50%] translate-y-[-50%] w-[269.316px]"
      data-name="scottish-government.svg"
    >
      <svg
        className="block size-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 270 40"
      >
        <g clipPath="url(#clip0_1_229)" id="scottish-government.svg">
          <path
            d="M0 0H60.9772V37.6547H0V0Z"
            fill="var(--fill-0, white)"
            id="Vector"
          />
          <path
            d={svgPaths.p6de980}
            fill="var(--fill-0, #0065BD)"
            id="Vector_2"
          />
          <path
            d={svgPaths.p5307000}
            fill="var(--fill-0, #858B91)"
            id="Vector_3"
          />
          <path
            d={svgPaths.p19f11d00}
            fill="var(--fill-0, #333E48)"
            id="Vector_4"
          />
        </g>
        <defs>
          <clipPath id="clip0_1_229">
            <rect fill="white" height="40" width="269.316" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function ScottishGovernmentSvgFill() {
  return (
    <div
      className="absolute h-10 left-0 overflow-clip top-0 w-[269.31px]"
      data-name="scottish-government.svg fill"
    >
      <ScottishGovernmentSvg />
    </div>
  );
}

function ScottishGovernment() {
  return (
    <div
      className="absolute h-10 left-0 overflow-clip top-0 w-[269.31px]"
      data-name="Scottish Government"
    >
      <ScottishGovernmentSvgFill />
    </div>
  );
}

function Link10() {
  return (
    <a
      className="absolute block cursor-pointer h-10 left-0 overflow-visible top-1/2 translate-y-[-50%] w-[269.31px]"
      data-name="Link"
      href="https://cobalt.sgdatacatalogue.net/"
    >
      <ScottishGovernment />
    </a>
  );
}

function Container2() {
  return (
    <div
      className="absolute h-16 left-[392.5px] overflow-clip right-[657.5px] top-[177px]"
      data-name="Container"
    >
      <div
        className="absolute flex flex-col font-['Roboto:Light',_sans-serif] font-light h-5 justify-center leading-[0] left-[317.31px] text-[16px] text-[rgba(0,0,0,0.87)] text-left top-[30px] tracking-[0.15px] translate-y-[-50%] w-[178.143px]"
        style={{ fontVariationSettings: "'wdth' 100" }}
      >
        <p className="adjustLetterSpacing block leading-[24px]">
          Cobalt Open Data Portal
        </p>
      </div>
      <Link10 />
      <div
        className="absolute bg-[#0065bd] bottom-3 left-[293.31px] top-3 w-px"
        data-name="Vertical Divider"
      />
    </div>
  );
}

function Container3() {
  return (
    <div
      className="absolute h-[18px] left-3 overflow-clip right-[73px] top-[15px]"
      data-name="Container"
    >
      <div
        className="absolute flex flex-col font-['Roboto:Regular',_sans-serif] font-normal h-[17px] justify-center leading-[0] left-0 text-[#5e5e5e] text-[16px] text-left top-[8.5px] translate-y-[-50%] w-[51.055px]"
        style={{ fontVariationSettings: "'wdth' 100" }}
      >
        <p className="block leading-[normal]">Search</p>
      </div>
    </div>
  );
}

function Input1() {
  return (
    <div className="absolute bg-[#f8f8f8] inset-0" data-name="Input">
      <div className="overflow-clip relative size-full">
        <Container3 />
      </div>
      <div className="absolute border-2 border-[#5e5e5e] border-solid inset-0 pointer-events-none" />
    </div>
  );
}

function Img1() {
  return (
    <div className="absolute right-0 size-12 top-0" data-name="Img">
      <svg
        className="block size-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 48 48"
      >
        <g clipPath="url(#clip0_1_225)" id="search">
          <g id="Vector"></g>
          <path
            d={svgPaths.p26efbc80}
            fill="var(--fill-0, white)"
            id="Vector_2"
          />
        </g>
        <defs>
          <clipPath id="clip0_1_225">
            <rect fill="white" height="48" width="48" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Button1() {
  return (
    <div
      className="absolute bg-[#0065bd] left-[217px] size-12 top-0"
      data-name="Button"
    >
      <Img1 />
    </div>
  );
}

function Search2() {
  return (
    <div
      className="absolute h-12 left-[1247.5px] right-[392.5px] top-[185px]"
      data-name="Search"
    >
      <Input1 />
      <Button1 />
    </div>
  );
}

function ItemLink4() {
  return (
    <a
      className="absolute block h-12 left-0 overflow-visible right-[1039.66px] top-0"
      data-name="Item → Link"
      href="https://cobalt.sgdatacatalogue.net/datasets"
    >
      <div
        className="absolute flex flex-col font-['Roboto:Regular',_sans-serif] font-normal h-[17px] justify-center leading-[0] left-4 text-[16px] text-[rgba(0,0,0,0.87)] text-left top-[23.5px] tracking-[0.15px] translate-y-[-50%] w-[64.738px]"
        role="link"
        style={{ fontVariationSettings: "'wdth' 100" }}
        tabIndex="0"
      >
        <p className="adjustLetterSpacing block cursor-pointer leading-[32px]">
          Datasets
        </p>
      </div>
    </a>
  );
}

function ItemLink5() {
  return (
    <a
      className="absolute block h-12 left-[96.34px] overflow-visible right-[906.98px] top-0"
      data-name="Item → Link"
      href="https://cobalt.sgdatacatalogue.net/organisations"
    >
      <div
        className="absolute flex flex-col font-['Roboto:Regular',_sans-serif] font-normal h-[17px] justify-center leading-[0] left-4 text-[16px] text-[rgba(0,0,0,0.87)] text-left top-[23.5px] tracking-[0.15px] translate-y-[-50%] w-[101.036px]"
        role="link"
        style={{ fontVariationSettings: "'wdth' 100" }}
        tabIndex="0"
      >
        <p className="adjustLetterSpacing block cursor-pointer leading-[32px]">
          Organisations
        </p>
      </div>
    </a>
  );
}

function ItemLink6() {
  return (
    <a
      className="absolute block h-12 left-[229.02px] overflow-visible right-[816.28px] top-0"
      data-name="Item → Link"
      href="https://cobalt.sgdatacatalogue.net/themes"
    >
      <div
        className="absolute flex flex-col font-['Roboto:Regular',_sans-serif] font-normal h-[17px] justify-center leading-[0] left-4 text-[16px] text-[rgba(0,0,0,0.87)] text-left top-[23.5px] tracking-[0.15px] translate-y-[-50%] w-[59.08px]"
        role="link"
        style={{ fontVariationSettings: "'wdth' 100" }}
        tabIndex="0"
      >
        <p className="adjustLetterSpacing block cursor-pointer leading-[32px]">
          Themes
        </p>
      </div>
    </a>
  );
}

function ItemLink7() {
  return (
    <a
      className="absolute block h-12 left-[319.72px] overflow-visible right-[741.7px] top-0"
      data-name="Item → Link"
      href="https://cobalt.sgdatacatalogue.net/about"
    >
      <div
        className="absolute flex flex-col font-['Roboto:Regular',_sans-serif] font-normal h-[17px] justify-center leading-[0] left-4 text-[16px] text-[rgba(0,0,0,0.87)] text-left top-[23.5px] tracking-[0.15px] translate-y-[-50%] w-[43.3px]"
        role="link"
        style={{ fontVariationSettings: "'wdth' 100" }}
        tabIndex="0"
      >
        <p className="adjustLetterSpacing block cursor-pointer leading-[32px]">
          About
        </p>
      </div>
    </a>
  );
}

function ItemLink8() {
  return (
    <a
      className="absolute block h-12 left-[394.3px] overflow-visible right-[676.19px] top-0"
      data-name="Item → Link"
      href="https://cobalt.sgdatacatalogue.net/help"
    >
      <div
        className="absolute flex flex-col font-['Roboto:Regular',_sans-serif] font-normal h-[17px] justify-center leading-[0] left-4 text-[16px] text-[rgba(0,0,0,0.87)] text-left top-[23.5px] tracking-[0.15px] translate-y-[-50%] w-[33.812px]"
        role="link"
        style={{ fontVariationSettings: "'wdth' 100" }}
        tabIndex="0"
      >
        <p className="adjustLetterSpacing block cursor-pointer leading-[32px]">
          Help
        </p>
      </div>
    </a>
  );
}

function NavList() {
  return (
    <div
      className="absolute cursor-pointer h-12 left-[376.5px] right-[392.5px] top-px"
      data-name="Nav → List"
    >
      <ItemLink4 />
      <ItemLink5 />
      <ItemLink6 />
      <ItemLink7 />
      <ItemLink8 />
    </div>
  );
}

function HorizontalBorder() {
  return (
    <div
      className="absolute h-[49px] left-0 right-0 top-60"
      data-name="HorizontalBorder"
    >
      <div className="absolute border-[#ebebeb] border-[1px_0px_0px] border-solid inset-0 pointer-events-none" />
      <NavList />
    </div>
  );
}

function Strong1() {
  return (
    <div
      className="absolute bg-[#d9eeff] h-6 left-[392.5px] top-4 w-[57.69px]"
      data-name="Strong"
    >
      <div className="absolute inset-px" data-name="Strong:outline">
        <div className="absolute border border-[rgba(0,101,189,0.64)] border-solid inset-[-1px] pointer-events-none" />
      </div>
      <div
        className="absolute flex flex-col font-['Roboto:Regular',_sans-serif] font-normal h-[17px] justify-center leading-[0] left-2 text-[#00437d] text-[16px] text-left top-[11.5px] tracking-[0.15px] translate-y-[-50%] w-[42.017px]"
        style={{ fontVariationSettings: "'wdth' 100" }}
      >
        <p className="adjustLetterSpacing block leading-[24px]">Alpha</p>
      </div>
    </div>
  );
}

function Link11() {
  return (
    <div
      className="absolute h-[17px] left-[664.27px] top-[19px] w-[66.14px]"
      data-name="Link"
    >
      <a
        className="absolute flex flex-col font-['Roboto:Regular',_sans-serif] font-normal h-[17px] justify-center leading-[0] left-0 text-[#0065bd] text-[16px] text-left top-[8.5px] tracking-[0.15px] translate-y-[-50%] w-[66.645px]"
        href="mailto:statistics.opendata@gov.scot"
        style={{ fontVariationSettings: "'wdth' 100" }}
      >
        <p className="[text-decoration-line:underline] [text-decoration-style:solid] [text-underline-position:from-font] adjustLetterSpacing block cursor-pointer leading-[24px]">
          feedback
        </p>
      </a>
    </div>
  );
}

function Background1() {
  return (
    <div
      className="absolute bg-[#ebebeb] h-14 left-0 right-0 top-[289px]"
      data-name="Background"
    >
      <Strong1 />
      <div
        className="absolute flex flex-col font-['Roboto:Regular',_sans-serif] font-normal h-5 justify-center leading-[0] left-[466.19px] text-[16px] text-[rgba(0,0,0,0.87)] text-left top-[26px] tracking-[0.15px] translate-y-[-50%] w-[198.457px]"
        style={{ fontVariationSettings: "'wdth' 100" }}
      >
        <p className="adjustLetterSpacing block leading-[24px]">{`This is a new service. Your `}</p>
      </div>
      <Link11 />
      <div
        className="absolute flex flex-col font-['Roboto:Regular',_sans-serif] font-normal h-5 justify-center leading-[0] left-[730.41px] text-[16px] text-[rgba(0,0,0,0.87)] text-left top-[26px] tracking-[0.15px] translate-y-[-50%] w-[183.723px]"
        style={{ fontVariationSettings: "'wdth' 100" }}
      >
        <p className="adjustLetterSpacing block leading-[24px]">{` will help us to improve it.`}</p>
      </div>
    </div>
  );
}

function Banner() {
  return (
    <div
      className="absolute bg-[#ffffff] h-[173px] left-0 top-0 w-[1905px]"
      data-name="Banner"
    >
      <div className="absolute border-[#ebebeb] border-[0px_0px_1px] border-solid inset-0 pointer-events-none shadow-[0px_2px_4px_0px_rgba(0,0,0,0.1)]" />
      <div
        className="absolute h-1 left-0 right-0 top-[173px]"
        data-name="HorizontalBorder"
      >
        <div className="absolute border-[#0065bd] border-[4px_0px_0px] border-solid inset-0 pointer-events-none" />
      </div>
      <Container2 />
      <Search2 />
      <HorizontalBorder />
      <Background1 />
    </div>
  );
}

function Component1920WDefault() {
  return (
    <div
      className="absolute bg-[#ffffff] h-[1197.5px] left-[100px] right-[100px] top-[100px]"
      data-name="1920w default"
    >
      <Banner />
      <Container1 />
    </div>
  );
}

export default function HttpsCobaltSgdatacatalogueNetHomeByHtmlToDesignFreeVersion28062025123637Bst() {
  return (
    <div
      className="bg-[#ffffff] relative rounded-sm size-full"
      data-name="https://cobalt.sgdatacatalogue.net/home by html.to.design ❤️ FREE version - 28/06/2025, 12:36:37 BST"
    >
      <div className="overflow-clip relative size-full">
        <Component1920WDefault />
      </div>
      <div className="absolute border border-[rgba(0,0,0,0.1)] border-solid inset-0 pointer-events-none rounded-sm" />
    </div>
  );
}