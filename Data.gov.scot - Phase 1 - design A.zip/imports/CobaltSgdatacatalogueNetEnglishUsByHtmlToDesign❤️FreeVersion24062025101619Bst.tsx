import svgPaths from "./svg-lxv4opcm4j";

function Heading1() {
  return (
    <div
      className="basis-0 box-border content-stretch flex flex-col grow items-start justify-start min-h-px min-w-[250px] p-0 relative shrink-0"
      data-name="Heading 1"
    >
      <div
        className="flex flex-col font-['Roboto:Bold',_sans-serif] font-bold justify-center leading-[0] relative shrink-0 text-[44px] text-[rgba(0,0,0,0.87)] text-left tracking-[0.15px] w-full"
        style={{ fontVariationSettings: "'wdth' 100" }}
      >
        <p className="block leading-[56px]">Datasets</p>
      </div>
    </div>
  );
}

function Header() {
  return (
    <div
      className="[flex-flow:wrap] box-border content-center flex gap-0 items-center justify-start p-0 relative shrink-0 w-full"
      data-name="Header"
    >
      <Heading1 />
    </div>
  );
}

function Container() {
  return (
    <div
      className="absolute bottom-[4757px] box-border content-stretch flex flex-col items-start justify-start left-0 px-0 py-8 right-0 top-0"
      data-name="Container"
    >
      <Header />
    </div>
  );
}

function Heading3() {
  return (
    <div
      className="box-border content-stretch flex flex-col items-start justify-start pb-[7px] pt-2 px-0 relative shrink-0 w-full"
      data-name="Heading 3"
    >
      <div
        className="flex flex-col font-['Roboto:Bold',_sans-serif] font-bold justify-center leading-[0] relative shrink-0 text-[19px] text-[rgba(0,0,0,0.87)] text-left tracking-[0.15px] w-full"
        style={{ fontVariationSettings: "'wdth' 100" }}
      >
        <p className="block leading-[32px]">Search</p>
      </div>
    </div>
  );
}

function Container1() {
  return (
    <div
      className="absolute box-border content-stretch flex flex-col items-start justify-start left-3 overflow-clip pb-px pt-0 px-0 right-[73px] top-[15px]"
      data-name="Container"
    >
      <div
        className="flex flex-col font-['Roboto:Regular',_sans-serif] font-normal justify-center leading-[0] relative shrink-0 text-[#5e5e5e] text-[16px] text-left text-nowrap"
        style={{ fontVariationSettings: "'wdth' 100" }}
      >
        <p className="block leading-[normal] whitespace-pre">Search</p>
      </div>
    </div>
  );
}

function Container2() {
  return (
    <div
      className="basis-0 grow h-8 min-h-px min-w-px shrink-0"
      data-name="Container"
    />
  );
}

function Container3() {
  return (
    <div
      className="absolute box-border content-stretch flex flex-row items-center justify-center left-3 pl-0 pr-[15px] py-0 right-[58px] top-2"
      data-name="Container"
    >
      <Container2 />
    </div>
  );
}

function Input() {
  return (
    <div
      className="bg-[#f8f8f8] h-12 min-h-12 relative shrink-0 w-[352px]"
      data-name="Input"
    >
      <div className="h-12 overflow-clip relative w-[352px]">
        <Container1 />
        <Container3 />
      </div>
      <div className="absolute border-2 border-[#5e5e5e] border-solid inset-0 pointer-events-none" />
    </div>
  );
}

function InputMargin() {
  return (
    <div
      className="basis-0 box-border content-stretch flex flex-col grow items-start justify-center min-h-12 min-w-px p-0 relative self-stretch shrink-0"
      data-name="Input:margin"
    >
      <Input />
    </div>
  );
}

function Component1() {
  return (
    <div className="absolute right-0 size-12 top-0" data-name="Component 1">
      <svg
        className="block size-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 48 48"
      >
        <g id="Component 1">
          <path
            d={svgPaths.p26efbc80}
            fill="var(--fill-0, white)"
            id="Vector"
          />
        </g>
      </svg>
    </div>
  );
}

function Component2() {
  return (
    <div
      className="bg-[#0065bd] min-h-12 min-w-12 relative shrink-0 size-12"
      data-name="Component 2"
    >
      <Component1 />
    </div>
  );
}

function Search() {
  return (
    <div
      className="box-border content-stretch flex flex-row items-start justify-start p-0 relative shrink-0 w-full"
      data-name="Search"
    >
      <InputMargin />
      <Component2 />
    </div>
  );
}

function Heading4() {
  return (
    <div
      className="box-border content-stretch flex flex-col items-start justify-start pb-[7px] pt-2 px-0 relative shrink-0 w-full"
      data-name="Heading 3"
    >
      <div
        className="flex flex-col font-['Roboto:Bold',_sans-serif] font-bold justify-center leading-[0] relative shrink-0 text-[19px] text-[rgba(0,0,0,0.87)] text-left tracking-[0.15px] w-full"
        style={{ fontVariationSettings: "'wdth' 100" }}
      >
        <p className="block leading-[32px]">Filter by</p>
      </div>
    </div>
  );
}

function Input1() {
  return (
    <div
      className="absolute bg-[#ffffff] left-0 rounded-[2.5px] size-px top-px"
      data-name="Input"
    >
      <div className="absolute border border-[#767676] border-solid inset-0 pointer-events-none rounded-[2.5px]" />
    </div>
  );
}

function Heading5() {
  return (
    <div
      className="box-border content-stretch flex flex-col items-start justify-start p-0 relative shrink-0 w-full"
      data-name="Heading 3"
    >
      <div
        className="flex flex-col font-['Roboto:Bold',_sans-serif] font-bold justify-center leading-[0] relative shrink-0 text-[16px] text-[rgba(0,0,0,0.87)] text-left tracking-[0.15px] w-full"
        style={{ fontVariationSettings: "'wdth' 100" }}
      >
        <p className="block leading-[24px]">Organisation</p>
      </div>
    </div>
  );
}

function Component3() {
  return (
    <div
      className="bg-[#ffffff] relative shrink-0 w-full"
      data-name="Component 3"
    >
      <div className="relative size-full">
        <div className="box-border content-stretch flex flex-col items-start justify-start pb-[23px] pl-2 pr-4 pt-4 relative w-full">
          <Heading5 />
          <div className="absolute flex h-[16.971px] items-center justify-center right-[21.515px] top-[15.51px] w-[16.971px]">
            <div className="flex-none rotate-[45deg]">
              <div className="relative size-3" data-name="Border">
                <div className="absolute border-[#0065bd] border-[0px_3px_3px_0px] border-solid inset-0 pointer-events-none" />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function Border() {
  return (
    <div
      className="box-border content-stretch flex flex-col items-start justify-start mb-[-1px] px-0 py-px relative shrink-0 w-full"
      data-name="Border"
    >
      <div className="absolute border-[#b3b3b3] border-[1px_0px] border-solid inset-0 pointer-events-none" />
      <Input1 />
      <Component3 />
    </div>
  );
}

function Input2() {
  return (
    <div
      className="absolute bg-[#ffffff] left-0 rounded-[2.5px] size-px top-px"
      data-name="Input"
    >
      <div className="absolute border border-[#767676] border-solid inset-0 pointer-events-none rounded-[2.5px]" />
    </div>
  );
}

function Heading6() {
  return (
    <div
      className="box-border content-stretch flex flex-col items-start justify-start p-0 relative shrink-0 w-full"
      data-name="Heading 3"
    >
      <div
        className="flex flex-col font-['Roboto:Bold',_sans-serif] font-bold justify-center leading-[0] relative shrink-0 text-[16px] text-[rgba(0,0,0,0.87)] text-left tracking-[0.15px] w-full"
        style={{ fontVariationSettings: "'wdth' 100" }}
      >
        <p className="block leading-[24px]">Data Format</p>
      </div>
    </div>
  );
}

function Component8() {
  return (
    <div
      className="bg-[#ffffff] relative shrink-0 w-full"
      data-name="Component 3"
    >
      <div className="relative size-full">
        <div className="box-border content-stretch flex flex-col items-start justify-start pb-[23px] pl-2 pr-4 pt-4 relative w-full">
          <Heading6 />
          <div className="absolute flex h-[16.971px] items-center justify-center right-[21.515px] top-[15.51px] w-[16.971px]">
            <div className="flex-none rotate-[45deg]">
              <div className="relative size-3" data-name="Border">
                <div className="absolute border-[#0065bd] border-[0px_3px_3px_0px] border-solid inset-0 pointer-events-none" />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function Border1() {
  return (
    <div
      className="box-border content-stretch flex flex-col items-start justify-start mb-[-1px] px-0 py-px relative shrink-0 w-full"
      data-name="Border"
    >
      <div className="absolute border-[#b3b3b3] border-[1px_0px] border-solid inset-0 pointer-events-none" />
      <Input2 />
      <Component8 />
    </div>
  );
}

function Container4() {
  return (
    <div
      className="box-border content-stretch flex flex-col items-start justify-start pb-8 pt-0 px-0 relative shrink-0 w-full"
      data-name="Container"
    >
      <Border />
      <Border1 />
    </div>
  );
}

function Component4() {
  return (
    <div
      className="bg-[#0065bd] max-w-[480px] min-h-12 min-w-12 relative shrink-0 w-full"
      data-name="Component 4"
    >
      <div className="flex flex-row items-center justify-center max-w-inherit min-h-inherit min-w-inherit relative size-full">
        <div className="box-border content-stretch flex flex-row items-center justify-center max-w-inherit min-h-inherit min-w-inherit px-4 py-3 relative w-full">
          <div
            className="basis-0 flex flex-col font-['Roboto:Bold',_sans-serif] font-bold grow justify-center leading-[0] min-h-px min-w-px relative shrink-0 text-[#ffffff] text-[16px] text-center"
            style={{ fontVariationSettings: "'wdth' 100" }}
          >
            <p className="block leading-[24px]">Clear filters</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function Form() {
  return (
    <div
      className="box-border content-stretch flex flex-col items-start justify-start pb-0 pt-6 px-0 relative shrink-0 w-full"
      data-name="Form"
    >
      <Heading4 />
      <Container4 />
      <Component4 />
    </div>
  );
}

function Container5() {
  return (
    <div
      className="box-border content-stretch flex flex-col items-start justify-start p-0 relative shrink-0 w-full"
      data-name="Container"
    >
      <Heading3 />
      <Search />
      <Form />
    </div>
  );
}

function Container6() {
  return (
    <div
      className="absolute bottom-0 box-border content-stretch flex flex-col items-start justify-start left-0 p-0 right-[768px] top-[120px]"
      data-name="Container"
    >
      <Container5 />
    </div>
  );
}

function Heading2() {
  return (
    <div
      className="box-border content-stretch flex flex-col items-start justify-start p-0 relative shrink-0 w-full"
      data-name="Heading 2"
    >
      <div
        className="flex flex-col font-['Roboto:Regular',_sans-serif] font-normal justify-center leading-[0] relative shrink-0 text-[19px] text-[rgba(0,0,0,0.87)] text-left tracking-[0.15px] w-full"
        style={{ fontVariationSettings: "'wdth' 100" }}
      >
        <p className="block leading-[32px]">14 Datasets</p>
      </div>
    </div>
  );
}

function Separator() {
  return (
    <div className="h-px relative shrink-0 w-full" data-name="Separator">
      <div className="absolute border-[#b3b3b3] border-[1px_0px_0px] border-solid inset-0 pointer-events-none" />
    </div>
  );
}

function LabelMargin() {
  return (
    <div
      className="box-border content-stretch flex flex-col items-start justify-start p-0 relative shrink-0 w-[35.75px]"
      data-name="Label:margin"
    >
      <div
        className="flex flex-col font-['Roboto:Regular',_sans-serif] font-normal justify-center leading-[0] relative shrink-0 text-[#1a1a1a] text-[16px] text-left text-nowrap tracking-[0.15px]"
        style={{ fontVariationSettings: "'wdth' 100" }}
      >
        <p className="adjustLetterSpacing block leading-[24px] whitespace-pre">
          Sort by
        </p>
      </div>
    </div>
  );
}

function Container7() {
  return (
    <div
      className="box-border content-stretch flex flex-col items-start justify-start overflow-clip p-0 relative shrink-0 w-full"
      data-name="Container"
    >
      <div
        className="flex flex-col font-['Roboto:Regular',_sans-serif] font-normal justify-center leading-[0] relative shrink-0 text-[16px] text-[rgba(0,0,0,0.87)] text-left w-full"
        style={{ fontVariationSettings: "'wdth' 100" }}
      >
        <p className="block leading-[24px]">Most relevant</p>
      </div>
    </div>
  );
}

function Options() {
  return (
    <div
      className="bg-[rgba(255,255,255,0)] h-10 min-h-10 relative shrink-0 w-full"
      data-name="Options"
    >
      <div className="flex flex-col justify-center min-h-inherit overflow-clip relative size-full">
        <div className="box-border content-stretch flex flex-col h-10 items-start justify-center min-h-inherit pl-3 pr-12 py-1 relative w-full">
          <Container7 />
        </div>
      </div>
      <div className="absolute inset-0 pointer-events-none shadow-[0px_0px_0px_2px_inset_rgba(0,0,0,0.87)]" />
    </div>
  );
}

function Background() {
  return (
    <div
      className="absolute bg-[#0065bd] bottom-0 right-0 top-0 w-10"
      data-name="Background"
    >
      <div
        className="absolute flex h-[16.971px] items-center justify-center translate-x-[-50%] translate-y-[-50%] w-[16.971px]"
        style={{ top: "calc(50% - 3px)", left: "calc(50% - 0.00471378px)" }}
      >
        <div className="flex-none rotate-[315deg]">
          <div className="relative size-3" data-name="Border">
            <div className="absolute border-[#ffffff] border-[0px_0px_3px_3px] border-solid inset-0 pointer-events-none" />
          </div>
        </div>
      </div>
    </div>
  );
}

function Container8() {
  return (
    <div
      className="box-border content-stretch flex flex-col items-start justify-center min-w-40 p-0 relative shrink-0"
      data-name="Container"
    >
      <Options />
      <Background />
    </div>
  );
}

function Container9() {
  return (
    <div
      className="[flex-flow:wrap] box-border content-center flex gap-6 items-center justify-start pb-0 pt-[17px] px-0 relative shrink-0 w-full"
      data-name="Container"
    >
      <LabelMargin />
      <Container8 />
    </div>
  );
}

function Component5() {
  return (
    <div
      className="box-border content-stretch flex flex-row items-start justify-start p-0 relative shrink-0"
      data-name="Component 5"
    >
      <a
        className="[white-space-collapse:collapse] flex flex-col font-['Roboto:Bold',_sans-serif] font-bold justify-center leading-[0] relative shrink-0 text-[#0065bd] text-[22px] text-left text-nowrap tracking-[0.15px]"
        href="https://cobalt.sgdatacatalogue.net/dataset/deer-vehicle-collisions"
        style={{ fontVariationSettings: "'wdth' 100" }}
      >
        <p className="adjustLetterSpacing block cursor-pointer leading-[32px] whitespace-pre">
          Deer Vehicle Collisions
        </p>
      </a>
    </div>
  );
}

function Heading7() {
  return (
    <div
      className="box-border content-stretch flex flex-col items-start justify-start p-0 relative shrink-0 w-full"
      data-name="Heading 3"
    >
      <Component5 />
    </div>
  );
}

function Container10() {
  return (
    <div
      className="box-border content-stretch flex flex-col items-start justify-start p-0 relative shrink-0 w-full"
      data-name="Container"
    >
      <div
        className="flex flex-col font-['Roboto:Regular',_sans-serif] font-normal justify-center leading-[32px] relative shrink-0 text-[19px] text-[rgba(0,0,0,0.87)] text-left tracking-[0.15px] w-full"
        style={{ fontVariationSettings: "'wdth' 100" }}
      >
        <p className="block mb-0">
          Points showing the locations of traffic accidents involving deer
          (2008-2018). Data
        </p>
        <p className="block mb-0">
          collected by the National Deer-Vehicle Collisions Project
          www.deercollisions.co.uk - A
        </p>
        <p className="block">Project administered by The Deer Initiative</p>
      </div>
    </div>
  );
}

function Container11() {
  return (
    <div
      className="box-border content-stretch flex flex-row items-start justify-start p-0 relative shrink-0 w-[71.55px]"
      data-name="Container"
    >
      <div
        className="flex flex-col font-['Roboto:Regular',_sans-serif] font-normal justify-center leading-[0] relative shrink-0 text-[#5e5e5e] text-[14px] text-left text-nowrap tracking-[0.15px]"
        style={{ fontVariationSettings: "'wdth' 100" }}
      >
        <p className="adjustLetterSpacing block leading-[24px] whitespace-pre">
          NatureScot
        </p>
      </div>
    </div>
  );
}

function Container12() {
  return (
    <div
      className="box-border content-stretch flex flex-row items-start justify-start pl-2 pr-0 py-0 relative shrink-0 w-[108.89px]"
      data-name="Container"
    >
      <div
        className="flex flex-col font-['Roboto:Regular',_sans-serif] font-normal justify-center leading-[0] relative shrink-0 text-[#5e5e5e] text-[14px] text-left text-nowrap tracking-[0.15px]"
        style={{ fontVariationSettings: "'wdth' 100" }}
      >
        <p className="adjustLetterSpacing block leading-[24px] whitespace-pre">
          CSV, GeoJSON
        </p>
      </div>
      <div
        className="absolute bg-[#5e5e5e] h-[13px] left-0 top-1.5 w-px"
        data-name="Vertical Divider"
      />
    </div>
  );
}

function Descriptions() {
  return (
    <div className="relative shrink-0 w-full" data-name="Descriptions">
      <div className="flex flex-row justify-center overflow-clip relative size-full">
        <div className="box-border content-stretch flex flex-row gap-[3.5px] items-start justify-center pl-0 pr-[552.06px] py-0 relative w-full">
          <Container11 />
          <Container12 />
        </div>
      </div>
    </div>
  );
}

function Details() {
  return (
    <div
      className="basis-0 box-border content-stretch flex flex-row grow items-start justify-start min-h-px min-w-px p-0 relative shrink-0"
      data-name="Details"
    >
      <div
        className="basis-0 flex flex-col font-['Roboto:Regular',_sans-serif] font-normal grow justify-center leading-[0] min-h-px min-w-px relative shrink-0 text-[#5e5e5e] text-[14px] text-left tracking-[0.15px]"
        style={{ fontVariationSettings: "'wdth' 100" }}
      >
        <p className="block leading-[24px]">Last updated: 6/10/2025</p>
      </div>
    </div>
  );
}

function Container13() {
  return (
    <div
      className="box-border content-stretch flex flex-row items-start justify-start p-0 relative shrink-0 w-[154.48px]"
      data-name="Container"
    >
      <Details />
    </div>
  );
}

function Descriptions1() {
  return (
    <div
      className="box-border content-stretch flex flex-col items-start justify-start overflow-clip p-0 relative shrink-0 w-full"
      data-name="Descriptions"
    >
      <Container13 />
    </div>
  );
}

function Item() {
  return (
    <div
      className="box-border content-stretch flex flex-col gap-2 items-start justify-start pb-[23px] pt-0 px-0 relative shrink-0 w-full"
      data-name="Item"
    >
      <Heading7 />
      <Container10 />
      <Descriptions />
      <Descriptions1 />
    </div>
  );
}

function Component9() {
  return (
    <div
      className="box-border content-stretch flex flex-row items-start justify-start p-0 relative shrink-0"
      data-name="Component 5"
    >
      <a
        className="[white-space-collapse:collapse] flex flex-col font-['Roboto:Bold',_sans-serif] font-bold justify-center leading-[0] relative shrink-0 text-[#0065bd] text-[0px] text-left text-nowrap tracking-[0.15px]"
        href="https://cobalt.sgdatacatalogue.net/dataset/deer-vehicle-collisions"
        style={{ fontVariationSettings: "'wdth' 100" }}
      >
        <p
          className="adjustLetterSpacing block cursor-pointer leading-[32px] text-[22px] whitespace-pre"
          role="link"
          style={{ fontVariationSettings: "'wdth' 100" }}
          tabIndex="0"
        >
          2011 Data Zone Lookup - Archived Geographies
        </p>
      </a>
    </div>
  );
}

function Heading8() {
  return (
    <div
      className="box-border content-stretch flex flex-col items-start justify-start p-0 relative shrink-0 w-full"
      data-name="Heading 3"
    >
      <Component9 />
    </div>
  );
}

function Container14() {
  return (
    <div
      className="box-border content-stretch flex flex-col items-start justify-start p-0 relative shrink-0 w-full"
      data-name="Container"
    >
      <div
        className="flex flex-col font-['Roboto:Regular',_sans-serif] font-normal justify-center leading-[32px] relative shrink-0 text-[19px] text-[rgba(0,0,0,0.87)] text-left tracking-[0.15px] w-full"
        style={{ fontVariationSettings: "'wdth' 100" }}
      >
        <p className="block mb-0">
          As geography reference material, this file contains lookup
          information, showing how
        </p>
        <p className="block mb-0">
          2011 data zone geographic units can be aggregated to higher level
          archived
        </p>
        <p className="block mb-0">
          geographies. The compressed file includes a file with the archived
          geography codes
        </p>
        <p className="block mb-0">
          register containing dates between which each geography was valid and
          covers
        </p>
        <p className="block mb-0">
          changes to geographies made before 04/07/2024 - DataZone2011-Archived-
        </p>
        <p className="block">
          Geographies.csv. The geographies covered by this table are: (GSS code
          - Name...
        </p>
      </div>
    </div>
  );
}

function Container15() {
  return (
    <div
      className="box-border content-stretch flex flex-row items-start justify-start p-0 relative shrink-0 w-[133.58px]"
      data-name="Container"
    >
      <div
        className="flex flex-col font-['Roboto:Regular',_sans-serif] font-normal justify-center leading-[0] relative shrink-0 text-[#5e5e5e] text-[14px] text-left text-nowrap tracking-[0.15px]"
        style={{ fontVariationSettings: "'wdth' 100" }}
      >
        <p className="adjustLetterSpacing block leading-[24px] whitespace-pre">
          Scottish Government
        </p>
      </div>
    </div>
  );
}

function Container16() {
  return (
    <div
      className="box-border content-stretch flex flex-row items-start justify-start pl-2 pr-0 py-0 relative shrink-0 w-[37.25px]"
      data-name="Container"
    >
      <div
        className="flex flex-col font-['Roboto:Regular',_sans-serif] font-normal justify-center leading-[0] relative shrink-0 text-[#5e5e5e] text-[14px] text-left text-nowrap tracking-[0.15px]"
        style={{ fontVariationSettings: "'wdth' 100" }}
      >
        <p className="adjustLetterSpacing block leading-[24px] whitespace-pre">
          CSV
        </p>
      </div>
      <div
        className="absolute bg-[#5e5e5e] h-[13px] left-0 top-1.5 w-px"
        data-name="Vertical Divider"
      />
    </div>
  );
}

function Descriptions2() {
  return (
    <div className="relative shrink-0 w-full" data-name="Descriptions">
      <div className="flex flex-row justify-center overflow-clip relative size-full">
        <div className="box-border content-stretch flex flex-row gap-[3.5px] items-start justify-center pl-0 pr-[561.67px] py-0 relative w-full">
          <Container15 />
          <Container16 />
        </div>
      </div>
    </div>
  );
}

function Details1() {
  return (
    <div
      className="basis-0 box-border content-stretch flex flex-row grow items-start justify-start min-h-px min-w-px p-0 relative shrink-0"
      data-name="Details"
    >
      <div
        className="basis-0 flex flex-col font-['Roboto:Regular',_sans-serif] font-normal grow justify-center leading-[0] min-h-px min-w-px relative shrink-0 text-[#5e5e5e] text-[14px] text-left tracking-[0.15px]"
        style={{ fontVariationSettings: "'wdth' 100" }}
      >
        <p className="block leading-[24px]">Last updated: 5/29/2025</p>
      </div>
    </div>
  );
}

function Container17() {
  return (
    <div
      className="box-border content-stretch flex flex-row items-start justify-start p-0 relative shrink-0 w-[154.48px]"
      data-name="Container"
    >
      <Details1 />
    </div>
  );
}

function Descriptions3() {
  return (
    <div
      className="box-border content-stretch flex flex-col items-start justify-start overflow-clip p-0 relative shrink-0 w-full"
      data-name="Descriptions"
    >
      <Container17 />
    </div>
  );
}

function Item1() {
  return (
    <div
      className="box-border content-stretch flex flex-col gap-2 items-start justify-start pb-[23px] pt-[17px] px-0 relative shrink-0 w-full"
      data-name="Item"
    >
      <div className="absolute border-[#b3b3b3] border-[1px_0px_0px] border-solid inset-0 pointer-events-none" />
      <Heading8 />
      <Container14 />
      <Descriptions2 />
      <Descriptions3 />
    </div>
  );
}

function Component10() {
  return (
    <div
      className="box-border content-stretch flex flex-row items-start justify-start p-0 relative shrink-0"
      data-name="Component 5"
    >
      <a
        className="[white-space-collapse:collapse] flex flex-col font-['Roboto:Bold',_sans-serif] font-bold justify-center leading-[0] relative shrink-0 text-[#0065bd] text-[0px] text-left text-nowrap tracking-[0.15px]"
        href="https://cobalt.sgdatacatalogue.net/dataset/deer-vehicle-collisions"
        style={{ fontVariationSettings: "'wdth' 100" }}
      >
        <p
          className="adjustLetterSpacing block cursor-pointer leading-[32px] text-[22px] whitespace-pre"
          role="link"
          style={{ fontVariationSettings: "'wdth' 100" }}
          tabIndex="0"
        >
          Scottish Health Survey - Scotland Level Data by Sex
        </p>
      </a>
    </div>
  );
}

function Heading9() {
  return (
    <div
      className="box-border content-stretch flex flex-col items-start justify-start p-0 relative shrink-0 w-full"
      data-name="Heading 3"
    >
      <Component10 />
    </div>
  );
}

function Container18() {
  return (
    <div
      className="box-border content-stretch flex flex-col items-start justify-start p-0 relative shrink-0 w-full"
      data-name="Container"
    >
      <div
        className="flex flex-col font-['Roboto:Regular',_sans-serif] font-normal justify-center leading-[32px] relative shrink-0 text-[19px] text-[rgba(0,0,0,0.87)] text-left tracking-[0.15px] w-full"
        style={{ fontVariationSettings: "'wdth' 100" }}
      >
        <p className="block mb-0">
          The data presented here can also be viewed on an interactive
          dashboard. The
        </p>
        <p className="block mb-0">
          Scottish Health Survey (SHeS) has been carried out annually since 2008
          and prior to
        </p>
        <p className="block mb-0">
          this was carried out in 1995, 1998, and 2003. Commissioned by the
          Scottish
        </p>
        <p className="block mb-0">
          Government Health Directorates, the series provides regular
          information on aspects
        </p>
        <p className="block mb-0">
          of the public’s health and factors related to health which cannot be
          obtained from
        </p>
        <p className="block">other sources. The...</p>
      </div>
    </div>
  );
}

function Container19() {
  return (
    <div
      className="box-border content-stretch flex flex-row items-start justify-start p-0 relative shrink-0 w-[133.58px]"
      data-name="Container"
    >
      <div
        className="flex flex-col font-['Roboto:Regular',_sans-serif] font-normal justify-center leading-[0] relative shrink-0 text-[#5e5e5e] text-[14px] text-left text-nowrap tracking-[0.15px]"
        style={{ fontVariationSettings: "'wdth' 100" }}
      >
        <p className="adjustLetterSpacing block leading-[24px] whitespace-pre">
          Scottish Government
        </p>
      </div>
    </div>
  );
}

function Container20() {
  return (
    <div
      className="box-border content-stretch flex flex-row items-start justify-start pl-2 pr-0 py-0 relative shrink-0 w-[37.25px]"
      data-name="Container"
    >
      <div
        className="flex flex-col font-['Roboto:Regular',_sans-serif] font-normal justify-center leading-[0] relative shrink-0 text-[#5e5e5e] text-[14px] text-left text-nowrap tracking-[0.15px]"
        style={{ fontVariationSettings: "'wdth' 100" }}
      >
        <p className="adjustLetterSpacing block leading-[24px] whitespace-pre">
          CSV
        </p>
      </div>
      <div
        className="absolute bg-[#5e5e5e] h-[13px] left-0 top-1.5 w-px"
        data-name="Vertical Divider"
      />
    </div>
  );
}

function Descriptions4() {
  return (
    <div className="relative shrink-0 w-full" data-name="Descriptions">
      <div className="flex flex-row justify-center overflow-clip relative size-full">
        <div className="box-border content-stretch flex flex-row gap-[3.5px] items-start justify-center pl-0 pr-[561.67px] py-0 relative w-full">
          <Container19 />
          <Container20 />
        </div>
      </div>
    </div>
  );
}

function Details2() {
  return (
    <div
      className="basis-0 box-border content-stretch flex flex-row grow items-start justify-start min-h-px min-w-px p-0 relative shrink-0"
      data-name="Details"
    >
      <div
        className="basis-0 flex flex-col font-['Roboto:Regular',_sans-serif] font-normal grow justify-center leading-[0] min-h-px min-w-px relative shrink-0 text-[#5e5e5e] text-[14px] text-left tracking-[0.15px]"
        style={{ fontVariationSettings: "'wdth' 100" }}
      >
        <p className="block leading-[24px]">Last updated: 5/29/2025</p>
      </div>
    </div>
  );
}

function Container21() {
  return (
    <div
      className="box-border content-stretch flex flex-row items-start justify-start p-0 relative shrink-0 w-[154.48px]"
      data-name="Container"
    >
      <Details2 />
    </div>
  );
}

function Descriptions5() {
  return (
    <div
      className="box-border content-stretch flex flex-col items-start justify-start overflow-clip p-0 relative shrink-0 w-full"
      data-name="Descriptions"
    >
      <Container21 />
    </div>
  );
}

function Item2() {
  return (
    <div
      className="box-border content-stretch flex flex-col gap-2 items-start justify-start pb-[23px] pt-[17px] px-0 relative shrink-0 w-full"
      data-name="Item"
    >
      <div className="absolute border-[#b3b3b3] border-[1px_0px_0px] border-solid inset-0 pointer-events-none" />
      <Heading9 />
      <Container18 />
      <Descriptions4 />
      <Descriptions5 />
    </div>
  );
}

function Component11() {
  return (
    <div
      className="box-border content-stretch flex flex-row items-start justify-start p-0 relative shrink-0"
      data-name="Component 5"
    >
      <a
        className="[white-space-collapse:collapse] flex flex-col font-['Roboto:Bold',_sans-serif] font-bold justify-center leading-[0] relative shrink-0 text-[#0065bd] text-[0px] text-left text-nowrap tracking-[0.15px]"
        href="https://cobalt.sgdatacatalogue.net/dataset/deer-vehicle-collisions"
        style={{ fontVariationSettings: "'wdth' 100" }}
      >
        <p
          className="adjustLetterSpacing block cursor-pointer leading-[32px] text-[22px] whitespace-pre"
          role="link"
          style={{ fontVariationSettings: "'wdth' 100" }}
          tabIndex="0"
        >
          Scottish Accommodation Occupancy
        </p>
      </a>
    </div>
  );
}

function Heading10() {
  return (
    <div
      className="box-border content-stretch flex flex-col items-start justify-start p-0 relative shrink-0 w-full"
      data-name="Heading 3"
    >
      <Component11 />
    </div>
  );
}

function Container22() {
  return (
    <div
      className="box-border content-stretch flex flex-col items-start justify-start p-0 relative shrink-0 w-full"
      data-name="Container"
    >
      <div
        className="flex flex-col font-['Roboto:Regular',_sans-serif] font-normal justify-center leading-[32px] relative shrink-0 text-[19px] text-[rgba(0,0,0,0.87)] text-left tracking-[0.15px] w-full"
        style={{ fontVariationSettings: "'wdth' 100" }}
      >
        <p className="block mb-0">
          The Scottish Accommodation Occupancy Survey measures the occupancy of
          the
        </p>
        <p className="block mb-0">
          serviced and non-serviced tourist accommodation sector in Scotland.
          The survey is
        </p>
        <p className="block mb-0">
          optional and therefore is a sample of the tourism accommodation sector
          in Scotland.
        </p>
        <p className="block mb-0">
          Each accommodation provider fills out occupancy information on a
          monthly basis and
        </p>
        <p className="block">results are collated annually.</p>
      </div>
    </div>
  );
}

function Container23() {
  return (
    <div
      className="box-border content-stretch flex flex-row items-start justify-start p-0 relative shrink-0 w-[82.64px]"
      data-name="Container"
    >
      <div
        className="flex flex-col font-['Roboto:Regular',_sans-serif] font-normal justify-center leading-[0] relative shrink-0 text-[#5e5e5e] text-[14px] text-left text-nowrap tracking-[0.15px]"
        style={{ fontVariationSettings: "'wdth' 100" }}
      >
        <p className="adjustLetterSpacing block leading-[24px] whitespace-pre">
          VisitScotland
        </p>
      </div>
    </div>
  );
}

function Container24() {
  return (
    <div
      className="box-border content-stretch flex flex-row items-start justify-start pl-2 pr-0 py-0 relative shrink-0 w-[37.25px]"
      data-name="Container"
    >
      <div
        className="flex flex-col font-['Roboto:Regular',_sans-serif] font-normal justify-center leading-[0] relative shrink-0 text-[#5e5e5e] text-[14px] text-left text-nowrap tracking-[0.15px]"
        style={{ fontVariationSettings: "'wdth' 100" }}
      >
        <p className="adjustLetterSpacing block leading-[24px] whitespace-pre">
          CSV
        </p>
      </div>
      <div
        className="absolute bg-[#5e5e5e] h-[13px] left-0 top-1.5 w-px"
        data-name="Vertical Divider"
      />
    </div>
  );
}

function Descriptions6() {
  return (
    <div className="relative shrink-0 w-full" data-name="Descriptions">
      <div className="flex flex-row justify-center overflow-clip relative size-full">
        <div className="box-border content-stretch flex flex-row gap-[3.5px] items-start justify-center pl-0 pr-[612.61px] py-0 relative w-full">
          <Container23 />
          <Container24 />
        </div>
      </div>
    </div>
  );
}

function Details3() {
  return (
    <div
      className="basis-0 box-border content-stretch flex flex-row grow items-start justify-start min-h-px min-w-px p-0 relative shrink-0"
      data-name="Details"
    >
      <div
        className="basis-0 flex flex-col font-['Roboto:Regular',_sans-serif] font-normal grow justify-center leading-[0] min-h-px min-w-px relative shrink-0 text-[#5e5e5e] text-[14px] text-left tracking-[0.15px]"
        style={{ fontVariationSettings: "'wdth' 100" }}
      >
        <p className="block leading-[24px]">Last updated: 5/29/2025</p>
      </div>
    </div>
  );
}

function Container25() {
  return (
    <div
      className="box-border content-stretch flex flex-row items-start justify-start p-0 relative shrink-0 w-[154.48px]"
      data-name="Container"
    >
      <Details3 />
    </div>
  );
}

function Descriptions7() {
  return (
    <div
      className="box-border content-stretch flex flex-col items-start justify-start overflow-clip p-0 relative shrink-0 w-full"
      data-name="Descriptions"
    >
      <Container25 />
    </div>
  );
}

function Item3() {
  return (
    <div
      className="box-border content-stretch flex flex-col gap-2 items-start justify-start pb-[23px] pt-[17px] px-0 relative shrink-0 w-full"
      data-name="Item"
    >
      <div className="absolute border-[#b3b3b3] border-[1px_0px_0px] border-solid inset-0 pointer-events-none" />
      <Heading10 />
      <Container22 />
      <Descriptions6 />
      <Descriptions7 />
    </div>
  );
}

function Component12() {
  return (
    <div
      className="box-border content-stretch flex flex-row items-start justify-start p-0 relative shrink-0"
      data-name="Component 5"
    >
      <a
        className="[white-space-collapse:collapse] flex flex-col font-['Roboto:Bold',_sans-serif] font-bold justify-center leading-[0] relative shrink-0 text-[#0065bd] text-[0px] text-left text-nowrap tracking-[0.15px]"
        href="https://cobalt.sgdatacatalogue.net/dataset/deer-vehicle-collisions"
        style={{ fontVariationSettings: "'wdth' 100" }}
      >
        <p
          className="adjustLetterSpacing block cursor-pointer leading-[32px] text-[22px] whitespace-pre"
          role="link"
          style={{ fontVariationSettings: "'wdth' 100" }}
          tabIndex="0"
        >
          Primary 1 Children Body Mass Index - Clinical
        </p>
      </a>
    </div>
  );
}

function Heading11() {
  return (
    <div
      className="box-border content-stretch flex flex-col items-start justify-start p-0 relative shrink-0 w-full"
      data-name="Heading 3"
    >
      <Component12 />
    </div>
  );
}

function Container26() {
  return (
    <div
      className="box-border content-stretch flex flex-col items-start justify-start p-0 relative shrink-0 w-full"
      data-name="Container"
    >
      <div
        className="flex flex-col font-['Roboto:Regular',_sans-serif] font-normal justify-center leading-[32px] relative shrink-0 text-[19px] text-[rgba(0,0,0,0.87)] text-left text-nowrap tracking-[0.15px] w-full whitespace-pre"
        style={{ fontVariationSettings: "'wdth' 100" }}
      >
        <p className="block mb-0">
          Note: This dataset will not be receiving updates through this portal.
          Please refer to the
        </p>
        <p className="block mb-0">
          Public Health Scotland Open Data platform for the relevant data.
          Primary 1 Body
        </p>
        <p className="block mb-0">
          Mass Index (BMI) statistics capture important information of the
          growth of young
        </p>
        <p className="block mb-0">
          children. Clinical thresholds are used to define children with a level
          of under- or
        </p>
        <p className="block">
          overweight that may warrant clinical intervention, such as
          consideration of any...
        </p>
      </div>
    </div>
  );
}

function Container27() {
  return (
    <div
      className="box-border content-stretch flex flex-row items-start justify-start p-0 relative shrink-0 w-[144.17px]"
      data-name="Container"
    >
      <div
        className="flex flex-col font-['Roboto:Regular',_sans-serif] font-normal justify-center leading-[0] relative shrink-0 text-[#5e5e5e] text-[14px] text-left text-nowrap tracking-[0.15px]"
        style={{ fontVariationSettings: "'wdth' 100" }}
      >
        <p className="adjustLetterSpacing block leading-[24px] whitespace-pre">
          Public Health Scotland
        </p>
      </div>
    </div>
  );
}

function Container28() {
  return (
    <div
      className="box-border content-stretch flex flex-row items-start justify-start pl-2 pr-0 py-0 relative shrink-0 w-[37.25px]"
      data-name="Container"
    >
      <div
        className="flex flex-col font-['Roboto:Regular',_sans-serif] font-normal justify-center leading-[0] relative shrink-0 text-[#5e5e5e] text-[14px] text-left text-nowrap tracking-[0.15px]"
        style={{ fontVariationSettings: "'wdth' 100" }}
      >
        <p className="adjustLetterSpacing block leading-[24px] whitespace-pre">
          CSV
        </p>
      </div>
      <div
        className="absolute bg-[#5e5e5e] h-[13px] left-0 top-1.5 w-px"
        data-name="Vertical Divider"
      />
    </div>
  );
}

function Descriptions8() {
  return (
    <div className="relative shrink-0 w-full" data-name="Descriptions">
      <div className="flex flex-row justify-center overflow-clip relative size-full">
        <div className="box-border content-stretch flex flex-row gap-[3.5px] items-start justify-center pl-0 pr-[551.08px] py-0 relative w-full">
          <Container27 />
          <Container28 />
        </div>
      </div>
    </div>
  );
}

function Details4() {
  return (
    <div
      className="basis-0 box-border content-stretch flex flex-row grow items-start justify-start min-h-px min-w-px p-0 relative shrink-0"
      data-name="Details"
    >
      <div
        className="basis-0 flex flex-col font-['Roboto:Regular',_sans-serif] font-normal grow justify-center leading-[0] min-h-px min-w-px relative shrink-0 text-[#5e5e5e] text-[14px] text-left tracking-[0.15px]"
        style={{ fontVariationSettings: "'wdth' 100" }}
      >
        <p className="block leading-[24px]">Last updated: 5/29/2025</p>
      </div>
    </div>
  );
}

function Container29() {
  return (
    <div
      className="box-border content-stretch flex flex-row items-start justify-start p-0 relative shrink-0 w-[154.48px]"
      data-name="Container"
    >
      <Details4 />
    </div>
  );
}

function Descriptions9() {
  return (
    <div
      className="box-border content-stretch flex flex-col items-start justify-start overflow-clip p-0 relative shrink-0 w-full"
      data-name="Descriptions"
    >
      <Container29 />
    </div>
  );
}

function Item4() {
  return (
    <div
      className="box-border content-stretch flex flex-col gap-2 items-start justify-start pb-[23px] pt-[17px] px-0 relative shrink-0 w-full"
      data-name="Item"
    >
      <div className="absolute border-[#b3b3b3] border-[1px_0px_0px] border-solid inset-0 pointer-events-none" />
      <Heading11 />
      <Container26 />
      <Descriptions8 />
      <Descriptions9 />
    </div>
  );
}

function Component13() {
  return (
    <div
      className="box-border content-stretch flex flex-row items-start justify-start p-0 relative shrink-0"
      data-name="Component 5"
    >
      <a
        className="[white-space-collapse:collapse] flex flex-col font-['Roboto:Bold',_sans-serif] font-bold justify-center leading-[0] relative shrink-0 text-[#0065bd] text-[0px] text-left text-nowrap tracking-[0.15px]"
        href="https://cobalt.sgdatacatalogue.net/dataset/deer-vehicle-collisions"
        style={{ fontVariationSettings: "'wdth' 100" }}
      >
        <p
          className="adjustLetterSpacing block cursor-pointer leading-[32px] text-[22px] whitespace-pre"
          role="link"
          style={{ fontVariationSettings: "'wdth' 100" }}
          tabIndex="0"
        >
          Population Estimates: Young and Old
        </p>
      </a>
    </div>
  );
}

function Heading12() {
  return (
    <div
      className="box-border content-stretch flex flex-col items-start justify-start p-0 relative shrink-0 w-full"
      data-name="Heading 3"
    >
      <Component13 />
    </div>
  );
}

function Container30() {
  return (
    <div
      className="box-border content-stretch flex flex-col items-start justify-start p-0 relative shrink-0 w-full"
      data-name="Container"
    >
      <div
        className="flex flex-col font-['Roboto:Regular',_sans-serif] font-normal justify-center leading-[32px] relative shrink-0 text-[19px] text-[rgba(0,0,0,0.87)] text-left tracking-[0.15px] w-full"
        style={{ fontVariationSettings: "'wdth' 100" }}
      >
        <p className="block mb-0">
          This dataset presents population estimates for people who are young
          (under 16
        </p>
        <p className="block mb-0">
          years), old (70 years and over) and very old (85 years and over).
          Population
        </p>
        <p className="block mb-0">
          estimates for mid-2012 to mid-2022 have been revised following
          Scotland’s Census
        </p>
        <p className="block mb-0">
          2022. For more information on population statistics, please see the
          NRS website.
        </p>
        <p className="block">
          Small area population population estimates are available on the NRS
          website.
        </p>
      </div>
    </div>
  );
}

function Container31() {
  return (
    <div
      className="box-border content-stretch flex flex-row items-start justify-start p-0 relative shrink-0 w-[185.53px]"
      data-name="Container"
    >
      <div
        className="flex flex-col font-['Roboto:Regular',_sans-serif] font-normal justify-center leading-[0] relative shrink-0 text-[#5e5e5e] text-[14px] text-left text-nowrap tracking-[0.15px]"
        style={{ fontVariationSettings: "'wdth' 100" }}
      >
        <p className="adjustLetterSpacing block leading-[24px] whitespace-pre">
          National Records of Scotland
        </p>
      </div>
    </div>
  );
}

function Container32() {
  return (
    <div
      className="box-border content-stretch flex flex-row items-start justify-start pl-2 pr-0 py-0 relative shrink-0 w-[37.25px]"
      data-name="Container"
    >
      <div
        className="flex flex-col font-['Roboto:Regular',_sans-serif] font-normal justify-center leading-[0] relative shrink-0 text-[#5e5e5e] text-[14px] text-left text-nowrap tracking-[0.15px]"
        style={{ fontVariationSettings: "'wdth' 100" }}
      >
        <p className="adjustLetterSpacing block leading-[24px] whitespace-pre">
          CSV
        </p>
      </div>
      <div
        className="absolute bg-[#5e5e5e] h-[13px] left-0 top-1.5 w-px"
        data-name="Vertical Divider"
      />
    </div>
  );
}

function Descriptions10() {
  return (
    <div className="relative shrink-0 w-full" data-name="Descriptions">
      <div className="flex flex-row justify-center overflow-clip relative size-full">
        <div className="box-border content-stretch flex flex-row gap-[3.5px] items-start justify-center pl-0 pr-[509.72px] py-0 relative w-full">
          <Container31 />
          <Container32 />
        </div>
      </div>
    </div>
  );
}

function Details5() {
  return (
    <div
      className="basis-0 box-border content-stretch flex flex-row grow items-start justify-start min-h-px min-w-px p-0 relative shrink-0"
      data-name="Details"
    >
      <div
        className="basis-0 flex flex-col font-['Roboto:Regular',_sans-serif] font-normal grow justify-center leading-[0] min-h-px min-w-px relative shrink-0 text-[#5e5e5e] text-[14px] text-left tracking-[0.15px]"
        style={{ fontVariationSettings: "'wdth' 100" }}
      >
        <p className="block leading-[24px]">Last updated: 5/29/2025</p>
      </div>
    </div>
  );
}

function Container33() {
  return (
    <div
      className="box-border content-stretch flex flex-row items-start justify-start p-0 relative shrink-0 w-[154.48px]"
      data-name="Container"
    >
      <Details5 />
    </div>
  );
}

function Descriptions11() {
  return (
    <div
      className="box-border content-stretch flex flex-col items-start justify-start overflow-clip p-0 relative shrink-0 w-full"
      data-name="Descriptions"
    >
      <Container33 />
    </div>
  );
}

function Item5() {
  return (
    <div
      className="box-border content-stretch flex flex-col gap-2 items-start justify-start pb-[23px] pt-[17px] px-0 relative shrink-0 w-full"
      data-name="Item"
    >
      <div className="absolute border-[#b3b3b3] border-[1px_0px_0px] border-solid inset-0 pointer-events-none" />
      <Heading12 />
      <Container30 />
      <Descriptions10 />
      <Descriptions11 />
    </div>
  );
}

function Component14() {
  return (
    <div
      className="box-border content-stretch flex flex-row items-start justify-start p-0 relative shrink-0"
      data-name="Component 5"
    >
      <a
        className="[white-space-collapse:collapse] flex flex-col font-['Roboto:Bold',_sans-serif] font-bold justify-center leading-[0] relative shrink-0 text-[#0065bd] text-[0px] text-left text-nowrap tracking-[0.15px]"
        href="https://cobalt.sgdatacatalogue.net/dataset/deer-vehicle-collisions"
        style={{ fontVariationSettings: "'wdth' 100" }}
      >
        <p
          className="adjustLetterSpacing block cursor-pointer leading-[32px] text-[22px] whitespace-pre"
          role="link"
          style={{ fontVariationSettings: "'wdth' 100" }}
          tabIndex="0"
        >
          House Prices - Residential Properties Sales and Price
        </p>
      </a>
    </div>
  );
}

function Heading13() {
  return (
    <div
      className="box-border content-stretch flex flex-col items-start justify-start p-0 relative shrink-0 w-full"
      data-name="Heading 3"
    >
      <Component14 />
    </div>
  );
}

function Container34() {
  return (
    <div
      className="box-border content-stretch flex flex-col items-start justify-start p-0 relative shrink-0 w-full"
      data-name="Container"
    >
      <div
        className="flex flex-col font-['Roboto:Regular',_sans-serif] font-normal justify-center leading-[32px] relative shrink-0 text-[19px] text-[rgba(0,0,0,0.87)] text-left tracking-[0.15px] w-full"
        style={{ fontVariationSettings: "'wdth' 100" }}
      >
        <p className="block mb-0">
          The statistics include all market value sales in Scotland, based on
          the date of
        </p>
        <p className="block mb-0">
          registration with Registers of Scotland. Areas with less than 5 sales
          have had the
        </p>
        <p className="block mb-0">
          value of sales suppressed to help minimise the risk of data disclosure
          and to ensure
        </p>
        <p className="block mb-0">
          that any averages presented are based on at least 5 records. For the
          most up to date
        </p>
        <p className="block">Scotland and Local Authority figures...</p>
      </div>
    </div>
  );
}

function Container35() {
  return (
    <div
      className="box-border content-stretch flex flex-row items-start justify-start p-0 relative shrink-0 w-[136.23px]"
      data-name="Container"
    >
      <div
        className="flex flex-col font-['Roboto:Regular',_sans-serif] font-normal justify-center leading-[0] relative shrink-0 text-[#5e5e5e] text-[14px] text-left text-nowrap tracking-[0.15px]"
        style={{ fontVariationSettings: "'wdth' 100" }}
      >
        <p className="adjustLetterSpacing block leading-[24px] whitespace-pre">
          Registers of Scotland
        </p>
      </div>
    </div>
  );
}

function Container36() {
  return (
    <div
      className="box-border content-stretch flex flex-row items-start justify-start pl-2 pr-0 py-0 relative shrink-0 w-[37.25px]"
      data-name="Container"
    >
      <div
        className="flex flex-col font-['Roboto:Regular',_sans-serif] font-normal justify-center leading-[0] relative shrink-0 text-[#5e5e5e] text-[14px] text-left text-nowrap tracking-[0.15px]"
        style={{ fontVariationSettings: "'wdth' 100" }}
      >
        <p className="adjustLetterSpacing block leading-[24px] whitespace-pre">
          CSV
        </p>
      </div>
      <div
        className="absolute bg-[#5e5e5e] h-[13px] left-0 top-1.5 w-px"
        data-name="Vertical Divider"
      />
    </div>
  );
}

function Descriptions12() {
  return (
    <div className="relative shrink-0 w-full" data-name="Descriptions">
      <div className="flex flex-row justify-center overflow-clip relative size-full">
        <div className="box-border content-stretch flex flex-row gap-[3.5px] items-start justify-center pl-0 pr-[559.02px] py-0 relative w-full">
          <Container35 />
          <Container36 />
        </div>
      </div>
    </div>
  );
}

function Details6() {
  return (
    <div
      className="basis-0 box-border content-stretch flex flex-row grow items-start justify-start min-h-px min-w-px p-0 relative shrink-0"
      data-name="Details"
    >
      <div
        className="basis-0 flex flex-col font-['Roboto:Regular',_sans-serif] font-normal grow justify-center leading-[0] min-h-px min-w-px relative shrink-0 text-[#5e5e5e] text-[14px] text-left tracking-[0.15px]"
        style={{ fontVariationSettings: "'wdth' 100" }}
      >
        <p className="block leading-[24px]">Last updated: 5/29/2025</p>
      </div>
    </div>
  );
}

function Container37() {
  return (
    <div
      className="box-border content-stretch flex flex-row items-start justify-start p-0 relative shrink-0 w-[154.48px]"
      data-name="Container"
    >
      <Details6 />
    </div>
  );
}

function Descriptions13() {
  return (
    <div
      className="box-border content-stretch flex flex-col items-start justify-start overflow-clip p-0 relative shrink-0 w-full"
      data-name="Descriptions"
    >
      <Container37 />
    </div>
  );
}

function Item6() {
  return (
    <div
      className="box-border content-stretch flex flex-col gap-2 items-start justify-start pb-[23px] pt-[17px] px-0 relative shrink-0 w-full"
      data-name="Item"
    >
      <div className="absolute border-[#b3b3b3] border-[1px_0px_0px] border-solid inset-0 pointer-events-none" />
      <Heading13 />
      <Container34 />
      <Descriptions12 />
      <Descriptions13 />
    </div>
  );
}

function Component15() {
  return (
    <div
      className="box-border content-stretch flex flex-row items-start justify-start p-0 relative shrink-0"
      data-name="Component 5"
    >
      <a
        className="[white-space-collapse:collapse] flex flex-col font-['Roboto:Bold',_sans-serif] font-bold justify-center leading-[0] relative shrink-0 text-[#0065bd] text-[0px] text-left text-nowrap tracking-[0.15px]"
        href="https://cobalt.sgdatacatalogue.net/dataset/deer-vehicle-collisions"
        style={{ fontVariationSettings: "'wdth' 100" }}
      >
        <p
          className="adjustLetterSpacing block cursor-pointer leading-[32px] text-[22px] whitespace-pre"
          role="link"
          style={{ fontVariationSettings: "'wdth' 100" }}
          tabIndex="0"
        >
          Carbon Footprint Breakdown
        </p>
      </a>
    </div>
  );
}

function Heading14() {
  return (
    <div
      className="box-border content-stretch flex flex-col items-start justify-start p-0 relative shrink-0 w-full"
      data-name="Heading 3"
    >
      <Component15 />
    </div>
  );
}

function Container38() {
  return (
    <div
      className="box-border content-stretch flex flex-col items-start justify-start p-0 relative shrink-0 w-full"
      data-name="Container"
    >
      <div
        className="flex flex-col font-['Roboto:Regular',_sans-serif] font-normal justify-center leading-[32px] relative shrink-0 text-[19px] text-[rgba(0,0,0,0.87)] text-left tracking-[0.15px] w-full"
        style={{ fontVariationSettings: "'wdth' 100" }}
      >
        <p className="block mb-0">
          These are sometimes referred to “consumption emissions”. Scotland’s
          carbon
        </p>
        <p className="block mb-0">
          footprint is associated with the spending of Scottish residents on
          goods and services,
        </p>
        <p className="block mb-0">
          wherever in the world these emissions arise along the supply chain,
          and those which
        </p>
        <p className="block mb-0">
          are directly generated by Scottish households through private motoring
          and heating.
        </p>
        <p className="block mb-0">
          The purpose of this dataset is to find out what effect Scottish
          consumption has on
        </p>
        <p className="block">greenhouse gas emissions,...</p>
      </div>
    </div>
  );
}

function Container39() {
  return (
    <div
      className="box-border content-stretch flex flex-row items-start justify-start p-0 relative shrink-0 w-[133.58px]"
      data-name="Container"
    >
      <div
        className="flex flex-col font-['Roboto:Regular',_sans-serif] font-normal justify-center leading-[0] relative shrink-0 text-[#5e5e5e] text-[14px] text-left text-nowrap tracking-[0.15px]"
        style={{ fontVariationSettings: "'wdth' 100" }}
      >
        <p className="adjustLetterSpacing block leading-[24px] whitespace-pre">
          Scottish Government
        </p>
      </div>
    </div>
  );
}

function Container40() {
  return (
    <div
      className="box-border content-stretch flex flex-row items-start justify-start pl-2 pr-0 py-0 relative shrink-0 w-[37.25px]"
      data-name="Container"
    >
      <div
        className="flex flex-col font-['Roboto:Regular',_sans-serif] font-normal justify-center leading-[0] relative shrink-0 text-[#5e5e5e] text-[14px] text-left text-nowrap tracking-[0.15px]"
        style={{ fontVariationSettings: "'wdth' 100" }}
      >
        <p className="adjustLetterSpacing block leading-[24px] whitespace-pre">
          CSV
        </p>
      </div>
      <div
        className="absolute bg-[#5e5e5e] h-[13px] left-0 top-1.5 w-px"
        data-name="Vertical Divider"
      />
    </div>
  );
}

function Descriptions14() {
  return (
    <div className="relative shrink-0 w-full" data-name="Descriptions">
      <div className="flex flex-row justify-center overflow-clip relative size-full">
        <div className="box-border content-stretch flex flex-row gap-[3.5px] items-start justify-center pl-0 pr-[561.67px] py-0 relative w-full">
          <Container39 />
          <Container40 />
        </div>
      </div>
    </div>
  );
}

function Details7() {
  return (
    <div
      className="basis-0 box-border content-stretch flex flex-row grow items-start justify-start min-h-px min-w-px p-0 relative shrink-0"
      data-name="Details"
    >
      <div
        className="basis-0 flex flex-col font-['Roboto:Regular',_sans-serif] font-normal grow justify-center leading-[0] min-h-px min-w-px relative shrink-0 text-[#5e5e5e] text-[14px] text-left tracking-[0.15px]"
        style={{ fontVariationSettings: "'wdth' 100" }}
      >
        <p className="block leading-[24px]">Last updated: 5/29/2025</p>
      </div>
    </div>
  );
}

function Container41() {
  return (
    <div
      className="box-border content-stretch flex flex-row items-start justify-start p-0 relative shrink-0 w-[154.48px]"
      data-name="Container"
    >
      <Details7 />
    </div>
  );
}

function Descriptions15() {
  return (
    <div
      className="box-border content-stretch flex flex-col items-start justify-start overflow-clip p-0 relative shrink-0 w-full"
      data-name="Descriptions"
    >
      <Container41 />
    </div>
  );
}

function Item7() {
  return (
    <div
      className="box-border content-stretch flex flex-col gap-2 items-start justify-start pb-[23px] pt-[17px] px-0 relative shrink-0 w-full"
      data-name="Item"
    >
      <div className="absolute border-[#b3b3b3] border-[1px_0px_0px] border-solid inset-0 pointer-events-none" />
      <Heading14 />
      <Container38 />
      <Descriptions14 />
      <Descriptions15 />
    </div>
  );
}

function Component16() {
  return (
    <div
      className="box-border content-stretch flex flex-row items-start justify-start p-0 relative shrink-0"
      data-name="Component 5"
    >
      <a
        className="[white-space-collapse:collapse] flex flex-col font-['Roboto:Bold',_sans-serif] font-bold justify-center leading-[0] relative shrink-0 text-[#0065bd] text-[0px] text-left text-nowrap tracking-[0.15px]"
        href="https://cobalt.sgdatacatalogue.net/dataset/deer-vehicle-collisions"
        style={{ fontVariationSettings: "'wdth' 100" }}
      >
        <p
          className="adjustLetterSpacing block cursor-pointer leading-[32px] text-[22px] whitespace-pre"
          role="link"
          style={{ fontVariationSettings: "'wdth' 100" }}
          tabIndex="0"
        >
          Gender Pay Gap Scotland
        </p>
      </a>
    </div>
  );
}

function Heading15() {
  return (
    <div
      className="box-border content-stretch flex flex-col items-start justify-start p-0 relative shrink-0 w-full"
      data-name="Heading 3"
    >
      <Component16 />
    </div>
  );
}

function Container42() {
  return (
    <div
      className="box-border content-stretch flex flex-col items-start justify-start p-0 relative shrink-0 w-full"
      data-name="Container"
    >
      <div
        className="flex flex-col font-['Roboto:Regular',_sans-serif] font-normal justify-center leading-[32px] relative shrink-0 text-[19px] text-[rgba(0,0,0,0.87)] text-left tracking-[0.15px] w-full"
        style={{ fontVariationSettings: "'wdth' 100" }}
      >
        <p className="block mb-0">
          This indicator measures the difference between male and female median
          earnings
        </p>
        <p className="block mb-0">
          (gross hourly earnings excluding overtime), expressed as a percentage
          of male
        </p>
        <p className="block mb-0">
          earnings. Estimates are workplace based and cover employees on adult
          rates whose
        </p>
        <p className="block mb-0">
          pay for the survey pay-period was not affected by absence. The median
          and mean
        </p>
        <p className="block mb-0">{`gross weekly earnings (before deductions for Tax & National Insurance) of full-time`}</p>
        <p className="block">employees on adult rates, whose...</p>
      </div>
    </div>
  );
}

function Container43() {
  return (
    <div
      className="box-border content-stretch flex flex-row items-start justify-start p-0 relative shrink-0 w-[133.58px]"
      data-name="Container"
    >
      <div
        className="flex flex-col font-['Roboto:Regular',_sans-serif] font-normal justify-center leading-[0] relative shrink-0 text-[#5e5e5e] text-[14px] text-left text-nowrap tracking-[0.15px]"
        style={{ fontVariationSettings: "'wdth' 100" }}
      >
        <p className="adjustLetterSpacing block leading-[24px] whitespace-pre">
          Scottish Government
        </p>
      </div>
    </div>
  );
}

function Container44() {
  return (
    <div
      className="box-border content-stretch flex flex-row items-start justify-start pl-2 pr-0 py-0 relative shrink-0 w-[37.25px]"
      data-name="Container"
    >
      <div
        className="flex flex-col font-['Roboto:Regular',_sans-serif] font-normal justify-center leading-[0] relative shrink-0 text-[#5e5e5e] text-[14px] text-left text-nowrap tracking-[0.15px]"
        style={{ fontVariationSettings: "'wdth' 100" }}
      >
        <p className="adjustLetterSpacing block leading-[24px] whitespace-pre">
          CSV
        </p>
      </div>
      <div
        className="absolute bg-[#5e5e5e] h-[13px] left-0 top-1.5 w-px"
        data-name="Vertical Divider"
      />
    </div>
  );
}

function Descriptions16() {
  return (
    <div className="relative shrink-0 w-full" data-name="Descriptions">
      <div className="flex flex-row justify-center overflow-clip relative size-full">
        <div className="box-border content-stretch flex flex-row gap-[3.5px] items-start justify-center pl-0 pr-[561.67px] py-0 relative w-full">
          <Container43 />
          <Container44 />
        </div>
      </div>
    </div>
  );
}

function Details8() {
  return (
    <div
      className="basis-0 box-border content-stretch flex flex-row grow items-start justify-start min-h-px min-w-px p-0 relative shrink-0"
      data-name="Details"
    >
      <div
        className="basis-0 flex flex-col font-['Roboto:Regular',_sans-serif] font-normal grow justify-center leading-[0] min-h-px min-w-px relative shrink-0 text-[#5e5e5e] text-[14px] text-left tracking-[0.15px]"
        style={{ fontVariationSettings: "'wdth' 100" }}
      >
        <p className="block leading-[24px]">Last updated: 5/22/2025</p>
      </div>
    </div>
  );
}

function Container45() {
  return (
    <div
      className="box-border content-stretch flex flex-row items-start justify-start p-0 relative shrink-0 w-[154.48px]"
      data-name="Container"
    >
      <Details8 />
    </div>
  );
}

function Descriptions17() {
  return (
    <div
      className="box-border content-stretch flex flex-col items-start justify-start overflow-clip p-0 relative shrink-0 w-full"
      data-name="Descriptions"
    >
      <Container45 />
    </div>
  );
}

function Item8() {
  return (
    <div
      className="box-border content-stretch flex flex-col gap-2 items-start justify-start pb-[23px] pt-[17px] px-0 relative shrink-0 w-full"
      data-name="Item"
    >
      <div className="absolute border-[#b3b3b3] border-[1px_0px_0px] border-solid inset-0 pointer-events-none" />
      <Heading15 />
      <Container42 />
      <Descriptions16 />
      <Descriptions17 />
    </div>
  );
}

function Component17() {
  return (
    <div
      className="box-border content-stretch flex flex-row items-start justify-start p-0 relative shrink-0"
      data-name="Component 5"
    >
      <a
        className="[white-space-collapse:collapse] flex flex-col font-['Roboto:Bold',_sans-serif] font-bold justify-center leading-[0] relative shrink-0 text-[#0065bd] text-[0px] text-left text-nowrap tracking-[0.15px]"
        href="https://cobalt.sgdatacatalogue.net/dataset/deer-vehicle-collisions"
        style={{ fontVariationSettings: "'wdth' 100" }}
      >
        <p
          className="adjustLetterSpacing block cursor-pointer leading-[32px] text-[22px] whitespace-pre"
          role="link"
          style={{ fontVariationSettings: "'wdth' 100" }}
          tabIndex="0"
        >
          Deaths involving coronavirus (COVID-19)
        </p>
      </a>
    </div>
  );
}

function Heading16() {
  return (
    <div
      className="box-border content-stretch flex flex-col items-start justify-start p-0 relative shrink-0 w-full"
      data-name="Heading 3"
    >
      <Component17 />
    </div>
  );
}

function Container46() {
  return (
    <div
      className="box-border content-stretch flex flex-col items-start justify-start p-0 relative shrink-0 w-full"
      data-name="Container"
    >
      <div
        className="flex flex-col font-['Roboto:Regular',_sans-serif] font-normal justify-center leading-[32px] relative shrink-0 text-[19px] text-[rgba(0,0,0,0.87)] text-left tracking-[0.15px] w-full"
        style={{ fontVariationSettings: "'wdth' 100" }}
      >
        <p className="block mb-0">
          This dataset presents the weekly, and year to date, provisional number
          of deaths
        </p>
        <p className="block mb-0">
          associated with coronavirus (COVID-19) alongside the total number of
          deaths
        </p>
        <p className="block mb-0">
          registered in Scotland, broken down by age, sex. Tables and commentary
          for this
        </p>
        <p className="block mb-0">
          publication are also available on the NRS website. Deaths involving
          COVID-19
        </p>
        <p className="block mb-0">
          include any deaths where COVID-19 is mentioned on the death
          certificate, whether it
        </p>
        <p className="block">is the underlying cause of death...</p>
      </div>
    </div>
  );
}

function Container47() {
  return (
    <div
      className="box-border content-stretch flex flex-row items-start justify-start p-0 relative shrink-0 w-[185.53px]"
      data-name="Container"
    >
      <div
        className="flex flex-col font-['Roboto:Regular',_sans-serif] font-normal justify-center leading-[0] relative shrink-0 text-[#5e5e5e] text-[14px] text-left text-nowrap tracking-[0.15px]"
        style={{ fontVariationSettings: "'wdth' 100" }}
      >
        <p className="adjustLetterSpacing block leading-[24px] whitespace-pre">
          National Records of Scotland
        </p>
      </div>
    </div>
  );
}

function Container48() {
  return (
    <div
      className="box-border content-stretch flex flex-row items-start justify-start pl-2 pr-0 py-0 relative shrink-0 w-[37.25px]"
      data-name="Container"
    >
      <div
        className="flex flex-col font-['Roboto:Regular',_sans-serif] font-normal justify-center leading-[0] relative shrink-0 text-[#5e5e5e] text-[14px] text-left text-nowrap tracking-[0.15px]"
        style={{ fontVariationSettings: "'wdth' 100" }}
      >
        <p className="adjustLetterSpacing block leading-[24px] whitespace-pre">
          CSV
        </p>
      </div>
      <div
        className="absolute bg-[#5e5e5e] h-[13px] left-0 top-1.5 w-px"
        data-name="Vertical Divider"
      />
    </div>
  );
}

function Descriptions18() {
  return (
    <div className="relative shrink-0 w-full" data-name="Descriptions">
      <div className="flex flex-row justify-center overflow-clip relative size-full">
        <div className="box-border content-stretch flex flex-row gap-[3.5px] items-start justify-center pl-0 pr-[509.72px] py-0 relative w-full">
          <Container47 />
          <Container48 />
        </div>
      </div>
    </div>
  );
}

function Details9() {
  return (
    <div
      className="basis-0 box-border content-stretch flex flex-row grow items-start justify-start min-h-px min-w-px p-0 relative shrink-0"
      data-name="Details"
    >
      <div
        className="basis-0 flex flex-col font-['Roboto:Regular',_sans-serif] font-normal grow justify-center leading-[0] min-h-px min-w-px relative shrink-0 text-[#5e5e5e] text-[14px] text-left tracking-[0.15px]"
        style={{ fontVariationSettings: "'wdth' 100" }}
      >
        <p className="block leading-[24px]">Last updated: 3/18/2025</p>
      </div>
    </div>
  );
}

function Container49() {
  return (
    <div
      className="box-border content-stretch flex flex-row items-start justify-start p-0 relative shrink-0 w-[154.48px]"
      data-name="Container"
    >
      <Details9 />
    </div>
  );
}

function Descriptions19() {
  return (
    <div
      className="box-border content-stretch flex flex-col items-start justify-start overflow-clip p-0 relative shrink-0 w-full"
      data-name="Descriptions"
    >
      <Container49 />
    </div>
  );
}

function Component18() {
  return (
    <div
      className="bg-[#d9effc] box-border content-stretch flex flex-col items-start justify-start px-4 py-2 relative rounded self-stretch shrink-0"
      data-name="Component 5"
    >
      <div
        className="flex flex-col font-['Roboto:Medium',_sans-serif] font-medium justify-center leading-[0] relative shrink-0 text-[#0065bd] text-[0px] text-left text-nowrap tracking-[0.15px]"
        style={{ fontVariationSettings: "'wdth' 100" }}
      >
        <a
          className="adjustLetterSpacing block cursor-pointer leading-[21px] text-[14px] whitespace-pre"
          href="https://cobalt.sgdatacatalogue.net/results"
          style={{ fontVariationSettings: "'wdth' 100" }}
        >
          Covid-19
        </a>
      </div>
    </div>
  );
}

function Component19() {
  return (
    <div
      className="bg-[#d9effc] box-border content-stretch flex flex-col items-start justify-start px-4 py-2 relative rounded self-stretch shrink-0"
      data-name="Component 5"
    >
      <div
        className="flex flex-col font-['Roboto:Medium',_sans-serif] font-medium justify-center leading-[0] relative shrink-0 text-[#0065bd] text-[0px] text-left text-nowrap tracking-[0.15px]"
        style={{ fontVariationSettings: "'wdth' 100" }}
      >
        <a
          className="adjustLetterSpacing block cursor-pointer leading-[21px] text-[14px] whitespace-pre"
          href="https://cobalt.sgdatacatalogue.net/results"
          style={{ fontVariationSettings: "'wdth' 100" }}
        >
          Health
        </a>
      </div>
    </div>
  );
}

function Container50() {
  return (
    <div
      className="[flex-flow:wrap] box-border content-stretch flex gap-3 items-start justify-start pb-0 pt-1 px-0 relative shrink-0 w-full"
      data-name="Container"
    >
      <Component18 />
      <Component19 />
    </div>
  );
}

function Item9() {
  return (
    <div
      className="box-border content-stretch flex flex-col gap-2 items-start justify-start pb-[15px] pt-[17px] px-0 relative shrink-0 w-full"
      data-name="Item"
    >
      <div className="absolute border-[#b3b3b3] border-[1px_0px_0px] border-solid inset-0 pointer-events-none" />
      <Heading16 />
      <Container46 />
      <Descriptions18 />
      <Descriptions19 />
      <Container50 />
    </div>
  );
}

function Component20() {
  return (
    <div
      className="box-border content-stretch flex flex-row items-start justify-start p-0 relative shrink-0"
      data-name="Component 5"
    >
      <a
        className="[white-space-collapse:collapse] flex flex-col font-['Roboto:Bold',_sans-serif] font-bold justify-center leading-[0] relative shrink-0 text-[#0065bd] text-[0px] text-left text-nowrap tracking-[0.15px]"
        href="https://cobalt.sgdatacatalogue.net/dataset/deer-vehicle-collisions"
        style={{ fontVariationSettings: "'wdth' 100" }}
      >
        <p
          className="adjustLetterSpacing block cursor-pointer leading-[32px] text-[22px] whitespace-pre"
          role="link"
          style={{ fontVariationSettings: "'wdth' 100" }}
          tabIndex="0"
        >
          Life Expectancy
        </p>
      </a>
    </div>
  );
}

function Heading17() {
  return (
    <div
      className="box-border content-stretch flex flex-col items-start justify-start p-0 relative shrink-0 w-full"
      data-name="Heading 3"
    >
      <Component20 />
    </div>
  );
}

function Container51() {
  return (
    <div
      className="box-border content-stretch flex flex-col items-start justify-start p-0 relative shrink-0 w-full"
      data-name="Container"
    >
      <div
        className="flex flex-col font-['Roboto:Regular',_sans-serif] font-normal justify-center leading-[32px] relative shrink-0 text-[19px] text-[rgba(0,0,0,0.87)] text-left tracking-[0.15px] w-full"
        style={{ fontVariationSettings: "'wdth' 100" }}
      >
        <p className="block mb-0">
          Life expectancy in years, at birth and for age groups. Breakdowns are
          also given for
        </p>
        <p className="block mb-0">
          deprivation (SIMD) and Urban Rural classification. Life expectancy
          refers to the
        </p>
        <p className="block mb-0">
          number of years that a person could expect to survive if the current
          mortality rates for
        </p>
        <p className="block mb-0">
          each age group, sex and geographic area remain constant throughout
          their life. This
        </p>
        <p className="block">
          is referred to as ‘period life expectancy’ and does not usually...
        </p>
      </div>
    </div>
  );
}

function Container52() {
  return (
    <div
      className="box-border content-stretch flex flex-row items-start justify-start p-0 relative shrink-0 w-[185.53px]"
      data-name="Container"
    >
      <div
        className="flex flex-col font-['Roboto:Regular',_sans-serif] font-normal justify-center leading-[0] relative shrink-0 text-[#5e5e5e] text-[14px] text-left text-nowrap tracking-[0.15px]"
        style={{ fontVariationSettings: "'wdth' 100" }}
      >
        <p className="adjustLetterSpacing block leading-[24px] whitespace-pre">
          National Records of Scotland
        </p>
      </div>
    </div>
  );
}

function Container53() {
  return (
    <div
      className="box-border content-stretch flex flex-row items-start justify-start pl-2 pr-0 py-0 relative shrink-0 w-[37.25px]"
      data-name="Container"
    >
      <div
        className="flex flex-col font-['Roboto:Regular',_sans-serif] font-normal justify-center leading-[0] relative shrink-0 text-[#5e5e5e] text-[14px] text-left text-nowrap tracking-[0.15px]"
        style={{ fontVariationSettings: "'wdth' 100" }}
      >
        <p className="adjustLetterSpacing block leading-[24px] whitespace-pre">
          CSV
        </p>
      </div>
      <div
        className="absolute bg-[#5e5e5e] h-[13px] left-0 top-1.5 w-px"
        data-name="Vertical Divider"
      />
    </div>
  );
}

function Descriptions20() {
  return (
    <div className="relative shrink-0 w-full" data-name="Descriptions">
      <div className="flex flex-row justify-center overflow-clip relative size-full">
        <div className="box-border content-stretch flex flex-row gap-[3.5px] items-start justify-center pl-0 pr-[509.72px] py-0 relative w-full">
          <Container52 />
          <Container53 />
        </div>
      </div>
    </div>
  );
}

function Details10() {
  return (
    <div
      className="basis-0 box-border content-stretch flex flex-row grow items-start justify-start min-h-px min-w-px p-0 relative shrink-0"
      data-name="Details"
    >
      <div
        className="basis-0 flex flex-col font-['Roboto:Regular',_sans-serif] font-normal grow justify-center leading-[0] min-h-px min-w-px relative shrink-0 text-[#5e5e5e] text-[14px] text-left tracking-[0.15px]"
        style={{ fontVariationSettings: "'wdth' 100" }}
      >
        <p className="block leading-[24px]">Last updated: 3/18/2025</p>
      </div>
    </div>
  );
}

function Container54() {
  return (
    <div
      className="box-border content-stretch flex flex-row items-start justify-start p-0 relative shrink-0 w-[154.48px]"
      data-name="Container"
    >
      <Details10 />
    </div>
  );
}

function Descriptions21() {
  return (
    <div
      className="box-border content-stretch flex flex-col items-start justify-start overflow-clip p-0 relative shrink-0 w-full"
      data-name="Descriptions"
    >
      <Container54 />
    </div>
  );
}

function Component21() {
  return (
    <div
      className="bg-[#d9effc] box-border content-stretch flex flex-col items-start justify-start px-4 py-2 relative rounded self-stretch shrink-0"
      data-name="Component 5"
    >
      <div
        className="flex flex-col font-['Roboto:Medium',_sans-serif] font-medium justify-center leading-[0] relative shrink-0 text-[#0065bd] text-[0px] text-left text-nowrap tracking-[0.15px]"
        style={{ fontVariationSettings: "'wdth' 100" }}
      >
        <a
          className="adjustLetterSpacing block cursor-pointer leading-[21px] text-[14px] whitespace-pre"
          href="https://cobalt.sgdatacatalogue.net/results"
          style={{ fontVariationSettings: "'wdth' 100" }}
        >
          Demographics
        </a>
      </div>
    </div>
  );
}

function Component22() {
  return (
    <div
      className="bg-[#d9effc] box-border content-stretch flex flex-col items-start justify-start px-4 py-2 relative rounded self-stretch shrink-0"
      data-name="Component 5"
    >
      <div
        className="flex flex-col font-['Roboto:Medium',_sans-serif] font-medium justify-center leading-[0] relative shrink-0 text-[#0065bd] text-[0px] text-left text-nowrap tracking-[0.15px]"
        style={{ fontVariationSettings: "'wdth' 100" }}
      >
        <a
          className="adjustLetterSpacing block cursor-pointer leading-[21px] text-[14px] whitespace-pre"
          href="https://cobalt.sgdatacatalogue.net/results"
          style={{ fontVariationSettings: "'wdth' 100" }}
        >
          Health
        </a>
      </div>
    </div>
  );
}

function Component23() {
  return (
    <div
      className="bg-[#d9effc] box-border content-stretch flex flex-col items-start justify-start px-4 py-2 relative rounded self-stretch shrink-0"
      data-name="Component 5"
    >
      <div
        className="flex flex-col font-['Roboto:Medium',_sans-serif] font-medium justify-center leading-[0] relative shrink-0 text-[#0065bd] text-[0px] text-left text-nowrap tracking-[0.15px]"
        style={{ fontVariationSettings: "'wdth' 100" }}
      >
        <a
          className="adjustLetterSpacing block cursor-pointer leading-[21px] text-[14px] whitespace-pre"
          href="https://cobalt.sgdatacatalogue.net/results"
          style={{ fontVariationSettings: "'wdth' 100" }}
        >
          Population
        </a>
      </div>
    </div>
  );
}

function Container55() {
  return (
    <div
      className="[flex-flow:wrap] box-border content-stretch flex gap-3 items-start justify-start pb-0 pt-1 px-0 relative shrink-0 w-full"
      data-name="Container"
    >
      <Component21 />
      <Component22 />
      <Component23 />
    </div>
  );
}

function Item10() {
  return (
    <div
      className="box-border content-stretch flex flex-col gap-2 items-start justify-start pb-[15px] pt-[17px] px-0 relative shrink-0 w-full"
      data-name="Item"
    >
      <div className="absolute border-[#b3b3b3] border-[1px_0px_0px] border-solid inset-0 pointer-events-none" />
      <Heading17 />
      <Container51 />
      <Descriptions20 />
      <Descriptions21 />
      <Container55 />
    </div>
  );
}

function Component24() {
  return (
    <div
      className="box-border content-stretch flex flex-row items-start justify-start p-0 relative shrink-0"
      data-name="Component 5"
    >
      <a
        className="[white-space-collapse:collapse] flex flex-col font-['Roboto:Bold',_sans-serif] font-bold justify-center leading-[0] relative shrink-0 text-[#0065bd] text-[0px] text-left text-nowrap tracking-[0.15px]"
        href="https://cobalt.sgdatacatalogue.net/dataset/deer-vehicle-collisions"
        style={{ fontVariationSettings: "'wdth' 100" }}
      >
        <p
          className="adjustLetterSpacing block cursor-pointer leading-[32px] text-[22px] whitespace-pre"
          role="link"
          style={{ fontVariationSettings: "'wdth' 100" }}
          tabIndex="0"
        >
          Gross Domestic Product: Quarterly Output by Industry
        </p>
      </a>
    </div>
  );
}

function Heading18() {
  return (
    <div
      className="box-border content-stretch flex flex-col items-start justify-start p-0 relative shrink-0 w-full"
      data-name="Heading 3"
    >
      <Component24 />
    </div>
  );
}

function Container56() {
  return (
    <div
      className="box-border content-stretch flex flex-col items-start justify-start p-0 relative shrink-0 w-full"
      data-name="Container"
    >
      <div
        className="flex flex-col font-['Roboto:Regular',_sans-serif] font-normal justify-center leading-[32px] relative shrink-0 text-[19px] text-[rgba(0,0,0,0.87)] text-left tracking-[0.15px] w-full"
        style={{ fontVariationSettings: "'wdth' 100" }}
      >
        <p className="block mb-0">
          Gross Domestic Product (GDP) is one of the best known indicators of
          economic
        </p>
        <p className="block mb-0">
          activity and is widely used to monitor economic performance. GDP
          statistics for
        </p>
        <p className="block mb-0">
          Scotland are produced by the Scottish Government and have been
          designated as
        </p>
        <p className="block mb-0">
          National Statistics. This dataset contains statistics for the output
          approach to GDP
        </p>
        <p className="block mb-0">
          and growth in real terms, and includes results for the whole economy
          (Total GDP) and
        </p>
        <p className="block">industry...</p>
      </div>
    </div>
  );
}

function Container57() {
  return (
    <div
      className="box-border content-stretch flex flex-row items-start justify-start p-0 relative shrink-0 w-[133.58px]"
      data-name="Container"
    >
      <div
        className="flex flex-col font-['Roboto:Regular',_sans-serif] font-normal justify-center leading-[0] relative shrink-0 text-[#5e5e5e] text-[14px] text-left text-nowrap tracking-[0.15px]"
        style={{ fontVariationSettings: "'wdth' 100" }}
      >
        <p className="adjustLetterSpacing block leading-[24px] whitespace-pre">
          Scottish Government
        </p>
      </div>
    </div>
  );
}

function Container58() {
  return (
    <div
      className="box-border content-stretch flex flex-row items-start justify-start pl-2 pr-0 py-0 relative shrink-0 w-[37.25px]"
      data-name="Container"
    >
      <div
        className="flex flex-col font-['Roboto:Regular',_sans-serif] font-normal justify-center leading-[0] relative shrink-0 text-[#5e5e5e] text-[14px] text-left text-nowrap tracking-[0.15px]"
        style={{ fontVariationSettings: "'wdth' 100" }}
      >
        <p className="adjustLetterSpacing block leading-[24px] whitespace-pre">
          CSV
        </p>
      </div>
      <div
        className="absolute bg-[#5e5e5e] h-[13px] left-0 top-1.5 w-px"
        data-name="Vertical Divider"
      />
    </div>
  );
}

function Descriptions22() {
  return (
    <div className="relative shrink-0 w-full" data-name="Descriptions">
      <div className="flex flex-row justify-center overflow-clip relative size-full">
        <div className="box-border content-stretch flex flex-row gap-[3.5px] items-start justify-center pl-0 pr-[561.67px] py-0 relative w-full">
          <Container57 />
          <Container58 />
        </div>
      </div>
    </div>
  );
}

function Details11() {
  return (
    <div
      className="basis-0 box-border content-stretch flex flex-row grow items-start justify-start min-h-px min-w-px p-0 relative shrink-0"
      data-name="Details"
    >
      <div
        className="basis-0 flex flex-col font-['Roboto:Regular',_sans-serif] font-normal grow justify-center leading-[0] min-h-px min-w-px relative shrink-0 text-[#5e5e5e] text-[14px] text-left tracking-[0.15px]"
        style={{ fontVariationSettings: "'wdth' 100" }}
      >
        <p className="block leading-[24px]">Last updated: 3/18/2025</p>
      </div>
    </div>
  );
}

function Container59() {
  return (
    <div
      className="box-border content-stretch flex flex-row items-start justify-start p-0 relative shrink-0 w-[154.48px]"
      data-name="Container"
    >
      <Details11 />
    </div>
  );
}

function Descriptions23() {
  return (
    <div
      className="box-border content-stretch flex flex-col items-start justify-start overflow-clip p-0 relative shrink-0 w-full"
      data-name="Descriptions"
    >
      <Container59 />
    </div>
  );
}

function Component25() {
  return (
    <div
      className="bg-[#d9effc] box-border content-stretch flex flex-col items-start justify-start px-4 py-2 relative rounded self-stretch shrink-0"
      data-name="Component 5"
    >
      <div
        className="flex flex-col font-['Roboto:Medium',_sans-serif] font-medium justify-center leading-[0] relative shrink-0 text-[#0065bd] text-[0px] text-left text-nowrap tracking-[0.15px]"
        style={{ fontVariationSettings: "'wdth' 100" }}
      >
        <a
          className="adjustLetterSpacing block cursor-pointer leading-[21px] text-[14px] whitespace-pre"
          href="https://cobalt.sgdatacatalogue.net/results"
          style={{ fontVariationSettings: "'wdth' 100" }}
        >
          Economy
        </a>
      </div>
    </div>
  );
}

function Container60() {
  return (
    <div
      className="[flex-flow:wrap] box-border content-stretch flex gap-0 items-start justify-start pb-0 pt-1 px-0 relative shrink-0 w-full"
      data-name="Container"
    >
      <Component25 />
    </div>
  );
}

function Item11() {
  return (
    <div
      className="box-border content-stretch flex flex-col gap-2 items-start justify-start pb-[15px] pt-[17px] px-0 relative shrink-0 w-full"
      data-name="Item"
    >
      <div className="absolute border-[#b3b3b3] border-[1px_0px_0px] border-solid inset-0 pointer-events-none" />
      <Heading18 />
      <Container56 />
      <Descriptions22 />
      <Descriptions23 />
      <Container60 />
    </div>
  );
}

function Component26() {
  return (
    <div
      className="box-border content-stretch flex flex-row items-start justify-start p-0 relative shrink-0"
      data-name="Component 5"
    >
      <a
        className="[white-space-collapse:collapse] flex flex-col font-['Roboto:Bold',_sans-serif] font-bold justify-center leading-[0] relative shrink-0 text-[#0065bd] text-[0px] text-left text-nowrap tracking-[0.15px]"
        href="https://cobalt.sgdatacatalogue.net/dataset/deer-vehicle-collisions"
        style={{ fontVariationSettings: "'wdth' 100" }}
      >
        <p
          className="adjustLetterSpacing block cursor-pointer leading-[32px] text-[22px] whitespace-pre"
          role="link"
          style={{ fontVariationSettings: "'wdth' 100" }}
          tabIndex="0"
        >
          Non-domestic Energy Performance Certificates - Dataset to Q3 2024
        </p>
      </a>
    </div>
  );
}

function Heading19() {
  return (
    <div
      className="box-border content-stretch flex flex-col items-start justify-start p-0 relative shrink-0 w-full"
      data-name="Heading 3"
    >
      <Component26 />
    </div>
  );
}

function Container61() {
  return (
    <div
      className="box-border content-stretch flex flex-col items-start justify-start p-0 relative shrink-0 w-full"
      data-name="Container"
    >
      <div
        className="flex flex-col font-['Roboto:Regular',_sans-serif] font-normal justify-center leading-[32px] relative shrink-0 text-[19px] text-[rgba(0,0,0,0.87)] text-left tracking-[0.15px] w-full"
        style={{ fontVariationSettings: "'wdth' 100" }}
      >
        <p className="block mb-0">
          Management Information: environmental data on Non-domestic Energy
          Performance
        </p>
        <p className="block mb-0">
          Certificate (EPC) and Recommendations Report for each current record
          held on the
        </p>
        <p className="block">
          Scottish EPC Register from Q4 2014 to Q3 2024. Data extracted October
          2024.
        </p>
      </div>
    </div>
  );
}

function Container62() {
  return (
    <div
      className="box-border content-stretch flex flex-row items-start justify-start p-0 relative shrink-0 w-[133.58px]"
      data-name="Container"
    >
      <div
        className="flex flex-col font-['Roboto:Regular',_sans-serif] font-normal justify-center leading-[0] relative shrink-0 text-[#5e5e5e] text-[14px] text-left text-nowrap tracking-[0.15px]"
        style={{ fontVariationSettings: "'wdth' 100" }}
      >
        <p className="adjustLetterSpacing block leading-[24px] whitespace-pre">
          Scottish Government
        </p>
      </div>
    </div>
  );
}

function Container63() {
  return (
    <div
      className="box-border content-stretch flex flex-row items-start justify-start pl-2 pr-0 py-0 relative shrink-0 w-[37.25px]"
      data-name="Container"
    >
      <div
        className="flex flex-col font-['Roboto:Regular',_sans-serif] font-normal justify-center leading-[0] relative shrink-0 text-[#5e5e5e] text-[14px] text-left text-nowrap tracking-[0.15px]"
        style={{ fontVariationSettings: "'wdth' 100" }}
      >
        <p className="adjustLetterSpacing block leading-[24px] whitespace-pre">
          CSV
        </p>
      </div>
      <div
        className="absolute bg-[#5e5e5e] h-[13px] left-0 top-1.5 w-px"
        data-name="Vertical Divider"
      />
    </div>
  );
}

function Descriptions24() {
  return (
    <div className="relative shrink-0 w-full" data-name="Descriptions">
      <div className="flex flex-row justify-center overflow-clip relative size-full">
        <div className="box-border content-stretch flex flex-row gap-[3.5px] items-start justify-center pl-0 pr-[561.67px] py-0 relative w-full">
          <Container62 />
          <Container63 />
        </div>
      </div>
    </div>
  );
}

function Details12() {
  return (
    <div
      className="basis-0 box-border content-stretch flex flex-row grow items-start justify-start min-h-px min-w-px p-0 relative shrink-0"
      data-name="Details"
    >
      <div
        className="basis-0 flex flex-col font-['Roboto:Regular',_sans-serif] font-normal grow justify-center leading-[0] min-h-px min-w-px relative shrink-0 text-[#5e5e5e] text-[14px] text-left tracking-[0.15px]"
        style={{ fontVariationSettings: "'wdth' 100" }}
      >
        <p className="block leading-[24px]">Last updated: 3/18/2025</p>
      </div>
    </div>
  );
}

function Container64() {
  return (
    <div
      className="box-border content-stretch flex flex-row items-start justify-start p-0 relative shrink-0 w-[154.48px]"
      data-name="Container"
    >
      <Details12 />
    </div>
  );
}

function Descriptions25() {
  return (
    <div
      className="box-border content-stretch flex flex-col items-start justify-start overflow-clip p-0 relative shrink-0 w-full"
      data-name="Descriptions"
    >
      <Container64 />
    </div>
  );
}

function Component27() {
  return (
    <div
      className="bg-[#d9effc] box-border content-stretch flex flex-col items-start justify-start px-4 py-2 relative rounded self-stretch shrink-0"
      data-name="Component 5"
    >
      <div
        className="flex flex-col font-['Roboto:Medium',_sans-serif] font-medium justify-center leading-[0] relative shrink-0 text-[#0065bd] text-[0px] text-left text-nowrap tracking-[0.15px]"
        style={{ fontVariationSettings: "'wdth' 100" }}
      >
        <a
          className="adjustLetterSpacing block cursor-pointer leading-[21px] text-[14px] whitespace-pre"
          href="https://cobalt.sgdatacatalogue.net/results"
          style={{ fontVariationSettings: "'wdth' 100" }}
        >
          EPC
        </a>
      </div>
    </div>
  );
}

function Component28() {
  return (
    <div
      className="bg-[#d9effc] box-border content-stretch flex flex-col items-start justify-start px-4 py-2 relative rounded self-stretch shrink-0"
      data-name="Component 5"
    >
      <div
        className="flex flex-col font-['Roboto:Medium',_sans-serif] font-medium justify-center leading-[0] relative shrink-0 text-[#0065bd] text-[0px] text-left text-nowrap tracking-[0.15px]"
        style={{ fontVariationSettings: "'wdth' 100" }}
      >
        <a
          className="adjustLetterSpacing block cursor-pointer leading-[21px] text-[14px] whitespace-pre"
          href="https://cobalt.sgdatacatalogue.net/results"
          style={{ fontVariationSettings: "'wdth' 100" }}
        >
          Energy
        </a>
      </div>
    </div>
  );
}

function Component29() {
  return (
    <div
      className="bg-[#d9effc] box-border content-stretch flex flex-col items-start justify-start px-4 py-2 relative rounded self-stretch shrink-0"
      data-name="Component 5"
    >
      <div
        className="flex flex-col font-['Roboto:Medium',_sans-serif] font-medium justify-center leading-[0] relative shrink-0 text-[#0065bd] text-[0px] text-left text-nowrap tracking-[0.15px]"
        style={{ fontVariationSettings: "'wdth' 100" }}
      >
        <a
          className="adjustLetterSpacing block cursor-pointer leading-[21px] text-[14px] whitespace-pre"
          href="https://cobalt.sgdatacatalogue.net/results"
          style={{ fontVariationSettings: "'wdth' 100" }}
        >
          Environment
        </a>
      </div>
    </div>
  );
}

function Container65() {
  return (
    <div
      className="[flex-flow:wrap] box-border content-stretch flex gap-3 items-start justify-start pb-0 pt-1 px-0 relative shrink-0 w-full"
      data-name="Container"
    >
      <Component27 />
      <Component28 />
      <Component29 />
    </div>
  );
}

function Item12() {
  return (
    <div
      className="box-border content-stretch flex flex-col gap-2 items-start justify-start pb-[15px] pt-[17px] px-0 relative shrink-0 w-full"
      data-name="Item"
    >
      <div className="absolute border-[#b3b3b3] border-[1px_0px_0px] border-solid inset-0 pointer-events-none" />
      <Heading19 />
      <Container61 />
      <Descriptions24 />
      <Descriptions25 />
      <Container65 />
    </div>
  );
}

function Component30() {
  return (
    <div
      className="box-border content-stretch flex flex-row items-start justify-start p-0 relative shrink-0"
      data-name="Component 5"
    >
      <a
        className="[white-space-collapse:collapse] flex flex-col font-['Roboto:Bold',_sans-serif] font-bold justify-center leading-[0] relative shrink-0 text-[#0065bd] text-[0px] text-left text-nowrap tracking-[0.15px]"
        href="https://cobalt.sgdatacatalogue.net/dataset/deer-vehicle-collisions"
        style={{ fontVariationSettings: "'wdth' 100" }}
      >
        <p
          className="adjustLetterSpacing block cursor-pointer leading-[32px] text-[22px] whitespace-pre"
          role="link"
          style={{ fontVariationSettings: "'wdth' 100" }}
          tabIndex="0"
        >
          Police Officer Quarterly Strength
        </p>
      </a>
    </div>
  );
}

function Heading20() {
  return (
    <div
      className="box-border content-stretch flex flex-col items-start justify-start p-0 relative shrink-0 w-full"
      data-name="Heading 3"
    >
      <Component30 />
    </div>
  );
}

function Container66() {
  return (
    <div
      className="box-border content-stretch flex flex-col items-start justify-start p-0 relative shrink-0 w-full"
      data-name="Container"
    >
      <div
        className="flex flex-col font-['Roboto:Regular',_sans-serif] font-normal justify-center leading-[32px] relative shrink-0 text-[19px] text-[rgba(0,0,0,0.87)] text-left tracking-[0.15px] w-full"
        style={{ fontVariationSettings: "'wdth' 100" }}
      >
        <p className="block mb-0">
          The first publication of Police Officer Quarterly Strength statistics
          as Official Statistics
        </p>
        <p className="block mb-0">
          was on 2 December 2008. Prior to this publication, figures were
          collated by the
        </p>
        <p className="block mb-0">
          Scottish Government and released through responses to Parliamentary
          Questions
        </p>
        <p className="block mb-0">
          and by depositing the figures in the Scottish Parliamentary Library.
          The Police and
        </p>
        <p className="block mb-0">
          Fire Reform (Scotland) Act 2012 created Police Scotland and the
          Scottish Police
        </p>
        <p className="block">Authority (SPA), which came into being...</p>
      </div>
    </div>
  );
}

function Container67() {
  return (
    <div
      className="box-border content-stretch flex flex-row items-start justify-start p-0 relative shrink-0 w-[133.58px]"
      data-name="Container"
    >
      <div
        className="flex flex-col font-['Roboto:Regular',_sans-serif] font-normal justify-center leading-[0] relative shrink-0 text-[#5e5e5e] text-[14px] text-left text-nowrap tracking-[0.15px]"
        style={{ fontVariationSettings: "'wdth' 100" }}
      >
        <p className="adjustLetterSpacing block leading-[24px] whitespace-pre">
          Scottish Government
        </p>
      </div>
    </div>
  );
}

function Container68() {
  return (
    <div
      className="box-border content-stretch flex flex-row items-start justify-start pl-2 pr-0 py-0 relative shrink-0 w-[81.98px]"
      data-name="Container"
    >
      <div
        className="flex flex-col font-['Roboto:Regular',_sans-serif] font-normal justify-center leading-[0] relative shrink-0 text-[#5e5e5e] text-[14px] text-left text-nowrap tracking-[0.15px]"
        style={{ fontVariationSettings: "'wdth' 100" }}
      >
        <p className="adjustLetterSpacing block leading-[24px] whitespace-pre">
          CSV, JSON
        </p>
      </div>
      <div
        className="absolute bg-[#5e5e5e] h-[13px] left-0 top-1.5 w-px"
        data-name="Vertical Divider"
      />
    </div>
  );
}

function Descriptions26() {
  return (
    <div className="relative shrink-0 w-full" data-name="Descriptions">
      <div className="flex flex-row justify-center overflow-clip relative size-full">
        <div className="box-border content-stretch flex flex-row gap-[3.5px] items-start justify-center pl-0 pr-[516.94px] py-0 relative w-full">
          <Container67 />
          <Container68 />
        </div>
      </div>
    </div>
  );
}

function Details13() {
  return (
    <div
      className="basis-0 box-border content-stretch flex flex-row grow items-start justify-start min-h-px min-w-px p-0 relative shrink-0"
      data-name="Details"
    >
      <div
        className="basis-0 flex flex-col font-['Roboto:Regular',_sans-serif] font-normal grow justify-center leading-[0] min-h-px min-w-px relative shrink-0 text-[#5e5e5e] text-[14px] text-left tracking-[0.15px]"
        style={{ fontVariationSettings: "'wdth' 100" }}
      >
        <p className="block leading-[24px]">Last updated: 3/18/2025</p>
      </div>
    </div>
  );
}

function Container69() {
  return (
    <div
      className="box-border content-stretch flex flex-row items-start justify-start p-0 relative shrink-0 w-[154.48px]"
      data-name="Container"
    >
      <Details13 />
    </div>
  );
}

function Descriptions27() {
  return (
    <div
      className="box-border content-stretch flex flex-col items-start justify-start overflow-clip p-0 relative shrink-0 w-full"
      data-name="Descriptions"
    >
      <Container69 />
    </div>
  );
}

function Component31() {
  return (
    <div
      className="bg-[#d9effc] box-border content-stretch flex flex-col items-start justify-start px-4 py-2 relative rounded self-stretch shrink-0"
      data-name="Component 5"
    >
      <div
        className="flex flex-col font-['Roboto:Medium',_sans-serif] font-medium justify-center leading-[0] relative shrink-0 text-[#0065bd] text-[0px] text-left text-nowrap tracking-[0.15px]"
        style={{ fontVariationSettings: "'wdth' 100" }}
      >
        <a
          className="adjustLetterSpacing block cursor-pointer leading-[21px] text-[14px] whitespace-pre"
          href="https://cobalt.sgdatacatalogue.net/results"
          style={{ fontVariationSettings: "'wdth' 100" }}
        >
          Crime
        </a>
      </div>
    </div>
  );
}

function Component32() {
  return (
    <div
      className="bg-[#d9effc] box-border content-stretch flex flex-col items-start justify-start px-4 py-2 relative rounded self-stretch shrink-0"
      data-name="Component 5"
    >
      <div
        className="flex flex-col font-['Roboto:Medium',_sans-serif] font-medium justify-center leading-[0] relative shrink-0 text-[#0065bd] text-[0px] text-left text-nowrap tracking-[0.15px]"
        style={{ fontVariationSettings: "'wdth' 100" }}
      >
        <a
          className="adjustLetterSpacing block cursor-pointer leading-[21px] text-[14px] whitespace-pre"
          href="https://cobalt.sgdatacatalogue.net/results"
          style={{ fontVariationSettings: "'wdth' 100" }}
        >
          Justice
        </a>
      </div>
    </div>
  );
}

function Component33() {
  return (
    <div
      className="bg-[#d9effc] box-border content-stretch flex flex-col items-start justify-start px-4 py-2 relative rounded self-stretch shrink-0"
      data-name="Component 5"
    >
      <div
        className="flex flex-col font-['Roboto:Medium',_sans-serif] font-medium justify-center leading-[0] relative shrink-0 text-[#0065bd] text-[0px] text-left text-nowrap tracking-[0.15px]"
        style={{ fontVariationSettings: "'wdth' 100" }}
      >
        <a
          className="adjustLetterSpacing block cursor-pointer leading-[21px] text-[14px] whitespace-pre"
          href="https://cobalt.sgdatacatalogue.net/results"
          style={{ fontVariationSettings: "'wdth' 100" }}
        >
          Police
        </a>
      </div>
    </div>
  );
}

function Container70() {
  return (
    <div
      className="[flex-flow:wrap] box-border content-stretch flex gap-3 items-start justify-start pb-0 pt-1 px-0 relative shrink-0 w-full"
      data-name="Container"
    >
      <Component31 />
      <Component32 />
      <Component33 />
    </div>
  );
}

function Item13() {
  return (
    <div
      className="box-border content-stretch flex flex-col gap-2 items-start justify-start pb-[15px] pt-[17px] px-0 relative shrink-0 w-full"
      data-name="Item"
    >
      <div className="absolute border-[#b3b3b3] border-[1px_0px_0px] border-solid inset-0 pointer-events-none" />
      <Heading20 />
      <Container66 />
      <Descriptions26 />
      <Descriptions27 />
      <Container70 />
    </div>
  );
}

function OrderedList() {
  return (
    <div
      className="box-border content-stretch flex flex-col items-start justify-start pb-px pt-[25px] px-0 relative shrink-0 w-full"
      data-name="Ordered List"
    >
      <div className="absolute border-[#b3b3b3] border-[0px_0px_1px] border-solid inset-0 pointer-events-none" />
      <Item />
      <Item1 />
      <Item2 />
      <Item3 />
      <Item4 />
      <Item5 />
      <Item6 />
      <Item7 />
      <Item8 />
      <Item9 />
      <Item10 />
      <Item11 />
      <Item12 />
      <Item13 />
    </div>
  );
}

function Container71() {
  return (
    <div
      className="box-border content-stretch flex flex-col items-center justify-start p-0 relative shrink-0"
      data-name="Container"
    >
      <div
        className="flex flex-col font-['Roboto:Regular',_sans-serif] font-normal justify-center leading-[0] relative shrink-0 text-[0px] text-[rgba(0,0,0,0.87)] text-center text-nowrap tracking-[0.15px]"
        role="link"
        style={{ fontVariationSettings: "'wdth' 100" }}
        tabIndex="0"
      >
        <p
          className="adjustLetterSpacing block cursor-pointer leading-[40px] text-[16px] whitespace-pre"
          style={{ fontVariationSettings: "'wdth' 100" }}
        >
          1
        </p>
      </div>
    </div>
  );
}

function LinkPage1() {
  return (
    <a
      className="bg-[#f8f8f8] cursor-pointer min-h-10 min-w-10 relative shrink-0 w-full"
      data-name="Link - Page 1"
      href="https://cobalt.sgdatacatalogue.net/datasets"
    >
      <div className="flex flex-row items-center justify-center min-h-inherit min-w-inherit relative size-full">
        <div className="box-border content-stretch flex flex-row items-center justify-center min-h-inherit min-w-inherit px-2 py-0 relative w-full">
          <Container71 />
          <div
            className="absolute bottom-0 h-0.5 left-0 right-0"
            data-name="Horizontal Divider"
          >
            <div className="absolute border-[0px_0px_2px] border-[rgba(0,0,0,0.76)] border-solid inset-0 pointer-events-none" />
          </div>
        </div>
      </div>
    </a>
  );
}

function Item14() {
  return (
    <div
      className="box-border content-stretch flex flex-col items-start justify-start p-0 relative self-stretch shrink-0"
      data-name="Item"
    >
      <LinkPage1 />
    </div>
  );
}

function NavSearchResultPagesList() {
  return (
    <div
      className="[flex-flow:wrap] box-border content-stretch flex gap-0 items-start justify-center pb-0 pt-[25px] px-0 relative shrink-0 w-full"
      data-name="Nav - Search result pages → List"
    >
      <Item14 />
    </div>
  );
}

function Container72() {
  return (
    <div
      className="box-border content-stretch flex flex-col gap-[7px] items-start justify-start p-0 relative shrink-0 w-full"
      data-name="Container"
    >
      <Heading2 />
      <Separator />
      <Container9 />
      <OrderedList />
      <NavSearchResultPagesList />
    </div>
  );
}

function Container73() {
  return (
    <div
      className="absolute bottom-0 box-border content-stretch flex flex-col items-start justify-start left-96 pb-0 pt-2 px-0 right-0 top-[120px]"
      data-name="Container"
    >
      <Container72 />
    </div>
  );
}

function Main() {
  return (
    <div className="h-[4877px] relative shrink-0 w-full" data-name="Main">
      <Container />
      <Container6 />
      <Container73 />
    </div>
  );
}

function Container74() {
  return (
    <div
      className="box-border content-stretch flex flex-col h-[4877px] items-start justify-start px-4 py-0 relative shrink-0 w-[1152px]"
      data-name="Container"
    >
      <Main />
    </div>
  );
}

function Container75() {
  return (
    <div
      className="box-border content-stretch flex flex-col items-center justify-center pb-16 pt-0 px-0 relative shrink-0 w-full"
      data-name="Container"
    >
      <Container74 />
    </div>
  );
}

function Main1() {
  return (
    <div
      className="box-border content-stretch flex flex-col h-[4941px] items-start justify-start p-0 relative shrink-0 w-full"
      data-name="Main"
    >
      <Container75 />
    </div>
  );
}

function Component34() {
  return (
    <div
      className="box-border content-stretch flex flex-row items-start justify-start p-0 relative shrink-0"
      data-name="Component 5"
    >
      <div
        className="flex flex-col font-['Roboto:Regular',_sans-serif] font-normal justify-center leading-[0] relative shrink-0 text-[#0065bd] text-[0px] text-left text-nowrap tracking-[0.15px]"
        style={{ fontVariationSettings: "'wdth' 100" }}
      >
        <a
          className="[text-decoration-line:underline] [text-decoration-style:solid] [text-underline-position:from-font] adjustLetterSpacing block cursor-pointer leading-[24px] text-[14px] whitespace-pre"
          href="https://cobalt.sgdatacatalogue.net/privacy"
          style={{ fontVariationSettings: "'wdth' 100" }}
        >
          Privacy
        </a>
      </div>
    </div>
  );
}

function Component35() {
  return (
    <div
      className="box-border content-stretch flex flex-row items-start justify-start p-0 relative shrink-0"
      data-name="Component 5"
    >
      <div
        className="flex flex-col font-['Roboto:Regular',_sans-serif] font-normal justify-center leading-[0] relative shrink-0 text-[#0065bd] text-[0px] text-left text-nowrap tracking-[0.15px]"
        style={{ fontVariationSettings: "'wdth' 100" }}
      >
        <a
          className="[text-decoration-line:underline] [text-decoration-style:solid] [text-underline-position:from-font] adjustLetterSpacing block cursor-pointer leading-[24px] text-[14px] whitespace-pre"
          href="https://cobalt.sgdatacatalogue.net/accessibility"
          style={{ fontVariationSettings: "'wdth' 100" }}
        >
          Accessibility statement
        </a>
      </div>
    </div>
  );
}

function Component36() {
  return (
    <div
      className="box-border content-stretch flex flex-row items-start justify-start p-0 relative shrink-0"
      data-name="Component 5"
    >
      <div
        className="flex flex-col font-['Roboto:Regular',_sans-serif] font-normal justify-center leading-[0] relative shrink-0 text-[#0065bd] text-[0px] text-left text-nowrap tracking-[0.15px]"
        style={{ fontVariationSettings: "'wdth' 100" }}
      >
        <a
          className="[text-decoration-line:underline] [text-decoration-style:solid] [text-underline-position:from-font] adjustLetterSpacing block cursor-pointer leading-[24px] text-[14px] whitespace-pre"
          href="https://cobalt.sgdatacatalogue.net/contact"
          style={{ fontVariationSettings: "'wdth' 100" }}
        >
          Contact
        </a>
      </div>
    </div>
  );
}

function Component37() {
  return (
    <div
      className="box-border content-stretch flex flex-row items-start justify-start p-0 relative shrink-0"
      data-name="Component 5"
    >
      <div
        className="flex flex-col font-['Roboto:Regular',_sans-serif] font-normal justify-center leading-[0] relative shrink-0 text-[#0065bd] text-[0px] text-left text-nowrap tracking-[0.15px]"
        style={{ fontVariationSettings: "'wdth' 100" }}
      >
        <a
          className="[text-decoration-line:underline] [text-decoration-style:solid] [text-underline-position:from-font] adjustLetterSpacing block cursor-pointer leading-[24px] text-[14px] whitespace-pre"
          href="https://cobalt.sgdatacatalogue.net/help"
          style={{ fontVariationSettings: "'wdth' 100" }}
        >
          How to use this site
        </a>
      </div>
    </div>
  );
}

function List() {
  return (
    <div
      className="absolute bottom-[23px] box-border content-stretch flex flex-row gap-6 items-start justify-start left-0 pb-px pt-0 px-0 right-0 top-[-8px]"
      data-name="List"
    >
      <div className="absolute border-[#b3b3b3] border-[0px_0px_1px] border-solid inset-0 pointer-events-none" />
      <Component34 />
      <Component35 />
      <Component36 />
      <Component37 />
    </div>
  );
}

function ListMargin() {
  return (
    <div
      className="absolute bottom-40 left-0 right-0 top-[23px]"
      data-name="List:margin"
    >
      <List />
    </div>
  );
}

function Component38() {
  return (
    <div
      className="absolute box-border content-stretch flex flex-row items-start justify-start left-[240.09px] p-0 top-[-0.5px]"
      data-name="Component 5"
    >
      <div
        className="flex flex-col font-['Roboto:Regular',_sans-serif] font-normal justify-center leading-[0] relative shrink-0 text-[#0065bd] text-[0px] text-left text-nowrap tracking-[0.15px]"
        style={{ fontVariationSettings: "'wdth' 100" }}
      >
        <a
          className="[text-decoration-line:underline] [text-decoration-style:solid] [text-underline-position:from-font] adjustLetterSpacing block cursor-pointer leading-[24px] text-[16px] whitespace-pre"
          href="https://www.nationalarchives.gov.uk/doc/open-government-licence/version/3/"
          style={{ fontVariationSettings: "'wdth' 100" }}
        >
          Open Government Licence v3.0
        </a>
      </div>
    </div>
  );
}

function Container76() {
  return (
    <div className="h-12 relative shrink-0 w-full" data-name="Container">
      <div
        className="absolute flex flex-col font-['Roboto:Regular',_sans-serif] font-normal h-6 justify-center leading-[0] left-0 text-[16px] text-[rgba(0,0,0,0.87)] text-left top-[11.5px] tracking-[0.15px] translate-y-[-50%] w-[240.477px]"
        style={{ fontVariationSettings: "'wdth' 100" }}
      >
        <p className="adjustLetterSpacing block leading-[24px]">{`All content is available under the `}</p>
      </div>
      <Component38 />
      <div
        className="absolute flex flex-col font-['Roboto:Regular',_sans-serif] font-normal h-6 justify-center leading-[0] left-[470.2px] text-[16px] text-[rgba(0,0,0,0.87)] text-left top-[11.5px] tracking-[0.15px] translate-y-[-50%] w-[191.158px]"
        style={{ fontVariationSettings: "'wdth' 100" }}
      >
        <p className="adjustLetterSpacing block leading-[24px]">
          , except for graphic assets
        </p>
      </div>
      <div
        className="absolute flex flex-col font-['Roboto:Regular',_sans-serif] font-normal h-6 justify-center leading-[0] left-0 text-[16px] text-[rgba(0,0,0,0.87)] text-left top-[35.5px] tracking-[0.15px] translate-y-[-50%] w-[200.245px]"
        style={{ fontVariationSettings: "'wdth' 100" }}
      >
        <p className="adjustLetterSpacing block leading-[24px]">
          and where otherwise stated
        </p>
      </div>
    </div>
  );
}

function Component39() {
  return (
    <div
      className="box-border content-stretch flex flex-row items-start justify-start p-0 relative shrink-0"
      data-name="Component 5"
    >
      <div
        className="flex flex-col font-['Roboto:Bold',_sans-serif] font-bold justify-center leading-[0] relative shrink-0 text-[#0065bd] text-[0px] text-left text-nowrap tracking-[0.15px]"
        style={{ fontVariationSettings: "'wdth' 100" }}
      >
        <a
          className="[text-decoration-line:underline] [text-decoration-style:solid] [text-underline-position:from-font] adjustLetterSpacing block cursor-pointer leading-[24px] text-[16px] whitespace-pre"
          href="https://github.com/ckan/ckan"
          style={{ fontVariationSettings: "'wdth' 100" }}
        >
          CKAN
        </a>
      </div>
    </div>
  );
}

function Strong() {
  return (
    <div
      className="box-border content-stretch flex flex-row items-start justify-start p-0 relative shrink-0"
      data-name="Strong"
    >
      <div
        className="flex flex-col font-['Roboto:Bold',_sans-serif] font-bold justify-center leading-[0] relative shrink-0 text-[16px] text-[rgba(0,0,0,0.87)] text-left text-nowrap tracking-[0.15px]"
        style={{ fontVariationSettings: "'wdth' 100" }}
      >
        <p className="adjustLetterSpacing block leading-[24px] whitespace-pre">{`Powered by `}</p>
      </div>
      <Component39 />
    </div>
  );
}

function Container77() {
  return (
    <div
      className="box-border content-stretch flex flex-col items-start justify-start p-0 relative shrink-0 w-full"
      data-name="Container"
    >
      <Strong />
    </div>
  );
}

function Container78() {
  return (
    <div
      className="box-border content-stretch flex flex-col items-start justify-start p-0 relative shrink-0 w-full"
      data-name="Container"
    >
      <div
        className="flex flex-col font-['Roboto:Regular',_sans-serif] font-normal justify-center leading-[0] relative shrink-0 text-[16px] text-[rgba(0,0,0,0.87)] text-left tracking-[0.15px] w-full"
        style={{ fontVariationSettings: "'wdth' 100" }}
      >
        <p className="block leading-[24px]">© Crown Copyright</p>
      </div>
    </div>
  );
}

function Component40() {
  return (
    <div className="h-[12.959px] relative shrink-0 w-8" data-name="Component 1">
      <svg
        className="block size-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 32 13"
      >
        <g clipPath="url(#clip0_7_826)" id="Component 1">
          <path
            d={svgPaths.p1e54e5f0}
            fill="var(--fill-0, #333333)"
            id="Vector"
          />
          <path
            d={svgPaths.p3e4bb300}
            fill="var(--fill-0, #333333)"
            id="Vector_2"
          />
        </g>
        <defs>
          <clipPath id="clip0_7_826">
            <rect fill="white" height="12.9587" width="32" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function OglSvgFill() {
  return (
    <div
      className="box-border content-stretch flex flex-col h-[12.95px] items-center justify-center overflow-clip p-0 relative shrink-0 w-8"
      data-name="ogl.svg fill"
    >
      <Component40 />
    </div>
  );
}

function OpenGovernmentLicense() {
  return (
    <div
      className="box-border content-stretch flex flex-row items-start justify-start max-w-8 overflow-clip p-0 relative shrink-0 w-full"
      data-name="Open Government License"
    >
      <OglSvgFill />
    </div>
  );
}

function Component6() {
  return (
    <a
      className="absolute box-border content-stretch cursor-pointer flex flex-col items-start justify-start left-0 overflow-visible pb-[7px] pt-[4.05px] px-0 top-0.5 w-8"
      data-name="Component 6"
      href="https://www.nationalarchives.gov.uk/doc/open-government-licence/version/3/"
    >
      <OpenGovernmentLicense />
    </a>
  );
}

function Container79() {
  return (
    <div
      className="absolute bottom-8 box-border content-stretch flex flex-col gap-4 items-start justify-start left-0 pl-12 pr-0 py-0 right-96 top-[79px]"
      data-name="Container"
    >
      <Container76 />
      <Container77 />
      <Container78 />
      <Component6 />
    </div>
  );
}

function Component41() {
  return (
    <div
      className="h-[30.394px] relative shrink-0 w-40"
      data-name="Component 1"
    >
      <svg
        className="block size-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 160 31"
      >
        <g clipPath="url(#clip0_7_818)" id="Component 1">
          <g id="Clip path group">
            <mask
              height="31"
              id="mask0_7_818"
              maskUnits="userSpaceOnUse"
              style={{ maskType: "luminance" }}
              width="160"
              x="0"
              y="0"
            >
              <g id="b">
                <path
                  d="M0 0H160V30.3939H0V0Z"
                  fill="var(--fill-0, white)"
                  id="Vector"
                />
              </g>
            </mask>
            <g mask="url(#mask0_7_818)">
              <path
                d={svgPaths.p2a6a7000}
                fill="var(--fill-0, #333E48)"
                id="Vector_2"
              />
            </g>
          </g>
          <path
            d={svgPaths.p19ce0400}
            fill="var(--fill-0, white)"
            id="Vector_3"
          />
          <path
            d={svgPaths.pa664b00}
            fill="var(--fill-0, #0065BD)"
            id="Vector_4"
          />
        </g>
        <defs>
          <clipPath id="clip0_7_818">
            <rect fill="white" height="30.3939" width="160" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function ScottishGovernmentMinSvgFill() {
  return (
    <div
      className="box-border content-stretch flex flex-col h-[30.39px] items-center justify-center overflow-clip p-0 relative shrink-0 w-40"
      data-name="scottish-government--min.svg fill"
    >
      <Component41 />
    </div>
  );
}

function GovScot() {
  return (
    <div
      className="box-border content-stretch flex flex-col items-start justify-start max-w-40 overflow-clip p-0 relative shrink-0 w-full"
      data-name="gov.scot"
    >
      <ScottishGovernmentMinSvgFill />
    </div>
  );
}

function Component42() {
  return (
    <a
      className="box-border content-stretch cursor-pointer flex flex-col items-start justify-start overflow-visible p-0 relative shrink-0 w-full"
      data-name="Component 6"
      href="https://www.gov.scot/"
    >
      <GovScot />
    </a>
  );
}

function Container80() {
  return (
    <div
      className="absolute bottom-8 box-border content-stretch flex flex-col items-start justify-start left-[960px] max-w-40 p-0 right-0 top-[79px]"
      data-name="Container"
    >
      <Component42 />
    </div>
  );
}

function Container81() {
  return (
    <div className="h-[239px] relative shrink-0 w-full" data-name="Container">
      <ListMargin />
      <Container79 />
      <Container80 />
    </div>
  );
}

function Container82() {
  return (
    <div
      className="box-border content-stretch flex flex-col items-start justify-start px-4 py-0 relative shrink-0 w-[1152px]"
      data-name="Container"
    >
      <Container81 />
    </div>
  );
}

function Footer() {
  return (
    <div
      className="bg-[#ebebeb] box-border content-stretch flex flex-col h-60 items-center justify-start pb-0 pt-px px-0 relative shrink-0 w-full"
      data-name="Footer"
    >
      <div className="absolute border-[#b3b3b3] border-[1px_0px_0px] border-solid inset-0 pointer-events-none" />
      <Container82 />
    </div>
  );
}

function Container83() {
  return (
    <div
      className="box-border content-stretch flex flex-col items-start justify-center min-h-[1200px] pb-0 pt-[173px] px-0 relative shrink-0 w-full"
      data-name="Container"
    >
      <Main1 />
      <Footer />
    </div>
  );
}

function Component43() {
  return (
    <div
      className="h-10 relative shrink-0 w-[269.316px]"
      data-name="Component 1"
    >
      <svg
        className="block size-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 270 40"
      >
        <g clipPath="url(#clip0_7_830)" id="Component 1">
          <path
            d="M0 0H60.9772V37.6547H0V0Z"
            fill="var(--fill-0, white)"
            id="Vector"
          />
          <path
            d={svgPaths.p6de980}
            fill="var(--fill-0, #0065BD)"
            id="Vector_2"
          />
          <path
            d={svgPaths.p5307000}
            fill="var(--fill-0, #858B91)"
            id="Vector_3"
          />
          <path
            d={svgPaths.p19f11d00}
            fill="var(--fill-0, #333E48)"
            id="Vector_4"
          />
        </g>
        <defs>
          <clipPath id="clip0_7_830">
            <rect fill="white" height="40" width="269.316" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function ScottishGovernmentSvgFill() {
  return (
    <div
      className="box-border content-stretch flex flex-col h-10 items-center justify-center overflow-clip pl-0 py-0 relative shrink-0 w-[269.31px]"
      data-name="scottish-government.svg fill"
      style={{ paddingRight: "2.84217e-14px" }}
    >
      <Component43 />
    </div>
  );
}

function ScottishGovernment() {
  return (
    <div
      className="box-border content-stretch flex flex-row h-10 items-start justify-start max-w-[269.31px] overflow-clip p-0 relative shrink-0"
      data-name="Scottish Government"
    >
      <ScottishGovernmentSvgFill />
    </div>
  );
}

function Component44() {
  return (
    <a
      className="box-border content-stretch cursor-pointer flex flex-col h-10 items-start justify-start overflow-visible p-0 relative shrink-0"
      data-name="Component 6"
      href="https://cobalt.sgdatacatalogue.net/"
    >
      <ScottishGovernment />
    </a>
  );
}

function LinkMargin() {
  return (
    <div
      className="box-border content-stretch flex flex-col h-10 items-start justify-start order-2 pl-0 pr-12 py-0 relative shrink-0"
      data-name="Link:margin"
      style={{ marginRight: "-5.68434e-14px" }}
    >
      <Component44 />
    </div>
  );
}

function Container84() {
  return (
    <div
      className="box-border content-stretch flex flex-col items-start justify-start order-1 p-0 relative shrink-0"
      data-name="Container"
      style={{ marginRight: "-5.68434e-14px" }}
    >
      <div
        className="flex flex-col font-['Roboto:Light',_sans-serif] font-light justify-center leading-[0] relative shrink-0 text-[16px] text-[rgba(0,0,0,0.87)] text-left text-nowrap tracking-[0.15px]"
        style={{ fontVariationSettings: "'wdth' 100" }}
      >
        <p className="adjustLetterSpacing block leading-[24px] whitespace-pre">
          Cobalt Open Data Portal
        </p>
      </div>
    </div>
  );
}

function Container85() {
  return (
    <div
      className="[flex-flow:row-reverse_wrap] box-border content-center flex gap-0 items-center justify-start overflow-clip pl-0 py-3 relative shrink-0 w-[850px]"
      data-name="Container"
      style={{ paddingRight: "5.68434e-14px" }}
    >
      <div
        className="absolute bg-[#0065bd] bottom-3 left-[293.31px] order-3 top-3 w-px"
        data-name="Vertical Divider"
      />
      <LinkMargin />
      <Container84 />
    </div>
  );
}

function Container86() {
  return (
    <div
      className="absolute box-border content-stretch flex flex-col items-start justify-start left-3 overflow-clip pb-px pt-0 px-0 right-[73px] top-[15px]"
      data-name="Container"
    >
      <div
        className="flex flex-col font-['Roboto:Regular',_sans-serif] font-normal justify-center leading-[0] relative shrink-0 text-[#5e5e5e] text-[16px] text-left text-nowrap"
        style={{ fontVariationSettings: "'wdth' 100" }}
      >
        <p className="block leading-[normal] whitespace-pre">Search</p>
      </div>
    </div>
  );
}

function Container87() {
  return (
    <div
      className="basis-0 grow h-8 min-h-px min-w-px shrink-0"
      data-name="Container"
    />
  );
}

function Container88() {
  return (
    <div
      className="absolute box-border content-stretch flex flex-row items-center justify-center left-3 pl-0 pr-[15px] py-0 right-[58px] top-2"
      data-name="Container"
    >
      <Container87 />
    </div>
  );
}

function Input3() {
  return (
    <div
      className="bg-[#f8f8f8] h-12 min-h-12 relative shrink-0 w-[270px]"
      data-name="Input"
    >
      <div className="h-12 overflow-clip relative w-[270px]">
        <Container86 />
        <Container88 />
      </div>
      <div className="absolute border-2 border-[#5e5e5e] border-solid inset-0 pointer-events-none" />
    </div>
  );
}

function InputMargin1() {
  return (
    <div
      className="basis-0 box-border content-stretch flex flex-col grow items-start justify-center min-h-12 min-w-px p-0 relative self-stretch shrink-0"
      data-name="Input:margin"
    >
      <Input3 />
    </div>
  );
}

function Component45() {
  return (
    <div className="absolute right-0 size-12 top-0" data-name="Component 1">
      <svg
        className="block size-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 48 48"
      >
        <g clipPath="url(#clip0_7_811)" id="search">
          <g id="Vector"></g>
          <path
            d={svgPaths.p26efbc80}
            fill="var(--fill-0, white)"
            id="Vector_2"
          />
        </g>
        <defs>
          <clipPath id="clip0_7_811">
            <rect fill="white" height="48" width="48" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Component46() {
  return (
    <div
      className="bg-[#0065bd] min-h-12 min-w-12 relative shrink-0 size-12"
      data-name="Component 2"
    >
      <Component45 />
    </div>
  );
}

function Search2() {
  return (
    <div
      className="box-border content-stretch flex flex-row items-start justify-start p-0 relative shrink-0 w-full"
      data-name="Search"
    >
      <InputMargin1 />
      <Component46 />
    </div>
  );
}

function Margin() {
  return (
    <div
      className="box-border content-stretch flex flex-col items-start justify-start min-h-16 px-0 py-2 relative shrink-0 w-[270px]"
      data-name="Margin"
    >
      <Search2 />
    </div>
  );
}

function Container89() {
  return (
    <div
      className="box-border content-stretch flex flex-row items-center justify-center p-0 relative shrink-0 w-full"
      data-name="Container"
    >
      <Container85 />
      <Margin />
    </div>
  );
}

function Container90() {
  return (
    <div
      className="box-border content-stretch flex flex-col items-start justify-start px-4 py-0 relative shrink-0 w-[1152px]"
      data-name="Container"
    >
      <Container89 />
    </div>
  );
}

function Component7() {
  return (
    <a
      className="bg-[#f8f8f8] cursor-pointer relative shrink-0 w-full"
      data-name="Component 7"
      href="https://cobalt.sgdatacatalogue.net/datasets"
    >
      <div className="relative size-full">
        <div className="box-border content-stretch flex flex-col items-start justify-start px-4 py-2 relative w-full">
          <div
            className="flex flex-col font-['Roboto:Regular',_sans-serif] font-normal justify-center leading-[0] relative shrink-0 text-[#1a1a1a] text-[0px] text-left text-nowrap tracking-[0.15px]"
            role="link"
            style={{ fontVariationSettings: "'wdth' 100" }}
            tabIndex="0"
          >
            <p
              className="adjustLetterSpacing block cursor-pointer leading-[32px] text-[16px] whitespace-pre"
              style={{ fontVariationSettings: "'wdth' 100" }}
            >
              Datasets
            </p>
          </div>
          <div
            className="absolute bg-[#1a1a1a] bottom-0 h-[2.55px] left-0 right-0"
            data-name="Background"
          />
        </div>
      </div>
    </a>
  );
}

function Item15() {
  return (
    <div
      className="box-border content-stretch flex flex-col items-start justify-start p-0 relative self-stretch shrink-0"
      data-name="Item"
    >
      <Component7 />
    </div>
  );
}

function Component47() {
  return (
    <a
      className="cursor-pointer relative shrink-0 w-full"
      data-name="Component 5"
      href="https://cobalt.sgdatacatalogue.net/organisations"
    >
      <div className="relative size-full">
        <div className="box-border content-stretch flex flex-col items-start justify-start px-4 py-2 relative w-full">
          <div
            className="flex flex-col font-['Roboto:Regular',_sans-serif] font-normal justify-center leading-[0] relative shrink-0 text-[0px] text-[rgba(0,0,0,0.87)] text-left text-nowrap tracking-[0.15px]"
            style={{ fontVariationSettings: "'wdth' 100" }}
          >
            <p
              className="adjustLetterSpacing block cursor-pointer leading-[32px] text-[16px] whitespace-pre"
              role="link"
              style={{ fontVariationSettings: "'wdth' 100" }}
              tabIndex="0"
            >
              Organisations
            </p>
          </div>
        </div>
      </div>
    </a>
  );
}

function Item16() {
  return (
    <div
      className="box-border content-stretch flex flex-col items-start justify-start p-0 relative self-stretch shrink-0"
      data-name="Item"
    >
      <Component47 />
    </div>
  );
}

function Component48() {
  return (
    <a
      className="cursor-pointer relative shrink-0 w-full"
      data-name="Component 5"
      href="https://cobalt.sgdatacatalogue.net/themes"
    >
      <div className="relative size-full">
        <div className="box-border content-stretch flex flex-col items-start justify-start px-4 py-2 relative w-full">
          <div
            className="flex flex-col font-['Roboto:Regular',_sans-serif] font-normal justify-center leading-[0] relative shrink-0 text-[0px] text-[rgba(0,0,0,0.87)] text-left text-nowrap tracking-[0.15px]"
            style={{ fontVariationSettings: "'wdth' 100" }}
          >
            <p
              className="adjustLetterSpacing block cursor-pointer leading-[32px] text-[16px] whitespace-pre"
              role="link"
              style={{ fontVariationSettings: "'wdth' 100" }}
              tabIndex="0"
            >
              Themes
            </p>
          </div>
        </div>
      </div>
    </a>
  );
}

function Item17() {
  return (
    <div
      className="box-border content-stretch flex flex-col items-start justify-start p-0 relative self-stretch shrink-0"
      data-name="Item"
    >
      <Component48 />
    </div>
  );
}

function Component49() {
  return (
    <a
      className="cursor-pointer relative shrink-0 w-full"
      data-name="Component 5"
      href="https://cobalt.sgdatacatalogue.net/about"
    >
      <div className="relative size-full">
        <div className="box-border content-stretch flex flex-col items-start justify-start px-4 py-2 relative w-full">
          <div
            className="flex flex-col font-['Roboto:Regular',_sans-serif] font-normal justify-center leading-[0] relative shrink-0 text-[0px] text-[rgba(0,0,0,0.87)] text-left text-nowrap tracking-[0.15px]"
            style={{ fontVariationSettings: "'wdth' 100" }}
          >
            <p
              className="adjustLetterSpacing block cursor-pointer leading-[32px] text-[16px] whitespace-pre"
              role="link"
              style={{ fontVariationSettings: "'wdth' 100" }}
              tabIndex="0"
            >
              About
            </p>
          </div>
        </div>
      </div>
    </a>
  );
}

function Item18() {
  return (
    <div
      className="box-border content-stretch flex flex-col items-start justify-start p-0 relative self-stretch shrink-0"
      data-name="Item"
    >
      <Component49 />
    </div>
  );
}

function Component50() {
  return (
    <a
      className="cursor-pointer relative shrink-0 w-full"
      data-name="Component 5"
      href="https://cobalt.sgdatacatalogue.net/help"
    >
      <div className="relative size-full">
        <div className="box-border content-stretch flex flex-col items-start justify-start px-4 py-2 relative w-full">
          <div
            className="flex flex-col font-['Roboto:Regular',_sans-serif] font-normal justify-center leading-[0] relative shrink-0 text-[0px] text-[rgba(0,0,0,0.87)] text-left text-nowrap tracking-[0.15px]"
            style={{ fontVariationSettings: "'wdth' 100" }}
          >
            <p
              className="adjustLetterSpacing block cursor-pointer leading-[32px] text-[16px] whitespace-pre"
              role="link"
              style={{ fontVariationSettings: "'wdth' 100" }}
              tabIndex="0"
            >
              Help
            </p>
          </div>
        </div>
      </div>
    </a>
  );
}

function Item19() {
  return (
    <div
      className="box-border content-stretch flex flex-col items-start justify-start p-0 relative self-stretch shrink-0"
      data-name="Item"
    >
      <Component50 />
    </div>
  );
}

function NavList() {
  return (
    <div
      className="[flex-flow:wrap] box-border content-stretch flex gap-0 items-start justify-start p-0 relative shrink-0 w-full"
      data-name="Nav → List"
    >
      <Item15 />
      <Item16 />
      <Item17 />
      <Item18 />
      <Item19 />
    </div>
  );
}

function Container91() {
  return (
    <div
      className="box-border content-stretch flex flex-col items-start justify-start pl-0 pr-4 py-0 relative shrink-0 w-[1152px]"
      data-name="Container"
    >
      <NavList />
    </div>
  );
}

function HorizontalBorder() {
  return (
    <div
      className="box-border content-stretch flex flex-col items-center justify-start p-0 relative shrink-0 w-full"
      data-name="HorizontalBorder"
    >
      <div className="absolute border-[#ebebeb] border-[1px_0px_0px] border-solid inset-0 pointer-events-none" />
      <Container91 />
    </div>
  );
}

function Strong1() {
  return (
    <div
      className="bg-[#d9eeff] box-border content-stretch flex flex-col items-start justify-start px-2 py-0 relative shrink-0"
      data-name="Strong"
    >
      <div className="absolute inset-px" data-name="Strong:outline">
        <div className="absolute border border-[rgba(0,101,189,0.64)] border-solid inset-[-1px] pointer-events-none" />
      </div>
      <div
        className="flex flex-col font-['Roboto:Regular',_sans-serif] font-normal justify-center leading-[0] relative shrink-0 text-[#00437d] text-[16px] text-left text-nowrap tracking-[0.15px]"
        style={{ fontVariationSettings: "'wdth' 100" }}
      >
        <p className="adjustLetterSpacing block leading-[24px] whitespace-pre">
          Alpha
        </p>
      </div>
    </div>
  );
}

function StrongMargin() {
  return (
    <div
      className="box-border content-stretch flex flex-col items-start justify-start pl-0 pr-4 py-0 relative shrink-0"
      data-name="Strong:margin"
    >
      <Strong1 />
    </div>
  );
}

function Component51() {
  return (
    <div
      className="box-border content-stretch flex flex-row items-start justify-start p-0 relative shrink-0"
      data-name="Component 5"
    >
      <div
        className="flex flex-col font-['Roboto:Regular',_sans-serif] font-normal justify-center leading-[0] relative shrink-0 text-[#0065bd] text-[0px] text-left text-nowrap tracking-[0.15px]"
        style={{ fontVariationSettings: "'wdth' 100" }}
      >
        <a
          className="[text-decoration-line:underline] [text-decoration-style:solid] [text-underline-position:from-font] adjustLetterSpacing block cursor-pointer leading-[24px] text-[16px] whitespace-pre"
          href="mailto:statistics.opendata@gov.scot"
          style={{ fontVariationSettings: "'wdth' 100" }}
        >
          feedback
        </a>
      </div>
    </div>
  );
}

function Container92() {
  return (
    <div
      className="box-border content-stretch flex flex-row items-start justify-start p-0 relative shrink-0"
      data-name="Container"
    >
      <div
        className="flex flex-col font-['Roboto:Regular',_sans-serif] font-normal justify-center leading-[0] relative shrink-0 text-[16px] text-[rgba(0,0,0,0.87)] text-left text-nowrap tracking-[0.15px]"
        style={{ fontVariationSettings: "'wdth' 100" }}
      >
        <p className="adjustLetterSpacing block leading-[24px] whitespace-pre">{`This is a new service. Your `}</p>
      </div>
      <Component51 />
      <div
        className="flex flex-col font-['Roboto:Regular',_sans-serif] font-normal justify-center leading-[0] relative shrink-0 text-[16px] text-[rgba(0,0,0,0.87)] text-left text-nowrap tracking-[0.15px]"
        style={{ fontVariationSettings: "'wdth' 100" }}
      >
        <p className="adjustLetterSpacing block leading-[24px] whitespace-pre">{` will help us to improve it.`}</p>
      </div>
    </div>
  );
}

function Container93() {
  return (
    <div
      className="box-border content-stretch flex flex-row items-start justify-start p-0 relative shrink-0 w-full"
      data-name="Container"
    >
      <StrongMargin />
      <Container92 />
    </div>
  );
}

function Container94() {
  return (
    <div
      className="box-border content-stretch flex flex-col items-start justify-start px-4 py-0 relative shrink-0 w-[1152px]"
      data-name="Container"
    >
      <Container93 />
    </div>
  );
}

function Background1() {
  return (
    <div
      className="bg-[#ebebeb] box-border content-stretch flex flex-col items-center justify-start px-0 py-4 relative shrink-0 w-full"
      data-name="Background"
    >
      <Container94 />
    </div>
  );
}

function Banner() {
  return (
    <div
      className="absolute bg-[#ffffff] box-border content-stretch flex flex-col h-[173px] items-center justify-start left-0 pb-px pt-0 px-0 top-0 w-[1920px]"
      data-name="Banner"
    >
      <div className="absolute border-[#ebebeb] border-[0px_0px_1px] border-solid inset-0 pointer-events-none shadow-[0px_2px_4px_0px_rgba(0,0,0,0.1)]" />
      <div
        className="h-1 relative shrink-0 w-full"
        data-name="HorizontalBorder"
      >
        <div className="absolute border-[#0065bd] border-[4px_0px_0px] border-solid inset-0 pointer-events-none" />
      </div>
      <Container90 />
      <HorizontalBorder />
      <Background1 />
    </div>
  );
}

function Component1920WLight() {
  return (
    <div
      className="absolute bg-[#ffffff] box-border content-stretch flex flex-col items-start justify-start left-[100px] p-0 right-[100px] top-[100px]"
      data-name="1920w light"
    >
      <Banner />
      <Container83 />
    </div>
  );
}

export default function CobaltSgdatacatalogueNetEnglishUsByHtmlToDesignFreeVersion24062025101619Bst() {
  return (
    <div
      className="bg-[#ffffff] relative rounded-sm size-full"
      data-name="cobalt.sgdatacatalogue.net (English-US) by html.to.design ❤️ FREE version - 24/06/2025, 10:16:19 BST"
    >
      <div className="overflow-clip relative size-full">
        <Component1920WLight />
      </div>
      <div className="absolute border border-[rgba(0,0,0,0.1)] border-solid inset-0 pointer-events-none rounded-sm" />
    </div>
  );
}