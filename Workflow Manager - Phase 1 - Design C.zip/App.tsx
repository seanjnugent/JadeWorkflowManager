import { useState, useEffect } from "react";
import { Header } from "./components/Header";
import { Hero } from "./components/Hero";
import { DataTiles } from "./components/DataTiles";
import { Data } from "./components/Data";
import { Organisations } from "./components/Organisations";

import { HealthSurvey } from "./components/HealthSurvey";
import { RunId } from "./components/RunId";
import { Journey } from "./components/Journey";
import { Step2Upload } from "./components/Step2Upload";
import { Step3Preview } from "./components/Step3Preview";
import { Step4Metadata } from "./components/Step4Metadata";
import { Step5Summary } from "./components/Step5Summary";
import { Step6QualityChecks } from "./components/Step6QualityChecks";
import { Step7Finalise } from "./components/Step7Finalise";
import { DataBySex } from "./components/DataBySex";
import { Help } from "./components/Help";
import { About } from "./components/About";
import { Contact } from "./components/Contact";
import { Footer } from "./components/Footer";

export default function App() {
  const [currentPage, setCurrentPage] = useState('home');

  useEffect(() => {
    const handleHashChange = () => {
      const hash = window.location.hash;
      let newPage = 'home';
      
      if (hash === '#/data') {
        newPage = 'data';
      } else if (hash === '#/organisations') {
        newPage = 'organisations';

      } else if (hash === '#/health-survey') {
        newPage = 'health-survey';
      } else if (hash === '#/run-id') {
        newPage = 'run-id';
      } else if (hash === '#/journey') {
        newPage = 'journey';
      } else if (hash === '#/step2-upload') {
        newPage = 'step2-upload';
      } else if (hash === '#/step3-preview') {
        newPage = 'step3-preview';
      } else if (hash === '#/step4-metadata') {
        newPage = 'step4-metadata';
      } else if (hash === '#/step5-summary') {
        newPage = 'step5-summary';
      } else if (hash === '#/step6-quality-checks') {
        newPage = 'step6-quality-checks';
      } else if (hash === '#/step7-finalise') {
        newPage = 'step7-finalise';
      } else if (hash === '#/data-by-sex') {
        newPage = 'data-by-sex';
      } else if (hash === '#/help') {
        newPage = 'help';
      } else if (hash === '#/about') {
        newPage = 'about';
      } else if (hash === '#/contact') {
        newPage = 'contact';
      }
      
      // Only scroll to top if the page actually changed
      if (newPage !== currentPage) {
        window.scrollTo(0, 0);
      }
      
      setCurrentPage(newPage);
    };

    // Check initial hash
    handleHashChange();
    
    // Listen for hash changes
    window.addEventListener('hashchange', handleHashChange);
    
    return () => {
      window.removeEventListener('hashchange', handleHashChange);
    };
  }, [currentPage]);

  return (
    <div className="min-h-screen bg-white">
      <Header currentPage={currentPage} />
      
      {currentPage === 'home' ? (
        <main>
          <Hero />
          <DataTiles />
        </main>
      ) : currentPage === 'data' ? (
        <main>
          <Data />
        </main>
      ) : currentPage === 'organisations' ? (
        <main>
          <Organisations />
        </main>

      ) : currentPage === 'health-survey' ? (
        <main>
          <HealthSurvey />
        </main>
      ) : currentPage === 'run-id' ? (
        <main>
          <RunId />
        </main>
      ) : currentPage === 'journey' ? (
        <main>
          <Journey />
        </main>
      ) : currentPage === 'step2-upload' ? (
        <main>
          <Step2Upload />
        </main>
      ) : currentPage === 'step3-preview' ? (
        <main>
          <Step3Preview />
        </main>
      ) : currentPage === 'step4-metadata' ? (
        <main>
          <Step4Metadata />
        </main>
      ) : currentPage === 'step5-summary' ? (
        <main>
          <Step5Summary />
        </main>
      ) : currentPage === 'step6-quality-checks' ? (
        <main>
          <Step6QualityChecks />
        </main>
      ) : currentPage === 'step7-finalise' ? (
        <main>
          <Step7Finalise />
        </main>
      ) : currentPage === 'data-by-sex' ? (
        <main>
          <DataBySex />
        </main>
      ) : currentPage === 'help' ? (
        <main>
          <Help />
        </main>
      ) : currentPage === 'about' ? (
        <main>
          <About />
        </main>
      ) : currentPage === 'contact' ? (
        <main>
          <Contact />
        </main>
      ) : (
        <main>
          <Hero />
          <DataTiles />
        </main>
      )}
      
      <Footer />
    </div>
  );
}