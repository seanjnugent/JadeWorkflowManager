import { Settings, LogOut } from "lucide-react";
import svgPaths from "../imports/svg-tmym2azjca";

interface HeaderProps {
  currentPage?: string;
}

export function Header({ currentPage = 'home' }: HeaderProps) {
  return (
    <>
      <header className="sg-banner">
        <div className="sg-banner-container">
          {/* Logo and title section */}
          <div className="flex items-center justify-between py-6">
            <div className="flex items-center gap-6">
              <a href="#/" className="sg-logo-link cursor-pointer">
                <div className="w-[269px] h-10 relative">
                  <svg
                    className="block w-full h-full"
                    fill="none"
                    preserveAspectRatio="none"
                    viewBox="0 0 270 40"
                  >
                    <g clipPath="url(#clip0_1_229)">
                      <path
                        d="M0 0H60.9772V37.6547H0V0Z"
                        fill="white"
                      />
                      <path
                        d={svgPaths.p6de980}
                        fill="#0065BD"
                      />
                      <path
                        d={svgPaths.p5307000}
                        fill="#858B91"
                      />
                      <path
                        d={svgPaths.p19f11d00}
                        fill="#333E48"
                      />
                    </g>
                    <defs>
                      <clipPath id="clip0_1_229">
                        <rect fill="white" height="40" width="269.316" />
                      </clipPath>
                    </defs>
                  </svg>
                </div>
              </a>
            </div>

            {/* User controls */}
            <div className="flex items-center gap-3">
              <button 
                className="flex items-center gap-2 px-4 py-2 border-2 border-[#5e5e5e] bg-white text-[#5e5e5e] hover:bg-[#f8f8f8] transition-colors duration-200 font-medium rounded-[4px]"
                aria-label="Account settings"
              >
                <Settings className="w-4 h-4" />
                <span className="text-sm font-medium">Settings</span>
              </button>
              
              <button 
                className="flex items-center gap-2 px-4 py-2 border-2 border-[#5e5e5e] bg-white text-[#5e5e5e] hover:bg-[#f8f8f8] transition-colors duration-200 font-medium rounded-[4px]"
                aria-label="Logout"
              >
                <LogOut className="w-4 h-4" />
                <span className="text-sm font-medium">Logout</span>
              </button>
            </div>
          </div>

          {/* Navigation */}
          <nav className="border-t border-gray-200">
            <div className="sg-nav-container flex items-center py-2">
              <a 
                href="#/data" 
                className={`sg-nav-link ${currentPage === 'data' ? 'sg-nav-link-active' : ''}`}
              >
                Workflows
              </a>
              <a 
                href="#/organisations" 
                className={`sg-nav-link ${currentPage === 'organisations' ? 'sg-nav-link-active' : ''}`}
              >
                Run history
              </a>
              <a 
                href="#/about" 
                className={`sg-nav-link ${currentPage === 'about' ? 'sg-nav-link-active' : ''}`}
              >
                About
              </a>
              <a 
                href="#/help" 
                className={`sg-nav-link ${currentPage === 'help' ? 'sg-nav-link-active' : ''}`}
              >
                Help
              </a>
              <a 
                href="#/contact" 
                className={`sg-nav-link ${currentPage === 'contact' ? 'sg-nav-link-active' : ''}`}
              >
                Contact
              </a>
            </div>
          </nav>
        </div>
      </header>

      {/* Alpha notice - outside of main container to span full width */}
      <div className="sg-alpha-notice">
        <div className="sg-alpha-notice-container">
          <div className="sg-alpha-badge">Alpha</div>
          <span>This is a new service. Your</span>
          <a href="mailto:statistics.opendata@gov.scot">feedback</a>
          <span>will help us to improve it.</span>
        </div>
      </div>
    </>
  );
}