import { useState, useEffect, useRef } from "react";
import { ChevronDown, FileSpreadsheet, ArrowRight } from "lucide-react";

export function HealthSurvey() {
  const [showMoreInfo, setShowMoreInfo] = useState(false);
  const [showDownloadDropdown, setShowDownloadDropdown] = useState(false);
  const [activeSection, setActiveSection] = useState<string>('summary'); // Start with 'summary' as default
  const [showGuide1Dropdown, setShowGuide1Dropdown] = useState(false);
  const [showGuide2Dropdown, setShowGuide2Dropdown] = useState(false);
  
  const downloadDropdownRef = useRef<HTMLDivElement>(null);
  const guide1DropdownRef = useRef<HTMLDivElement>(null);
  const guide2DropdownRef = useRef<HTMLDivElement>(null);

  const handleJumpLinkClick = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      // Calculate offset to align section header with Contents title
      // Sticky nav top (24px) + Contents title height + some spacing = ~45px offset
      const offset = 45;
      const elementPosition = element.getBoundingClientRect().top + window.pageYOffset - offset;
      
      window.scrollTo({
        top: elementPosition,
        behavior: 'smooth'
      });
    }
  };

  // Scroll spy functionality
  useEffect(() => {
    const sections = [
      'summary',
      'metadata',
      'data-quality',
      'additional-details'
    ];

    const observerOptions = {
      root: null,
      rootMargin: '-45px 0px -60% 0px', // Adjusted to account for our offset
      threshold: 0
    };

    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          setActiveSection(entry.target.id);
        }
      });
    }, observerOptions);

    // Observe all sections
    sections.forEach((sectionId) => {
      const element = document.getElementById(sectionId);
      if (element) {
        observer.observe(element);
      }
    });

    // Handle scroll to top - ensure 'About this data' is highlighted when at top
    const handleScroll = () => {
      const scrollPosition = window.pageYOffset || document.documentElement.scrollTop;
      
      // If we're at the top of the page (within 100px), highlight the first section
      if (scrollPosition < 100) {
        setActiveSection('summary');
      }
    };

    // Add scroll listener
    window.addEventListener('scroll', handleScroll);
    
    // Check initial scroll position
    handleScroll();

    return () => {
      sections.forEach((sectionId) => {
        const element = document.getElementById(sectionId);
        if (element) {
          observer.unobserve(element);
        }
      });
      window.removeEventListener('scroll', handleScroll);
    };
  }, []);

  const toggleMoreInfo = () => {
    setShowMoreInfo(!showMoreInfo);
  };

  const toggleDownloadDropdown = () => {
    setShowDownloadDropdown(!showDownloadDropdown);
  };

  const toggleGuide1Dropdown = () => {
    setShowGuide1Dropdown(!showGuide1Dropdown);
  };

  const toggleGuide2Dropdown = () => {
    setShowGuide2Dropdown(!showGuide2Dropdown);
  };

  const handleDownload = (format: string) => {
    console.log(`Downloading in ${format} format`);
    setShowDownloadDropdown(false);
  };

  const handleGuide1Download = (format: string) => {
    console.log(`Downloading User guide for workflow: Update existing resource & metadata in ${format} format`);
    setShowGuide1Dropdown(false);
  };

  const handleGuide2Download = (format: string) => {
    console.log(`Downloading User guide for workflow manager data quality in ${format} format`);
    setShowGuide2Dropdown(false);
  };

  const handleViewData = () => {
    console.log('Navigating to data by sex page');
    window.location.hash = '#/data-by-sex';
  };

  const handleTileClick = (e: React.MouseEvent) => {
    // Check if the click was on the download button or its children
    const target = e.target as HTMLElement;
    const downloadButton = downloadDropdownRef.current;
    
    if (downloadButton && (downloadButton.contains(target) || downloadButton === target)) {
      // Click was on download button, don't navigate
      return;
    }
    
    // Navigate to data page
    handleViewData();
  };

  const handleInactiveTileClick = (e: React.MouseEvent) => {
    // Do nothing - inactive tiles have no functionality
    e.preventDefault();
  };

  const handleInactiveButtonClick = (e: React.MouseEvent) => {
    // Do nothing - inactive buttons have no functionality
    e.preventDefault();
    e.stopPropagation();
  };

  // Close dropdowns when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (downloadDropdownRef.current && !downloadDropdownRef.current.contains(event.target as Node)) {
        setShowDownloadDropdown(false);
      }
      if (guide1DropdownRef.current && !guide1DropdownRef.current.contains(event.target as Node)) {
        setShowGuide1Dropdown(false);
      }
      if (guide2DropdownRef.current && !guide2DropdownRef.current.contains(event.target as Node)) {
        setShowGuide2Dropdown(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  // Helper function to determine if a section is active
  const isActiveSection = (sectionId: string) => {
    return activeSection === sectionId;
  };

  return (
    <div className="min-h-screen bg-white">
      {/* Blue page header section with reduced bottom padding */}
      <div className="sg-page-header" style={{ paddingBottom: '24px' }}>
        <div className="sg-page-header-container">
          {/* Breadcrumb */}
          <nav className="sg-page-header-breadcrumb">
            <div className="flex items-center gap-2 text-base">
              <a 
                href="#/" 
                className="text-white hover:text-[#d9eeff] hover:no-underline underline cursor-pointer transition-colors duration-200"
              >
                Home
              </a>
              <span className="text-white">&gt;</span>
              <a 
                href="#/data" 
                className="text-white hover:text-[#d9eeff] hover:no-underline underline cursor-pointer transition-colors duration-200"
              >
                Workflows
              </a>
              <span className="text-white">&gt;</span>
              <span className="text-white">Update existing resource & metadata</span>
            </div>
          </nav>

          {/* Page title */}
          <h1 className="sg-page-header-title">
            Update existing resource & metadata
          </h1>

          {/* Page description - constrained to 75% width */}
          <div className="w-3/4">
            <p className="sg-page-header-description">
              Make changes to an existing dataset's resource and its associated metadata. This is useful for updating data files and metadata, and revising descriptions and tags.
            </p>
          </div>

          {/* Hero tiles removed */}
        </div>
      </div>

      <div className="max-w-[1200px] mx-auto px-6 py-8">
        <div className="flex gap-8">
          {/* Sidebar - 25% width with sticky contents */}
          <div className="w-1/4 shrink-0">
            {/* Contents */}
            <div className="sg-contents-sticky">
              <h2 className="text-[24px] font-bold text-black leading-[32px] tracking-[0.15px] mb-4">
                Contents
              </h2>
              
              <nav>
                <ul className="sg-contents-nav">
                  <li className="sg-contents-item">
                    <button
                      onClick={() => handleJumpLinkClick('summary')}
                      className={`sg-contents-link w-full text-left ${isActiveSection('summary') ? 'sg-contents-link-active' : ''}`}
                    >
                      Overview
                    </button>
                  </li>
                  <li className="sg-contents-item">
                    <button
                      onClick={() => handleJumpLinkClick('metadata')}
                      className={`sg-contents-link w-full text-left ${isActiveSection('metadata') ? 'sg-contents-link-active' : ''}`}
                    >
                      Run history
                    </button>
                  </li>
                  <li className="sg-contents-item">
                    <button
                      onClick={() => handleJumpLinkClick('data-quality')}
                      className={`sg-contents-link w-full text-left ${isActiveSection('data-quality') ? 'sg-contents-link-active' : ''}`}
                    >
                      Version control
                    </button>
                  </li>
                  <li className="sg-contents-item">
                    <button
                      onClick={() => handleJumpLinkClick('additional-details')}
                      className={`sg-contents-link w-full text-left ${isActiveSection('additional-details') ? 'sg-contents-link-active' : ''}`}
                    >
                      Help and user guides
                    </button>
                  </li>
                </ul>
              </nav>
            </div>
          </div>

          {/* Main content - 75% width */}
          <div className="w-3/4">
            {/* Overview Section - positioned to align with Contents title */}
            <section id="summary" className="mb-12 pt-6">
              <div className="sg-section-separator">
                <div className="flex items-center justify-between mb-2">
                  <h2 className="text-[24px] font-bold text-black leading-[32px] tracking-[0.15px]">
                    Overview
                  </h2>
                  <a 
                    href="#/journey" 
                    className="inline-flex items-center gap-2 px-5 py-3 bg-[#0065bd] text-white text-[18px] leading-[24px] font-medium rounded hover:bg-[#004a9f] transition-colors duration-200 no-underline"
                  >
                    Begin workflow
                    <ArrowRight className="w-4 h-4" />
                  </a>
                </div>
              </div>
              <div className="prose prose-lg max-w-none">
                <p className="text-[19px] leading-[32px] tracking-[0.15px] text-[#333333] mb-8">
                  Use this workflow to update an existing resource on data.gov.scot as well as its associated metadata. To begin, click the 'Begin workflow' button.
                </p>
                
                {/* Workflow information table */}
                <table className="sg-table mb-8">
                  <tbody>
                    <tr>
                      <th className="w-1/2">Workflow name</th>
                      <td>Update existing resource & metadata</td>
                    </tr>
                    <tr>
                      <th>Workflow ID</th>
                      <td>WF101</td>
                    </tr>
                    <tr>
                      <th>Workflow maintainer</th>
                      <td>Platform Engineer, Data Division</td>
                    </tr>
                    <tr>
                      <th>Workflow created</th>
                      <td>01-01-2025</td>
                    </tr>
                    <tr>
                      <th>Last run</th>
                      <td>15-06-2025</td>
                    </tr>
                    <tr>
                      <th>Current workflow GitHub version</th>
                      <td>v2.1.1</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </section>

            {/* Run history Section */}
            <section id="metadata" className="mb-12">
              <div className="sg-section-separator">
                <h2 className="text-[24px] font-bold text-black leading-[32px] tracking-[0.15px] mb-2">
                  Run history
                </h2>
              </div>
              
              <div className="prose prose-lg max-w-none">
                <p className="text-[19px] leading-[32px] tracking-[0.15px] text-[#333333] mb-6">
                  Here are the latest 5 runs of this workflow. Click on a run for more information.
                </p>
                <div className="space-y-6">
                  {/* Run ID #10 */}
                  <a 
                    href="#/run-id"
                    className="sg-dataset-tile block"
                  >
                    <h3 className="sg-dataset-title">
                      Run ID #10
                    </h3>
                    
                    <div className="flex items-center gap-4 text-[14px] text-[#5e5e5e] leading-[24px] tracking-[0.15px] mb-3">
                      <span>Status: Complete</span>
                      <span>Date: 15-06-2025</span>
                      <span>Run by: Alex Campbell</span>
                      <span>Workflow ID: WF101</span>
                    </div>

                    <p className="sg-dataset-description">
                      Run name to be entered by user when workflow first triggered.
                    </p>
                  </a>

                  {/* Run ID #8 */}
                  <a 
                    href="#/run-id"
                    className="sg-dataset-tile block"
                  >
                    <h3 className="sg-dataset-title">
                      Run ID #8
                    </h3>
                    
                    <div className="flex items-center gap-4 text-[14px] text-[#5e5e5e] leading-[24px] tracking-[0.15px] mb-3">
                      <span>Status: Complete</span>
                      <span>Date: 13-06-2025</span>
                      <span>Run by: Alex Campbell</span>
                      <span>Workflow ID: WF101</span>
                    </div>

                    <p className="sg-dataset-description">
                      Run name to be entered by user when workflow first triggered.
                    </p>
                  </a>

                  {/* Run ID #7 */}
                  <a 
                    href="#/run-id"
                    className="sg-dataset-tile block"
                  >
                    <h3 className="sg-dataset-title">
                      Run ID #7
                    </h3>
                    
                    <div className="flex items-center gap-4 text-[14px] text-[#5e5e5e] leading-[24px] tracking-[0.15px] mb-3">
                      <span>Status: Running</span>
                      <span>Date: 12-06-2025</span>
                      <span>Run by: Fiona Smith</span>
                      <span>Workflow ID: WF101</span>
                    </div>

                    <p className="sg-dataset-description">
                      Run name to be entered by user when workflow first triggered.
                    </p>
                  </a>

                  {/* Run ID #3 */}
                  <a 
                    href="#/run-id"
                    className="sg-dataset-tile block"
                  >
                    <h3 className="sg-dataset-title">
                      Run ID #3
                    </h3>
                    
                    <div className="flex items-center gap-4 text-[14px] text-[#5e5e5e] leading-[24px] tracking-[0.15px] mb-3">
                      <span>Status: Running</span>
                      <span>Date: 08-06-2025</span>
                      <span>Run by: Fiona Smith</span>
                      <span>Workflow ID: WF101</span>
                    </div>

                    <p className="sg-dataset-description">
                      Run name to be entered by user when workflow first triggered.
                    </p>
                  </a>

                  {/* Run ID #2 */}
                  <a 
                    href="#/run-id"
                    className="sg-dataset-tile block"
                  >
                    <h3 className="sg-dataset-title">
                      Run ID #2
                    </h3>
                    
                    <div className="flex items-center gap-4 text-[14px] text-[#5e5e5e] leading-[24px] tracking-[0.15px] mb-3">
                      <span>Status: Complete</span>
                      <span>Date: 07-06-2025</span>
                      <span>Run by: Alex Campbell</span>
                      <span>Workflow ID: WF101</span>
                    </div>

                    <p className="sg-dataset-description">
                      Run name to be entered by user when workflow first triggered.
                    </p>
                  </a>
                </div>
              </div>
            </section>

            {/* Version control Section */}
            <section id="data-quality" className="mb-12">
              <div className="sg-section-separator">
                <h2 className="text-[24px] font-bold text-black leading-[32px] tracking-[0.15px] mb-2">
                  Version control
                </h2>
              </div>
              
              <div className="prose prose-lg max-w-none">
                <p className="text-[19px] leading-[32px] tracking-[0.15px] text-[#333333] mb-4">
                  We use GitHub to manage, share, and maintain our workflows and platform. This allows us to share what we build, knowing things are consistent, version controlled and transparent. For more information:
                </p>
                <ul className="list-disc list-inside space-y-2 mb-8 ml-4 text-[19px] leading-[32px] tracking-[0.15px] text-[#333333]">
                  <li>
                    <a 
                      href="#/github-workflow" 
                      className="text-[#0065bd] hover:text-[#004a9f] underline hover:no-underline transition-colors duration-200"
                    >
                      GitHub repository: Update existing resource & metadata workflow
                    </a>
                  </li>
                  <li>
                    <a 
                      href="#/github-platform" 
                      className="text-[#0065bd] hover:text-[#004a9f] underline hover:no-underline transition-colors duration-200"
                    >
                      GitHub repository: Workflow manager platform
                    </a>
                  </li>
                  <li>
                    <a 
                      href="#/github-guide" 
                      className="text-[#0065bd] hover:text-[#004a9f] underline hover:no-underline transition-colors duration-200"
                    >
                      GitHub user guide
                    </a>
                  </li>
                </ul>
              </div>
            </section>

            {/* Help and user guides Section */}
            <section id="additional-details" className="mb-12">
              <div className="sg-section-separator">
                <h2 className="text-[24px] font-bold text-black leading-[32px] tracking-[0.15px] mb-2">
                  Help and user guides
                </h2>
              </div>
              
              <div className="prose prose-lg max-w-none">
                <div className="space-y-6">
                  {/* User guide 1 */}
                  <div className="sg-dataset-tile">
                    <div className="flex items-start justify-between mb-3">
                      <h3 className="sg-dataset-title flex-1 mr-4">
                        User guide for workflow: Update existing resource & metadata
                      </h3>
                      <div className="relative" ref={guide1DropdownRef}>
                        <button 
                          onClick={toggleGuide1Dropdown}
                          className="px-4 py-2 bg-[#0065bd] text-white font-medium rounded hover:bg-[#004a9f] transition-colors duration-200 flex items-center whitespace-nowrap"
                        >
                          Download
                          <ChevronDown className="w-4 h-4 ml-2" />
                        </button>
                        {showGuide1Dropdown && (
                          <div className="absolute top-full right-0 mt-1 bg-white border border-[#b3b3b3] rounded shadow-lg z-1000 min-w-[120px]">
                            <button 
                              onClick={() => handleGuide1Download('DOCX')}
                              className="block w-full px-3 py-2 text-left text-sm text-[#333333] hover:bg-[#f8f8f8] transition-colors duration-200 border-none bg-none cursor-pointer"
                            >
                              DOCX
                            </button>
                            <button 
                              onClick={() => handleGuide1Download('PDF')}
                              className="block w-full px-3 py-2 text-left text-sm text-[#333333] hover:bg-[#f8f8f8] transition-colors duration-200 border-none bg-none cursor-pointer"
                            >
                              PDF
                            </button>
                          </div>
                        )}
                      </div>
                    </div>
                    
                    <div className="flex items-center gap-4 text-[14px] text-[#5e5e5e] leading-[24px] tracking-[0.15px] mb-3">
                      <span>Size: 1.4MB</span>
                      <span>Format: Docx, PDF</span>
                      <span>Last updated: 15-06-2025</span>
                    </div>

                    <p className="sg-dataset-description">
                      Comprehensive guide for users on how to update existing resources and their associated metadata. Includes step-by-step instructions, best practices, and troubleshooting tips.
                    </p>
                  </div>

                  {/* User guide 2 */}
                  <div className="sg-dataset-tile">
                    <div className="flex items-start justify-between mb-3">
                      <h3 className="sg-dataset-title flex-1 mr-4">
                        User guide for workflow manager data quality
                      </h3>
                      <div className="relative" ref={guide2DropdownRef}>
                        <button 
                          onClick={toggleGuide2Dropdown}
                          className="px-4 py-2 bg-[#0065bd] text-white font-medium rounded hover:bg-[#004a9f] transition-colors duration-200 flex items-center whitespace-nowrap"
                        >
                          Download
                          <ChevronDown className="w-4 h-4 ml-2" />
                        </button>
                        {showGuide2Dropdown && (
                          <div className="absolute top-full right-0 mt-1 bg-white border border-[#b3b3b3] rounded shadow-lg z-1000 min-w-[120px]">
                            <button 
                              onClick={() => handleGuide2Download('DOCX')}
                              className="block w-full px-3 py-2 text-left text-sm text-[#333333] hover:bg-[#f8f8f8] transition-colors duration-200 border-none bg-none cursor-pointer"
                            >
                              DOCX
                            </button>
                            <button 
                              onClick={() => handleGuide2Download('PDF')}
                              className="block w-full px-3 py-2 text-left text-sm text-[#333333] hover:bg-[#f8f8f8] transition-colors duration-200 border-none bg-none cursor-pointer"
                            >
                              PDF
                            </button>
                          </div>
                        )}
                      </div>
                    </div>
                    
                    <div className="flex items-center gap-4 text-[14px] text-[#5e5e5e] leading-[24px] tracking-[0.15px] mb-3">
                      <span>Size: 1.4MB</span>
                      <span>Format: Docx, PDF</span>
                      <span>Last updated: 12-06-2025</span>
                    </div>

                    <p className="sg-dataset-description">
                      Essential guide for workflow managers on maintaining and ensuring data quality throughout the workflow process. Covers quality standards, validation procedures, and monitoring techniques.
                    </p>
                  </div>
                </div>
              </div>
            </section>
          </div>
        </div>
      </div>
    </div>
  );
}