import { useState, useEffect } from "react";

export function About() {
  const [activeSection, setActiveSection] = useState<string>('our-mission'); // Start with 'our-mission' as default

  const handleJumpLinkClick = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      // Calculate offset to align section header with Contents title
      // Sticky nav top (24px) + Contents title height + some spacing = ~45px offset
      const offset = 45;
      const elementPosition = element.getBoundingClientRect().top + window.pageYOffset - offset;
      
      window.scrollTo({
        top: elementPosition,
        behavior: 'smooth'
      });
    }
  };

  // Scroll spy functionality
  useEffect(() => {
    const sections = [
      'our-mission',
      'our-principles',
      'our-standards',
      'accessibility-commitment',
      'contact-us'
    ];

    const observerOptions = {
      root: null,
      rootMargin: '-45px 0px -60% 0px', // Adjusted to account for our offset
      threshold: 0
    };

    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          setActiveSection(entry.target.id);
        }
      });
    }, observerOptions);

    // Observe all sections
    sections.forEach((sectionId) => {
      const element = document.getElementById(sectionId);
      if (element) {
        observer.observe(element);
      }
    });

    // Handle scroll to top - ensure first section is highlighted when at top
    const handleScroll = () => {
      const scrollPosition = window.pageYOffset || document.documentElement.scrollTop;
      
      // If we're at the top of the page (within 100px), highlight the first section
      if (scrollPosition < 100) {
        setActiveSection('our-mission');
      }
    };

    // Add scroll listener
    window.addEventListener('scroll', handleScroll);
    
    // Check initial scroll position
    handleScroll();

    return () => {
      sections.forEach((sectionId) => {
        const element = document.getElementById(sectionId);
        if (element) {
          observer.unobserve(element);
        }
      });
      window.removeEventListener('scroll', handleScroll);
    };
  }, []);

  // Helper function to determine if a section is active
  const isActiveSection = (sectionId: string) => {
    return activeSection === sectionId;
  };

  return (
    <div className="min-h-screen bg-white">
      {/* Blue page header section with reduced bottom padding */}
      <div className="sg-page-header" style={{ paddingBottom: '24px' }}>
        <div className="sg-page-header-container">
          {/* Breadcrumb */}
          <nav className="sg-page-header-breadcrumb">
            <div className="flex items-center gap-2 text-base">
              <a 
                href="#/" 
                className="text-white hover:text-[#d9eeff] hover:no-underline underline cursor-pointer transition-colors duration-200"
              >
                Home
              </a>
              <span className="text-white">&gt;</span>
              <span className="text-white">About</span>
            </div>
          </nav>

          {/* Page title */}
          <h1 className="sg-page-header-title">
            About the Workflow Manager platform
          </h1>

          {/* Page description - shortened and constrained to 75% width */}
          <div className="w-3/4">
            <p className="sg-page-header-description">
              Learn about the Workflow Manager platform - providing access to tools for creating, monitoring, and managing your workflows and runs.
            </p>
          </div>
        </div>
      </div>

      <div className="max-w-[1200px] mx-auto px-6 py-8">
        <div className="flex gap-8">
          {/* Sidebar - 25% width with sticky contents */}
          <div className="w-1/4 shrink-0">
            {/* Contents */}
            <div className="sg-contents-sticky">
              <h2 className="text-[24px] font-bold text-black leading-[32px] tracking-[0.15px] mb-4">
                Contents
              </h2>
              
              <nav>
                <ul className="sg-contents-nav">
                  <li className="sg-contents-item">
                    <button
                      onClick={() => handleJumpLinkClick('our-mission')}
                      className={`sg-contents-link w-full text-left ${isActiveSection('our-mission') ? 'sg-contents-link-active' : ''}`}
                    >
                      Our mission
                    </button>
                  </li>
                  <li className="sg-contents-item">
                    <button
                      onClick={() => handleJumpLinkClick('our-principles')}
                      className={`sg-contents-link w-full text-left ${isActiveSection('our-principles') ? 'sg-contents-link-active' : ''}`}
                    >
                      Our principles
                    </button>
                  </li>
                  <li className="sg-contents-item">
                    <button
                      onClick={() => handleJumpLinkClick('our-standards')}
                      className={`sg-contents-link w-full text-left ${isActiveSection('our-standards') ? 'sg-contents-link-active' : ''}`}
                    >
                      Our standards
                    </button>
                  </li>
                  <li className="sg-contents-item">
                    <button
                      onClick={() => handleJumpLinkClick('accessibility-commitment')}
                      className={`sg-contents-link w-full text-left ${isActiveSection('accessibility-commitment') ? 'sg-contents-link-active' : ''}`}
                    >
                      Accessibility commitment
                    </button>
                  </li>
                  <li className="sg-contents-item">
                    <button
                      onClick={() => handleJumpLinkClick('contact-us')}
                      className={`sg-contents-link w-full text-left ${isActiveSection('contact-us') ? 'sg-contents-link-active' : ''}`}
                    >
                      Contact us
                    </button>
                  </li>

                </ul>
              </nav>
            </div>
          </div>

          {/* Main content - 75% width */}
          <div className="w-3/4">
            {/* Our mission Section */}
            <section id="our-mission" className="mb-12 pt-6">
              <div className="sg-section-separator">
                <h2 className="text-[24px] font-bold text-black leading-[32px] tracking-[0.15px] mb-2">
                  Our mission
                </h2>
              </div>
              <div className="prose prose-lg max-w-none">
                {/* Content will be added later */}
              </div>
            </section>

            {/* Our principles Section */}
            <section id="our-principles" className="mb-12">
              <div className="sg-section-separator">
                <h2 className="text-[24px] font-bold text-black leading-[32px] tracking-[0.15px] mb-2">
                  Our principles
                </h2>
              </div>
              <div className="prose prose-lg max-w-none">
                {/* Content will be added later */}
              </div>
            </section>

            {/* Our standards Section */}
            <section id="our-standards" className="mb-12">
              <div className="sg-section-separator">
                <h2 className="text-[24px] font-bold text-black leading-[32px] tracking-[0.15px] mb-2">
                  Our standards
                </h2>
              </div>
              <div className="prose prose-lg max-w-none">
                {/* Content will be added later */}
              </div>
            </section>

            {/* Accessibility commitment Section */}
            <section id="accessibility-commitment" className="mb-12">
              <div className="sg-section-separator">
                <h2 className="text-[24px] font-bold text-black leading-[32px] tracking-[0.15px] mb-2">
                  Accessibility commitment
                </h2>
              </div>
              <div className="prose prose-lg max-w-none">
                {/* Content will be added later */}
              </div>
            </section>

            {/* Contact us Section */}
            <section id="contact-us" className="mb-12">
              <div className="sg-section-separator">
                <h2 className="text-[24px] font-bold text-black leading-[32px] tracking-[0.15px] mb-2">
                  Contact us
                </h2>
              </div>
              <div className="prose prose-lg max-w-none">
                <a
                  href="#/contact"
                  className="inline-block bg-[#0065bd] text-white px-6 py-3 rounded font-medium hover:bg-[#004a9f] focus:outline-none focus:ring-2 focus:ring-[#ffb900] focus:ring-offset-2 transition-colors duration-200 no-underline"
                >
                  Contact us
                </a>
                {/* Content will be added later */}
              </div>
            </section>


          </div>
        </div>
      </div>
    </div>
  );
}