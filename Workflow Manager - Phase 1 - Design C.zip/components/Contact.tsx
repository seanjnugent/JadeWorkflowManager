import { useState, useEffect } from "react";
import { ChevronDown } from "lucide-react";

export function Contact() {
  const [activeSection, setActiveSection] = useState<string>('get-in-touch'); // Start with 'get-in-touch' as default
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    subject: '',
    queryType: '',
    message: '',
    notRobot: false
  });

  const handleJumpLinkClick = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      // Calculate offset to align section header with Contents title
      // Sticky nav top (24px) + Contents title height + some spacing = ~45px offset
      const offset = 45;
      const elementPosition = element.getBoundingClientRect().top + window.pageYOffset - offset;
      
      window.scrollTo({
        top: elementPosition,
        behavior: 'smooth'
      });
    }
  };

  // Scroll spy functionality
  useEffect(() => {
    const sections = [
      'get-in-touch',
      'support-hours',
      'frequently-asked-questions',
      'feedback-suggestions',
      'technical-issues'
    ];

    const observerOptions = {
      root: null,
      rootMargin: '-45px 0px -60% 0px', // Adjusted to account for our offset
      threshold: 0
    };

    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          setActiveSection(entry.target.id);
        }
      });
    }, observerOptions);

    // Observe all sections
    sections.forEach((sectionId) => {
      const element = document.getElementById(sectionId);
      if (element) {
        observer.observe(element);
      }
    });

    // Handle scroll to top - ensure first section is highlighted when at top
    const handleScroll = () => {
      const scrollPosition = window.pageYOffset || document.documentElement.scrollTop;
      
      // If we're at the top of the page (within 100px), highlight the first section
      if (scrollPosition < 100) {
        setActiveSection('get-in-touch');
      }
    };

    // Add scroll listener
    window.addEventListener('scroll', handleScroll);
    
    // Check initial scroll position
    handleScroll();

    return () => {
      sections.forEach((sectionId) => {
        const element = document.getElementById(sectionId);
        if (element) {
          observer.unobserve(element);
        }
      });
      window.removeEventListener('scroll', handleScroll);
    };
  }, []);

  // Helper function to determine if a section is active
  const isActiveSection = (sectionId: string) => {
    return activeSection === sectionId;
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value, type } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? (e.target as HTMLInputElement).checked : value
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log('Form submitted:', formData);
    // Handle form submission logic here
  };

  return (
    <div className="min-h-screen bg-white">
      {/* Blue page header section with reduced bottom padding */}
      <div className="sg-page-header" style={{ paddingBottom: '24px' }}>
        <div className="sg-page-header-container">
          {/* Breadcrumb */}
          <nav className="sg-page-header-breadcrumb">
            <div className="flex items-center gap-2 text-base">
              <a 
                href="#/" 
                className="text-white hover:text-[#d9eeff] hover:no-underline underline cursor-pointer transition-colors duration-200"
              >
                Home
              </a>
              <span className="text-white">&gt;</span>
              <span className="text-white">Contact us</span>
            </div>
          </nav>

          {/* Page title */}
          <h1 className="sg-page-header-title">
            Contact us
          </h1>

          {/* Page description - shortened and constrained to 75% width */}
          <div className="w-3/4">
            <p className="sg-page-header-description">
              Get in touch with the Workflow Manager team for support, suggestions, or enquiries about the platform and its workflows. We welcome your feedback.
            </p>
          </div>
        </div>
      </div>

      <div className="max-w-[1200px] mx-auto px-6 py-8">
        <div className="flex gap-8">
          {/* Sidebar - 25% width with sticky contents */}
          <div className="w-1/4 shrink-0">
            {/* Contents */}
            <div className="sg-contents-sticky">
              <h2 className="text-[24px] font-bold text-black leading-[32px] tracking-[0.15px] mb-4">
                Contents
              </h2>
              
              <nav>
                <ul className="sg-contents-nav">
                  <li className="sg-contents-item">
                    <button
                      onClick={() => handleJumpLinkClick('get-in-touch')}
                      className={`sg-contents-link w-full text-left ${isActiveSection('get-in-touch') ? 'sg-contents-link-active' : ''}`}
                    >
                      Get in touch
                    </button>
                  </li>
                  <li className="sg-contents-item">
                    <button
                      onClick={() => handleJumpLinkClick('support-hours')}
                      className={`sg-contents-link w-full text-left ${isActiveSection('support-hours') ? 'sg-contents-link-active' : ''}`}
                    >
                      Support hours
                    </button>
                  </li>
                  <li className="sg-contents-item">
                    <button
                      onClick={() => handleJumpLinkClick('frequently-asked-questions')}
                      className={`sg-contents-link w-full text-left ${isActiveSection('frequently-asked-questions') ? 'sg-contents-link-active' : ''}`}
                    >
                      Frequently asked questions
                    </button>
                  </li>
                  <li className="sg-contents-item">
                    <button
                      onClick={() => handleJumpLinkClick('feedback-suggestions')}
                      className={`sg-contents-link w-full text-left ${isActiveSection('feedback-suggestions') ? 'sg-contents-link-active' : ''}`}
                    >
                      Feedback &amp; suggestions
                    </button>
                  </li>
                  <li className="sg-contents-item">
                    <button
                      onClick={() => handleJumpLinkClick('technical-issues')}
                      className={`sg-contents-link w-full text-left ${isActiveSection('technical-issues') ? 'sg-contents-link-active' : ''}`}
                    >
                      Technical issues
                    </button>
                  </li>

                </ul>
              </nav>
            </div>
          </div>

          {/* Main content - 75% width */}
          <div className="w-3/4">
            {/* Get in touch Section */}
            <section id="get-in-touch" className="mb-12 pt-6">
              <div className="sg-section-separator">
                <h2 className="text-[24px] font-bold text-black leading-[32px] tracking-[0.15px] mb-2">
                  Get in touch
                </h2>
              </div>
              <div className="prose prose-lg max-w-none">
                {/* Contact Form */}
                <div className="bg-white">
                  <form onSubmit={handleSubmit} className="space-y-6">
                    {/* Your Name */}
                    <div>
                      <label htmlFor="name" className="block text-[16px] font-medium text-black mb-2">
                        Your Name
                      </label>
                      <input
                        type="text"
                        id="name"
                        name="name"
                        value={formData.name}
                        onChange={handleInputChange}
                        placeholder="John Smith"
                        className="w-full h-[44px] px-3 py-2 border-2 border-[#5e5e5e] bg-white text-[#333333] placeholder-[#5e5e5e] focus:border-[#ffb900] focus:outline-none transition-colors duration-200"
                        required
                      />
                    </div>

                    {/* Your Email */}
                    <div>
                      <label htmlFor="email" className="block text-[16px] font-medium text-black mb-2">
                        Your Email
                      </label>
                      <input
                        type="email"
                        id="email"
                        name="email"
                        value={formData.email}
                        onChange={handleInputChange}
                        placeholder="john@example.com"
                        className="w-full h-[44px] px-3 py-2 border-2 border-[#5e5e5e] bg-white text-[#333333] placeholder-[#5e5e5e] focus:border-[#ffb900] focus:outline-none transition-colors duration-200"
                        required
                      />
                    </div>

                    {/* Subject */}
                    <div>
                      <label htmlFor="subject" className="block text-[16px] font-medium text-black mb-2">
                        Subject
                      </label>
                      <input
                        type="text"
                        id="subject"
                        name="subject"
                        value={formData.subject}
                        onChange={handleInputChange}
                        placeholder="How can we help?"
                        className="w-full h-[44px] px-3 py-2 border-2 border-[#5e5e5e] bg-white text-[#333333] placeholder-[#5e5e5e] focus:border-[#ffb900] focus:outline-none transition-colors duration-200"
                        required
                      />
                    </div>

                    {/* Type of Query */}
                    <div>
                      <label htmlFor="queryType" className="block text-[16px] font-medium text-black mb-2">
                        Type of Query
                      </label>
                      <div className="relative">
                        <select
                          id="queryType"
                          name="queryType"
                          value={formData.queryType}
                          onChange={handleInputChange}
                          className="w-full h-[44px] px-3 py-2 border-2 border-[#5e5e5e] bg-white text-[#333333] focus:border-[#ffb900] focus:outline-none transition-colors duration-200 appearance-none"
                          required
                        >
                          <option value="">Please select...</option>
                          <option value="general">General enquiry</option>
                          <option value="technical">Technical support</option>
                          <option value="data">Data request</option>
                          <option value="feedback">Feedback</option>
                          <option value="other">Other</option>
                        </select>
                        <div className="absolute right-0 top-0 h-[44px] w-[44px] bg-[#0065bd] flex items-center justify-center pointer-events-none">
                          <ChevronDown className="w-5 h-5 text-white" />
                        </div>
                      </div>
                    </div>

                    {/* Your Message */}
                    <div>
                      <label htmlFor="message" className="block text-[16px] font-medium text-black mb-2">
                        Your Message
                      </label>
                      <textarea
                        id="message"
                        name="message"
                        value={formData.message}
                        onChange={handleInputChange}
                        placeholder="Tell us how we can help you today..."
                        rows={6}
                        className="w-full px-3 py-2 border-2 border-[#5e5e5e] bg-white text-[#333333] placeholder-[#5e5e5e] focus:border-[#ffb900] focus:outline-none transition-colors duration-200 resize-vertical"
                        required
                      />
                    </div>

                    {/* Checkbox */}
                    <div className="flex items-center gap-2">
                      <input
                        type="checkbox"
                        id="notRobot"
                        name="notRobot"
                        checked={formData.notRobot}
                        onChange={handleInputChange}
                        className="w-4 h-4 border-2 border-[#5e5e5e] rounded-sm focus:ring-[#ffb900] focus:ring-2"
                        required
                      />
                      <label htmlFor="notRobot" className="text-[16px] font-medium text-black">
                        I'm not a robot
                      </label>
                    </div>

                    {/* Submit Button */}
                    <button
                      type="submit"
                      className="w-full h-[44px] bg-[#0065bd] text-white font-medium text-[16px] hover:bg-[#004a9f] focus:outline-none focus:ring-2 focus:ring-[#ffb900] focus:ring-offset-2 transition-colors duration-200"
                    >
                      Send Message
                    </button>
                  </form>
                </div>
              </div>
            </section>

            {/* Support hours Section */}
            <section id="support-hours" className="mb-12">
              <div className="sg-section-separator">
                <h2 className="text-[24px] font-bold text-black leading-[32px] tracking-[0.15px] mb-2">
                  Support hours
                </h2>
              </div>
              <div className="prose prose-lg max-w-none">
                {/* Content will be added later */}
              </div>
            </section>

            {/* Frequently asked questions Section */}
            <section id="frequently-asked-questions" className="mb-12">
              <div className="sg-section-separator">
                <h2 className="text-[24px] font-bold text-black leading-[32px] tracking-[0.15px] mb-2">
                  Frequently asked questions
                </h2>
              </div>
              <div className="prose prose-lg max-w-none">
                {/* Content will be added later */}
              </div>
            </section>

            {/* Feedback & suggestions Section */}
            <section id="feedback-suggestions" className="mb-12">
              <div className="sg-section-separator">
                <h2 className="text-[24px] font-bold text-black leading-[32px] tracking-[0.15px] mb-2">
                  Feedback &amp; suggestions
                </h2>
              </div>
              <div className="prose prose-lg max-w-none">
                {/* Content will be added later */}
              </div>
            </section>

            {/* Technical issues Section */}
            <section id="technical-issues" className="mb-12">
              <div className="sg-section-separator">
                <h2 className="text-[24px] font-bold text-black leading-[32px] tracking-[0.15px] mb-2">
                  Technical issues
                </h2>
              </div>
              <div className="prose prose-lg max-w-none">
                {/* Content will be added later */}
              </div>
            </section>


          </div>
        </div>
      </div>
    </div>
  );
}