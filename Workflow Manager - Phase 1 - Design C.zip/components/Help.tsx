import { useState, useEffect } from "react";

export function Help() {
  const [activeSection, setActiveSection] = useState<string>('getting-started'); // Start with 'getting-started' as default

  const handleJumpLinkClick = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      // Calculate offset to align section header with Contents title
      // Sticky nav top (24px) + Contents title height + some spacing = ~45px offset
      const offset = 45;
      const elementPosition = element.getBoundingClientRect().top + window.pageYOffset - offset;
      
      window.scrollTo({
        top: elementPosition,
        behavior: 'smooth'
      });
    }
  };

  // Scroll spy functionality
  useEffect(() => {
    const sections = [
      'getting-started',
      'glossary',
      'searching-workflows',
      'using-workflows',
      'technical-support'
    ];

    const observerOptions = {
      root: null,
      rootMargin: '-45px 0px -60% 0px', // Adjusted to account for our offset
      threshold: 0
    };

    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          setActiveSection(entry.target.id);
        }
      });
    }, observerOptions);

    // Observe all sections
    sections.forEach((sectionId) => {
      const element = document.getElementById(sectionId);
      if (element) {
        observer.observe(element);
      }
    });

    // Handle scroll to top - ensure first section is highlighted when at top
    const handleScroll = () => {
      const scrollPosition = window.pageYOffset || document.documentElement.scrollTop;
      
      // If we're at the top of the page (within 100px), highlight the first section
      if (scrollPosition < 100) {
        setActiveSection('getting-started');
      }
    };

    // Add scroll listener
    window.addEventListener('scroll', handleScroll);
    
    // Check initial scroll position
    handleScroll();

    return () => {
      sections.forEach((sectionId) => {
        const element = document.getElementById(sectionId);
        if (element) {
          observer.unobserve(element);
        }
      });
      window.removeEventListener('scroll', handleScroll);
    };
  }, []);

  // Helper function to determine if a section is active
  const isActiveSection = (sectionId: string) => {
    return activeSection === sectionId;
  };

  return (
    <div className="min-h-screen bg-white">
      {/* Blue page header section with reduced bottom padding */}
      <div className="sg-page-header" style={{ paddingBottom: '24px' }}>
        <div className="sg-page-header-container">
          {/* Breadcrumb */}
          <nav className="sg-page-header-breadcrumb">
            <div className="flex items-center gap-2 text-base">
              <a 
                href="#/" 
                className="text-white hover:text-[#d9eeff] hover:no-underline underline cursor-pointer transition-colors duration-200"
              >
                Home
              </a>
              <span className="text-white">&gt;</span>
              <span className="text-white">Help</span>
            </div>
          </nav>

          {/* Page title */}
          <h1 className="sg-page-header-title">
            Help &amp; support
          </h1>

          {/* Page description - shortened and constrained to 75% width */}
          <div className="w-3/4">
            <p className="sg-page-header-description">
              Find answers to common questions, learn how to navigate and use our site, and explore key terms and concepts in our comprehensive help and learning centre.
            </p>
          </div>
        </div>
      </div>

      <div className="max-w-[1200px] mx-auto px-6 py-8">
        <div className="flex gap-8">
          {/* Sidebar - 25% width with sticky contents */}
          <div className="w-1/4 shrink-0">
            {/* Contents */}
            <div className="sg-contents-sticky">
              <h2 className="text-[24px] font-bold text-black leading-[32px] tracking-[0.15px] mb-4">
                Contents
              </h2>
              
              <nav>
                <ul className="sg-contents-nav">
                  <li className="sg-contents-item">
                    <button
                      onClick={() => handleJumpLinkClick('getting-started')}
                      className={`sg-contents-link w-full text-left ${isActiveSection('getting-started') ? 'sg-contents-link-active' : ''}`}
                    >
                      Getting started
                    </button>
                  </li>
                  <li className="sg-contents-item">
                    <button
                      onClick={() => handleJumpLinkClick('glossary')}
                      className={`sg-contents-link w-full text-left ${isActiveSection('glossary') ? 'sg-contents-link-active' : ''}`}
                    >
                      Glossary
                    </button>
                  </li>
                  <li className="sg-contents-item">
                    <button
                      onClick={() => handleJumpLinkClick('searching-workflows')}
                      className={`sg-contents-link w-full text-left ${isActiveSection('searching-workflows') ? 'sg-contents-link-active' : ''}`}
                    >
                      Searching workflows
                    </button>
                  </li>
                  <li className="sg-contents-item">
                    <button
                      onClick={() => handleJumpLinkClick('using-workflows')}
                      className={`sg-contents-link w-full text-left ${isActiveSection('using-workflows') ? 'sg-contents-link-active' : ''}`}
                    >
                      Using workflows
                    </button>
                  </li>
                  <li className="sg-contents-item">
                    <button
                      onClick={() => handleJumpLinkClick('technical-support')}
                      className={`sg-contents-link w-full text-left ${isActiveSection('technical-support') ? 'sg-contents-link-active' : ''}`}
                    >
                      Technical support
                    </button>
                  </li>
                </ul>
              </nav>
            </div>
          </div>

          {/* Main content - 75% width */}
          <div className="w-3/4">
            {/* Getting started Section */}
            <section id="getting-started" className="mb-12 pt-6">
              <div className="sg-section-separator">
                <h2 className="text-[24px] font-bold text-black leading-[32px] tracking-[0.15px] mb-2">
                  Getting started
                </h2>
              </div>
              <div className="prose prose-lg max-w-none">
                {/* Content will be added later */}
              </div>
            </section>

            {/* Glossary Section - moved to second position */}
            <section id="glossary" className="mb-12">
              <div className="sg-section-separator">
                <h2 className="text-[24px] font-bold text-black leading-[32px] tracking-[0.15px] mb-2">
                  Glossary
                </h2>
              </div>
              <div className="prose prose-lg max-w-none">
                {/* Content will be added later */}
              </div>
            </section>

            {/* Searching workflows Section */}
            <section id="searching-workflows" className="mb-12">
              <div className="sg-section-separator">
                <h2 className="text-[24px] font-bold text-black leading-[32px] tracking-[0.15px] mb-2">
                  Searching workflows
                </h2>
              </div>
              <div className="prose prose-lg max-w-none">
                {/* Content will be added later */}
              </div>
            </section>

            {/* Using workflows Section */}
            <section id="using-workflows" className="mb-12">
              <div className="sg-section-separator">
                <h2 className="text-[24px] font-bold text-black leading-[32px] tracking-[0.15px] mb-2">
                  Using workflows
                </h2>
              </div>
              <div className="prose prose-lg max-w-none">
                {/* Content will be added later */}
              </div>
            </section>

            {/* Technical support Section */}
            <section id="technical-support" className="mb-12">
              <div className="sg-section-separator">
                <h2 className="text-[24px] font-bold text-black leading-[32px] tracking-[0.15px] mb-2">
                  Technical support
                </h2>
              </div>
              <div className="prose prose-lg max-w-none">
                <a
                  href="#/contact"
                  className="inline-block bg-[#0065bd] text-white px-6 py-3 rounded font-medium hover:bg-[#004a9f] focus:outline-none focus:ring-2 focus:ring-[#ffb900] focus:ring-offset-2 transition-colors duration-200 no-underline"
                >
                  Contact us
                </a>
                {/* Content will be added later */}
              </div>
            </section>
          </div>
        </div>
      </div>
    </div>
  );
}