import { useState } from "react";
import { X, ChevronDown } from "lucide-react";
import svgPaths from "../imports/svg-lxv4opcm4j";

export function Organisations() {
  const [searchValue, setSearchValue] = useState("");
  const [sortBy, setSortBy] = useState("Most recent");

  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchValue(e.target.value);
  };

  const clearSearch = () => {
    setSearchValue("");
  };

  const runs = [
    {
      title: "Run ID #10",
      description: "Run name to be entered by user when workflow first triggered.",
      status: "Complete",
      date: "15-06-2025",
      runBy: "Alex Campbell",
      workflowId: "WF101",
      href: "#/run-id"
    },
    {
      title: "Run ID #9",
      description: "Run name to be entered by user when workflow first triggered.",
      status: "Failed",
      date: "14-06-2025",
      runBy: "Fiona Smith",
      workflowId: "WF102",
      href: "#/run-id"
    },
    {
      title: "Run ID #8",
      description: "Run name to be entered by user when workflow first triggered.",
      status: "Complete",
      date: "13-06-2025",
      runBy: "Alex Campbell",
      workflowId: "WF101",
      href: "#/run-id"
    },
    {
      title: "Run ID #7",
      description: "Run name to be entered by user when workflow first triggered.",
      status: "Running",
      date: "12-06-2025",
      runBy: "Fiona Smith",
      workflowId: "WF101",
      href: "#/run-id"
    },
    {
      title: "Run ID #6",
      description: "Run name to be entered by user when workflow first triggered.",
      status: "Complete",
      date: "11-06-2025",
      runBy: "Alex Campbell",
      workflowId: "WF102",
      href: "#/run-id"
    },
    {
      title: "Run ID #5",
      description: "Run name to be entered by user when workflow first triggered.",
      status: "Failed",
      date: "10-06-2025",
      runBy: "Fiona Smith",
      workflowId: "WF102",
      href: "#/run-id"
    },
    {
      title: "Run ID #4",
      description: "Run name to be entered by user when workflow first triggered.",
      status: "Complete",
      date: "09-06-2025",
      runBy: "Alex Campbell",
      workflowId: "WF102",
      href: "#/run-id"
    },
    {
      title: "Run ID #3",
      description: "Run name to be entered by user when workflow first triggered.",
      status: "Running",
      date: "08-06-2025",
      runBy: "Fiona Smith",
      workflowId: "WF101",
      href: "#/run-id"
    },
    {
      title: "Run ID #2",
      description: "Run name to be entered by user when workflow first triggered.",
      status: "Complete",
      date: "07-06-2025",
      runBy: "Alex Campbell",
      workflowId: "WF101",
      href: "#/run-id"
    },
    {
      title: "Run ID #1",
      description: "Run name to be entered by user when workflow first triggered.",
      status: "Failed",
      date: "06-06-2025",
      runBy: "Fiona Smith",
      workflowId: "WF102",
      href: "#/run-id"
    }
  ];

  return (
    <div className="min-h-screen bg-white">
      <div className="max-w-[1200px] mx-auto px-6 py-8">
        {/* Breadcrumb */}
        <nav className="mb-6">
          <div className="flex items-center gap-2 text-base">
            <a 
              href="#/" 
              className="text-[#0065bd] hover:text-[#004a9f] hover:no-underline underline cursor-pointer transition-colors duration-200"
            >
              Home
            </a>
            <span className="text-[#5e5e5e]">&gt;</span>
            <span className="text-[#333333]">Run history</span>
          </div>
        </nav>

        <div className="flex gap-8">
          {/* Sidebar - 25% width */}
          <div className="w-1/4 shrink-0">
            {/* Page title */}
            <div className="mb-6">
              <h1 className="text-[44px] font-bold text-black leading-[50px] tracking-[0.15px] whitespace-nowrap">
                10 runs found
              </h1>
            </div>

            {/* Search */}
            <div className="mb-6">
              <h2 className="text-[24px] font-bold text-black leading-[32px] tracking-[0.15px] mb-2">
                Search
              </h2>
              <div className="sg-data-search-container">
                <input
                  type="text"
                  placeholder="Search runs..."
                  value={searchValue}
                  onChange={handleSearchChange}
                  className="sg-data-search-input"
                />
                {searchValue && (
                  <button
                    onClick={clearSearch}
                    className="absolute right-12 top-1/2 transform -translate-y-1/2 text-gray-500 hover:text-gray-700 p-1"
                    aria-label="Clear search"
                  >
                    <X className="w-4 h-4" />
                  </button>
                )}
                <button 
                  className="sg-data-search-button"
                  type="submit"
                  aria-label="Search runs"
                >
                  <svg
                    className="w-6 h-6 text-white"
                    fill="none"
                    viewBox="0 0 48 48"
                  >
                    <path
                      d={svgPaths.p26efbc80}
                      fill="currentColor"
                    />
                  </svg>
                </button>
              </div>
            </div>

            {/* Filter by */}
            <div>
              <h2 className="text-[24px] font-bold text-black leading-[32px] tracking-[0.15px] mb-4">
                Filter by
              </h2>
              
              {/* Status filter */}
              <div className="sg-filter-item">
                <div className="sg-filter-content">
                  <span className="sg-filter-label">Status</span>
                  <ChevronDown className="sg-filter-chevron" />
                </div>
              </div>

              {/* Workflow ID filter */}
              <div className="sg-filter-item">
                <div className="sg-filter-content">
                  <span className="sg-filter-label">Workflow ID</span>
                  <ChevronDown className="sg-filter-chevron" />
                </div>
              </div>

              {/* Run by filter */}
              <div className="sg-filter-item">
                <div className="sg-filter-content">
                  <span className="sg-filter-label">Run by</span>
                  <ChevronDown className="sg-filter-chevron" />
                </div>
              </div>

              {/* Date filter */}
              <div className="sg-filter-item sg-filter-item-last">
                <div className="sg-filter-content">
                  <span className="sg-filter-label">Date</span>
                  <ChevronDown className="sg-filter-chevron" />
                </div>
              </div>

              {/* Clear filters button */}
              <button className="w-full h-12 bg-[#0065bd] text-white font-bold text-base mt-8">
                Clear filters
              </button>
            </div>
          </div>

          {/* Main content - 75% width */}
          <div className="w-3/4">
            {/* Sort by dropdown - positioned at top of content */}
            <div className="flex justify-end mb-6" style={{ marginTop: '46px' }}>
              <div className="flex items-center gap-2">
                <label className="text-base text-[#1a1a1a] tracking-[0.15px]">
                  Sort by:
                </label>
                <div className="relative">
                  <select 
                    value={sortBy} 
                    onChange={(e) => setSortBy(e.target.value)}
                    className="h-10 w-40 px-3 pr-10 bg-white border-2 border-black text-base appearance-none cursor-pointer"
                  >
                    <option>Most recent</option>
                    <option>Oldest first</option>
                    <option>Run ID ascending</option>
                    <option>Run ID descending</option>
                    <option>Status</option>
                  </select>
                  <div className="absolute right-0 top-0 w-10 h-10 bg-[#0065bd] flex items-center justify-center pointer-events-none">
                    <div className="w-4 h-4 transform rotate-[315deg]">
                      <div className="border-white border-[0px_0px_3px_3px] w-3 h-3"></div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Run tiles */}
            <div className="space-y-6">
              {runs.map((run, index) => (
                <a 
                  key={index} 
                  href={run.href}
                  className="sg-dataset-tile block"
                >
                  <h3 className="sg-dataset-title">
                    {run.title}
                  </h3>
                  
                  <div className="flex items-center gap-4 text-[14px] text-[#5e5e5e] leading-[24px] tracking-[0.15px] mb-3">
                    <span>Status: {run.status}</span>
                    <span>Date: {run.date}</span>
                    <span>Run by: {run.runBy}</span>
                    <span>Workflow ID: {run.workflowId}</span>
                  </div>

                  <p className="sg-dataset-description">
                    {run.description}
                  </p>
                </a>
              ))}
            </div>

            {/* Pagination */}
            <div className="flex justify-center pt-6">
              <div className="w-10 h-10 bg-[#f8f8f8] border-b-2 border-black flex items-center justify-center">
                <span className="text-base text-black cursor-pointer">1</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}