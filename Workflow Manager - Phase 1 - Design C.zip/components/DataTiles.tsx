import { useState } from "react";
import { X, Search, Building, Folder, HelpCircle, Play } from "lucide-react";
import svgPaths from "../imports/svg-tmym2azjca";

export function DataTiles() {
  const [searchValue, setSearchValue] = useState("");
  
  const commonSearches = [
    "Population", "Housing", "Education", "Transport", "Health"
  ];

  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchValue(e.target.value);
  };

  const clearSearch = () => {
    setSearchValue("");
  };

  const handleTagClick = (tag: string) => {
    setSearchValue(tag);
    // Navigate to data page with search term
    window.location.hash = '#/data';
  };

  return (
    <section className="bg-white">
      <div className="sg-tiles-container-2x2">
        {/* Run a workflow tile - Top left */}
        <a href="#/data" className="sg-tile">
          <h2 className="flex items-center gap-2">
            <Play className="w-6 h-6" />
            Run a workflow
          </h2>
          <p>Start a workflow to load, validate, review and publish your datasets. Follow each step to ensure your data meets quality standards.</p>
        </a>

        {/* Browse history tile - Top right */}
        <a href="#/organisations" className="sg-tile">
          <h2 className="flex items-center gap-2">
            <Building className="w-6 h-6" />
            Browse history
          </h2>
          <p>View a complete history of your previously run workflows. Review status, notes, outcomes, outputs and log history.</p>
        </a>

        {/* Get in touch tile - Bottom left */}
        <a href="#/contact" className="sg-tile">
          <h2 className="flex items-center gap-2">
            <Folder className="w-6 h-6" />
            Get in touch
          </h2>
          <p>Need help or want to share feedback? Reach out to our support team—we're here to assist with technical questions, suggestions, or anything in between.</p>
        </a>

        {/* How to use this site tile - Bottom right */}
        <a href="#/help" className="sg-tile">
          <h2 className="flex items-center gap-2">
            <HelpCircle className="w-6 h-6" />
            How to use this site
          </h2>
          <p>New here? Explore our user-guides and helpful tips to get familiar with the platform to run workflows with confidence.</p>
        </a>
      </div>
    </section>
  );
}