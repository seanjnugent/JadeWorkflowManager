import { useState, useEffect } from "react";
import { ArrowRight } from "lucide-react";

export function Journey() {
  const [activeSection, setActiveSection] = useState<string>('name-run'); // Start with first section as default
  const [runName, setRunName] = useState<string>('');
  const maxCharacters = 70;

  const handleJumpLinkClick = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      // Calculate offset to align section header with Contents title
      // Sticky nav top (24px) + Contents title height + some spacing = ~45px offset
      const offset = 45;
      const elementPosition = element.getBoundingClientRect().top + window.pageYOffset - offset;
      
      window.scrollTo({
        top: elementPosition,
        behavior: 'smooth'
      });
    }
  };

  // Scroll spy functionality
  useEffect(() => {
    const sections = [
      'name-run',
      'what-to-expect'
    ];

    const observerOptions = {
      root: null,
      rootMargin: '-45px 0px -60% 0px', // Adjusted to account for our offset
      threshold: 0
    };

    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          setActiveSection(entry.target.id);
        }
      });
    }, observerOptions);

    // Observe all sections
    sections.forEach((sectionId) => {
      const element = document.getElementById(sectionId);
      if (element) {
        observer.observe(element);
      }
    });

    // Handle scroll to top - ensure first section is highlighted when at top
    const handleScroll = () => {
      const scrollPosition = window.pageYOffset || document.documentElement.scrollTop;
      
      // If we're at the top of the page (within 100px), highlight the first section
      if (scrollPosition < 100) {
        setActiveSection('name-run');
      }
    };

    // Add scroll listener
    window.addEventListener('scroll', handleScroll);
    
    // Check initial scroll position
    handleScroll();

    return () => {
      sections.forEach((sectionId) => {
        const element = document.getElementById(sectionId);
        if (element) {
          observer.unobserve(element);
        }
      });
      window.removeEventListener('scroll', handleScroll);
    };
  }, []);

  // Helper function to determine if a section is active
  const isActiveSection = (sectionId: string) => {
    return activeSection === sectionId;
  };

  return (
    <div className="min-h-screen bg-white">
      {/* Blue page header section with reduced bottom padding */}
      <div className="sg-page-header" style={{ paddingBottom: '24px' }}>
        <div className="sg-page-header-container">
          {/* Breadcrumb */}
          <nav className="sg-page-header-breadcrumb">
            <div className="flex items-center gap-2 text-base">
              <a 
                href="#/" 
                className="text-white hover:text-[#d9eeff] hover:no-underline underline cursor-pointer transition-colors duration-200"
              >
                Home
              </a>
              <span className="text-white">&gt;</span>
              <a 
                href="#/data" 
                className="text-white hover:text-[#d9eeff] hover:no-underline underline cursor-pointer transition-colors duration-200"
              >
                Workflows
              </a>
              <span className="text-white">&gt;</span>
              <a 
                href="#/health-survey" 
                className="text-white hover:text-[#d9eeff] hover:no-underline underline cursor-pointer transition-colors duration-200"
              >
                Update existing resource & metadata
              </a>
              <span className="text-white">&gt;</span>
              <span className="text-white">Step 1: Name Run</span>
            </div>
          </nav>

          {/* Page title */}
          <h1 className="sg-page-header-title">
            Step 1: Name Run
          </h1>

          {/* Progress indicator - spans full width */}
          <div className="w-full">
            <div className="sg-page-header-description" style={{ marginBottom: '10px' }}>
              <div className="relative">
                {/* Individual connectors between circles */}
                {/* Connector 1-2: Current to Future = Grey */}
                <div className="absolute top-4 h-1 rounded-full z-0" style={{ left: '32px', width: 'calc((100% - 64px) / 6)', background: 'rgba(227, 227, 227, 0.6)' }}></div>
                {/* Connector 2-3: Future to Future = Grey */}
                <div className="absolute top-4 h-1 rounded-full z-0" style={{ left: 'calc(32px + (100% - 64px) / 6)', width: 'calc((100% - 64px) / 6)', background: 'rgba(227, 227, 227, 0.6)' }}></div>
                {/* Connector 3-4: Future to Future = Grey */}
                <div className="absolute top-4 h-1 rounded-full z-0" style={{ left: 'calc(32px + 2 * (100% - 64px) / 6)', width: 'calc((100% - 64px) / 6)', background: 'rgba(227, 227, 227, 0.6)' }}></div>
                {/* Connector 4-5: Future to Future = Grey */}
                <div className="absolute top-4 h-1 rounded-full z-0" style={{ left: 'calc(32px + 3 * (100% - 64px) / 6)', width: 'calc((100% - 64px) / 6)', background: 'rgba(227, 227, 227, 0.6)' }}></div>
                {/* Connector 5-6: Future to Future = Grey */}
                <div className="absolute top-4 h-1 rounded-full z-0" style={{ left: 'calc(32px + 4 * (100% - 64px) / 6)', width: 'calc((100% - 64px) / 6)', background: 'rgba(227, 227, 227, 0.6)' }}></div>
                {/* Connector 6-7: Future to Future = Grey */}
                <div className="absolute top-4 h-1 rounded-full z-0" style={{ left: 'calc(32px + 5 * (100% - 64px) / 6)', width: 'calc((100% - 64px) / 6)', background: 'rgba(227, 227, 227, 0.6)' }}></div>
                
                {/* Steps container */}
                <div className="relative flex justify-between items-center w-full z-10">
                  {/* Step 1: Name (Current) - White */}
                  <div className="flex flex-col items-center relative z-20">
                    <div className="w-8 h-8 rounded-full bg-white text-[var(--sg-blue-dark)] flex items-center justify-center font-bold text-sm mb-3 shadow-lg border-2 border-white">
                      <div className="w-3 h-3 rounded-full bg-[var(--sg-blue-dark)]"></div>
                    </div>
                    <span className="text-white font-medium text-center text-sm">1. Name</span>
                  </div>
                  
                  {/* Step 2: Upload (Future) - Grey */}
                  <div className="flex flex-col items-center relative z-20">
                    <div className="w-8 h-8 rounded-full flex items-center justify-center font-bold text-sm mb-3" style={{ background: 'rgba(227, 227, 227, 0.6)', border: '2px solid rgba(227, 227, 227, 0.6)' }}>
                    </div>
                    <span className="text-center text-sm" style={{ color: 'rgba(227, 227, 227, 0.6)' }}>2. Upload</span>
                  </div>
                  
                  {/* Step 3: Preview (Future) - Grey */}
                  <div className="flex flex-col items-center relative z-20">
                    <div className="w-8 h-8 rounded-full flex items-center justify-center font-bold text-sm mb-3" style={{ background: 'rgba(227, 227, 227, 0.6)', border: '2px solid rgba(227, 227, 227, 0.6)' }}>
                    </div>
                    <span className="text-center text-sm" style={{ color: 'rgba(227, 227, 227, 0.6)' }}>3. Preview</span>
                  </div>
                  
                  {/* Step 4: Metadata (Future) - Grey */}
                  <div className="flex flex-col items-center relative z-20">
                    <div className="w-8 h-8 rounded-full flex items-center justify-center font-bold text-sm mb-3" style={{ background: 'rgba(227, 227, 227, 0.6)', border: '2px solid rgba(227, 227, 227, 0.6)' }}>
                    </div>
                    <span className="text-center text-sm" style={{ color: 'rgba(227, 227, 227, 0.6)' }}>4. Metadata</span>
                  </div>
                  
                  {/* Step 5: Summary (Future) - Grey */}
                  <div className="flex flex-col items-center relative z-20">
                    <div className="w-8 h-8 rounded-full flex items-center justify-center font-bold text-sm mb-3" style={{ background: 'rgba(227, 227, 227, 0.6)', border: '2px solid rgba(227, 227, 227, 0.6)' }}>
                    </div>
                    <span className="text-center text-sm" style={{ color: 'rgba(227, 227, 227, 0.6)' }}>5. Summary</span>
                  </div>
                  
                  {/* Step 6: Check (Future) - Grey */}
                  <div className="flex flex-col items-center relative z-20">
                    <div className="w-8 h-8 rounded-full flex items-center justify-center font-bold text-sm mb-3" style={{ background: 'rgba(227, 227, 227, 0.6)', border: '2px solid rgba(227, 227, 227, 0.6)' }}>
                    </div>
                    <span className="text-center text-sm" style={{ color: 'rgba(227, 227, 227, 0.6)' }}>6. Check</span>
                  </div>
                  
                  {/* Step 7: Finalise (Future) - Grey */}
                  <div className="flex flex-col items-center relative z-20">
                    <div className="w-8 h-8 rounded-full flex items-center justify-center font-bold text-sm mb-3" style={{ background: 'rgba(227, 227, 227, 0.6)', border: '2px solid rgba(227, 227, 227, 0.6)' }}>
                    </div>
                    <span className="text-center text-sm" style={{ color: 'rgba(227, 227, 227, 0.6)' }}>7. Finalise</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Hero tiles removed */}
        </div>
      </div>

      <div className="max-w-[1200px] mx-auto px-6 py-8">
        <div className="flex gap-8">
          {/* Sidebar - 25% width with sticky contents */}
          <div className="w-1/4 shrink-0">
            {/* Contents */}
            <div className="sg-contents-sticky">
              <h2 className="text-[24px] font-bold text-black leading-[32px] tracking-[0.15px] mb-4">
                Step summary
              </h2>
              
              <nav>
                <ul className="sg-contents-nav">
                  <li className="sg-contents-item">
                    <button
                      onClick={() => handleJumpLinkClick('name-run')}
                      className={`sg-contents-link w-full text-left ${isActiveSection('name-run') ? 'sg-contents-link-active' : ''}`}
                    >
                      Name your run
                    </button>
                  </li>
                  <li className="sg-contents-item">
                    <button
                      onClick={() => handleJumpLinkClick('what-to-expect')}
                      className={`sg-contents-link w-full text-left ${isActiveSection('what-to-expect') ? 'sg-contents-link-active' : ''}`}
                    >
                      What to expect
                    </button>
                  </li>
                </ul>
              </nav>
            </div>
          </div>

          {/* Main content - 75% width */}
          <div className="w-3/4">
            {/* Name your run Section */}
            <section id="name-run" className="mb-12 pt-6">
              <div className="sg-section-separator">
                <h2 className="text-[24px] font-bold text-black leading-[32px] tracking-[0.15px] mb-2">
                  Name your run
                </h2>
              </div>
              <div className="prose prose-lg max-w-none">
                <p className="text-[19px] leading-[32px] tracking-[0.15px] text-[#333333] mb-6">
                  Provide a descriptive name for this workflow run to help you identify it later:
                </p>
                
                {/* Text input field with character counter */}
                <div className="mb-8">
                  <div className="relative">
                    <input
                      type="text"
                      value={runName}
                      onChange={(e) => setRunName(e.target.value)}
                      placeholder="Name your run here..."
                      maxLength={maxCharacters}
                      className="w-full px-4 py-3 border-2 border-[#5e5e5e] rounded-[4px] text-[16px] leading-[24px] text-[#333333] placeholder-[#5e5e5e] focus:border-[#ffb900] focus:outline-none transition-colors duration-200"
                    />
                  </div>
                  <div className="mt-2 text-right">
                    <span className="text-[14px] text-[#5e5e5e]">
                      {runName.length}/{maxCharacters} characters
                    </span>
                  </div>
                </div>
              </div>
            </section>

            {/* What to expect Section */}
            <section id="what-to-expect" className="mb-12 pt-6">
              <div className="sg-section-separator">
                <h2 className="text-[24px] font-bold text-black leading-[32px] tracking-[0.15px] mb-2">
                  What to expect
                </h2>
              </div>
              <div className="prose prose-lg max-w-none">
                {/* Empty for now as requested */}
              </div>
            </section>

            {/* Continue button - right aligned */}
            <div className="flex justify-end pt-6">
              <button
                type="button"
                className="sg-data-action-button px-8 py-3 gap-2"
                onClick={() => {
                  window.location.hash = '#/step2-upload';
                }}
              >
                Continue
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}