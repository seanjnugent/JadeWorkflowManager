import { useState } from "react";
import { X, ChevronDown } from "lucide-react";
import svgPaths from "../imports/svg-lxv4opcm4j";

export function Data() {
  const [searchValue, setSearchValue] = useState("");
  const [sortBy, setSortBy] = useState("Most relevant");

  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchValue(e.target.value);
  };

  const clearSearch = () => {
    setSearchValue("");
  };

  const datasets = [
    {
      title: "Update existing resource & metadata",
      description: "Make changes to an existing dataset's resource and its associated metadata. This is useful for updating data files and metadata, and revising descriptions and tags.",
      organisation: "Scottish Government",
      format: "CSV",
      lastUpdated: "5/29/2025",
      href: "#/health-survey"
    },
    {
      title: "Add new resource & metadata",
      description: "Attach a new resource to an existing dataset and provide the relevant metadata. This helps enhance existing datasets with additional files or updated information.",
      organisation: "Data Platform",
      format: "CSV, JSON",
      lastUpdated: "6/10/2025",
      href: "#/health-survey"
    },
    {
      title: "Publish new dataset & resource & metadata",
      description: "Create and publish an entirely new dataset, complete with its initial resources and metadata. Use this workflow to introduce new data to the platform.",
      organisation: "Data Platform",
      format: "Various",
      lastUpdated: "6/8/2025",
      href: "#/health-survey"
    },
    {
      title: "Update metadata only",
      description: "Update the descriptive metadata for an existing dataset or resource. Useful for keeping titles, descriptions, tags, or classifications accurate and up to date.",
      organisation: "Scottish Government",
      format: "Metadata",
      lastUpdated: "6/12/2025",
      href: "#/health-survey"
    },
    {
      title: "Transform OLD load format to NEW format",
      description: "Convert data from the old structure to the new standardised format. Ensures consistency, compatibility, and usability for users.",
      organisation: "Data Platform",
      format: "Transform",
      lastUpdated: "6/5/2025",
      href: "#/health-survey"
    }
  ];

  return (
    <div className="min-h-screen bg-white">
      <div className="max-w-[1200px] mx-auto px-6 py-8">
        {/* Breadcrumb */}
        <nav className="mb-6">
          <div className="flex items-center gap-2 text-base">
            <a 
              href="#/" 
              className="text-[#0065bd] hover:text-[#004a9f] hover:no-underline underline cursor-pointer transition-colors duration-200"
            >
              Home
            </a>
            <span className="text-[#5e5e5e]">&gt;</span>
            <span className="text-[#333333]">Workflows</span>
          </div>
        </nav>

        <div className="flex gap-8">
          {/* Sidebar - 25% width */}
          <div className="w-1/4 shrink-0">
            {/* Page title */}
            <div className="mb-6">
              <h1 className="text-[44px] font-bold text-black leading-[50px] tracking-[0.15px] whitespace-nowrap">
                5 workflows available
              </h1>
            </div>

            {/* Search */}
            <div className="mb-6">
              <h2 className="text-[24px] font-bold text-black leading-[32px] tracking-[0.15px] mb-2">
                Search
              </h2>
              <div className="sg-data-search-container">
                <input
                  type="text"
                  placeholder="Search data..."
                  value={searchValue}
                  onChange={handleSearchChange}
                  className="sg-data-search-input"
                />
                {searchValue && (
                  <button
                    onClick={clearSearch}
                    className="absolute right-12 top-1/2 transform -translate-y-1/2 text-gray-500 hover:text-gray-700 p-1"
                    aria-label="Clear search"
                  >
                    <X className="w-4 h-4" />
                  </button>
                )}
                <button 
                  className="sg-data-search-button"
                  type="submit"
                  aria-label="Search datasets"
                >
                  <svg
                    className="w-6 h-6 text-white"
                    fill="none"
                    viewBox="0 0 48 48"
                  >
                    <path
                      d={svgPaths.p26efbc80}
                      fill="currentColor"
                    />
                  </svg>
                </button>
              </div>
            </div>

            {/* Filter by */}
            <div>
              <h2 className="text-[24px] font-bold text-black leading-[32px] tracking-[0.15px] mb-4">
                Filter by
              </h2>
              
              {/* Type filter */}
              <div className="sg-filter-item">
                <div className="sg-filter-content">
                  <span className="sg-filter-label">Type</span>
                  <ChevronDown className="sg-filter-chevron" />
                </div>
              </div>

              {/* Destination filter */}
              <div className="sg-filter-item">
                <div className="sg-filter-content">
                  <span className="sg-filter-label">Destination</span>
                  <ChevronDown className="sg-filter-chevron" />
                </div>
              </div>

              {/* Owner filter */}
              <div className="sg-filter-item">
                <div className="sg-filter-content">
                  <span className="sg-filter-label">Owner</span>
                  <ChevronDown className="sg-filter-chevron" />
                </div>
              </div>

              {/* Group filter */}
              <div className="sg-filter-item sg-filter-item-last">
                <div className="sg-filter-content">
                  <span className="sg-filter-label">Group</span>
                  <ChevronDown className="sg-filter-chevron" />
                </div>
              </div>

              {/* Clear filters button */}
              <button className="w-full h-12 bg-[#0065bd] text-white font-bold text-base mt-8">
                Clear filters
              </button>
            </div>
          </div>

          {/* Main content - 75% width */}
          <div className="w-3/4">
            {/* Sort by dropdown - positioned at top of content */}
            <div className="flex justify-end mb-6" style={{ marginTop: '46px' }}>
              <div className="flex items-center gap-2">
                <label className="text-base text-[#1a1a1a] tracking-[0.15px]">
                  Sort by:
                </label>
                <div className="relative">
                  <select 
                    value={sortBy} 
                    onChange={(e) => setSortBy(e.target.value)}
                    className="h-10 w-40 px-3 pr-10 bg-white border-2 border-black text-base appearance-none cursor-pointer"
                  >
                    <option>Most relevant</option>
                    <option>Newest first</option>
                    <option>Oldest first</option>
                    <option>A-Z</option>
                    <option>Z-A</option>
                  </select>
                  <div className="absolute right-0 top-0 w-10 h-10 bg-[#0065bd] flex items-center justify-center pointer-events-none">
                    <div className="w-4 h-4 transform rotate-[315deg]">
                      <div className="border-white border-[0px_0px_3px_3px] w-3 h-3"></div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Dataset tiles */}
            <div className="space-y-6">
              {datasets.map((dataset, index) => (
                <a 
                  key={index} 
                  href={dataset.href}
                  className="sg-dataset-tile block"
                >
                  <h3 className="sg-dataset-title">
                    {dataset.title}
                  </h3>
                  
                  <div className="flex items-center gap-4 text-[14px] text-[#5e5e5e] leading-[24px] tracking-[0.15px] mb-3">
                    <span>Organisation: {dataset.organisation}</span>
                    <span>Format: {dataset.format}</span>
                    <span>Last updated: {dataset.lastUpdated}</span>
                  </div>

                  <p className="sg-dataset-description">
                    {dataset.description}
                  </p>
                </a>
              ))}
            </div>

            {/* Pagination */}
            <div className="flex justify-center pt-6">
              <div className="w-10 h-10 bg-[#f8f8f8] border-b-2 border-black flex items-center justify-center">
                <span className="text-base text-black cursor-pointer">1</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}