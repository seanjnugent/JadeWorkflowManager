import svgPaths from "../imports/svg-tmym2azjca";

export function Footer() {
  return (
    <footer className="sg-footer">
      <div className="sg-footer-container">
        {/* Footer links */}
        <div className="sg-footer-links">
          <a href="/privacy" className="sg-footer-link">Privacy</a>
          <a href="/accessibility" className="sg-footer-link">Accessibility statement</a>
          <a href="#/contact" className="sg-footer-link">Contact</a>
          <a href="#/help" className="sg-footer-link">How to use this site</a>
        </div>

        {/* Single row footer content */}
        <div className="sg-footer-content">
          <div></div> {/* Empty space to push content right */}
          
          <div className="flex items-center gap-4">
            <span className="sg-footer-text">© Crown Copyright</span>
            
            <a href="https://www.gov.scot/" className="flex items-center cursor-pointer">
              <div className="w-40 h-8 relative">
                <svg
                  className="block w-full h-full"
                  fill="none"
                  preserveAspectRatio="none"
                  viewBox="0 0 160 31"
                >
                  <g clipPath="url(#clip0_1_235)">
                    <path
                      d={svgPaths.p2a6a7000}
                      fill="#333E48"
                    />
                    <path
                      d={svgPaths.p19ce0400}
                      fill="white"
                    />
                    <path
                      d={svgPaths.pa664b00}
                      fill="#0065BD"
                    />
                  </g>
                  <defs>
                    <clipPath id="clip0_1_235">
                      <rect fill="white" height="30.3939" width="160" />
                    </clipPath>
                  </defs>
                </svg>
              </div>
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
}