import { useState, useEffect } from "react";
import { ArrowRight, ArrowLeft } from "lucide-react";

export function Step6QualityChecks() {
  const [activeSection, setActiveSection] = useState<string>('view-on-data-gov-scot'); // Start with first section as default

  const handleJumpLinkClick = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      // Calculate offset to align section header with Contents title
      // Sticky nav top (24px) + Contents title height + some spacing = ~45px offset
      const offset = 45;
      const elementPosition = element.getBoundingClientRect().top + window.pageYOffset - offset;
      
      window.scrollTo({
        top: elementPosition,
        behavior: 'smooth'
      });
    }
  };

  // Scroll spy functionality
  useEffect(() => {
    const sections = [
      'view-on-data-gov-scot',
      'notify',
      'save-for-later'
    ];

    const observerOptions = {
      root: null,
      rootMargin: '-45px 0px -60% 0px', // Adjusted to account for our offset
      threshold: 0
    };

    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          setActiveSection(entry.target.id);
        }
      });
    }, observerOptions);

    // Observe all sections
    sections.forEach((sectionId) => {
      const element = document.getElementById(sectionId);
      if (element) {
        observer.observe(element);
      }
    });

    // Handle scroll to top - ensure first section is highlighted when at top
    const handleScroll = () => {
      const scrollPosition = window.pageYOffset || document.documentElement.scrollTop;
      
      // If we're at the top of the page (within 100px), highlight the first section
      if (scrollPosition < 100) {
        setActiveSection('view-on-data-gov-scot');
      }
    };

    // Add scroll listener
    window.addEventListener('scroll', handleScroll);
    
    // Check initial scroll position
    handleScroll();

    return () => {
      sections.forEach((sectionId) => {
        const element = document.getElementById(sectionId);
        if (element) {
          observer.unobserve(element);
        }
      });
      window.removeEventListener('scroll', handleScroll);
    };
  }, []);

  // Helper function to determine if a section is active
  const isActiveSection = (sectionId: string) => {
    return activeSection === sectionId;
  };

  return (
    <div className="min-h-screen bg-white">
      {/* Blue page header section with reduced bottom padding */}
      <div className="sg-page-header" style={{ paddingBottom: '24px' }}>
        <div className="sg-page-header-container">
          {/* Breadcrumb */}
          <nav className="sg-page-header-breadcrumb">
            <div className="flex items-center gap-2 text-base">
              <a 
                href="#/" 
                className="text-white hover:text-[#d9eeff] hover:no-underline underline cursor-pointer transition-colors duration-200"
              >
                Home
              </a>
              <span className="text-white">&gt;</span>
              <a 
                href="#/data" 
                className="text-white hover:text-[#d9eeff] hover:no-underline underline cursor-pointer transition-colors duration-200"
              >
                Workflows
              </a>
              <span className="text-white">&gt;</span>
              <a 
                href="#/health-survey" 
                className="text-white hover:text-[#d9eeff] hover:no-underline underline cursor-pointer transition-colors duration-200"
              >
                Update existing resource & metadata
              </a>
              <span className="text-white">&gt;</span>
              <span className="text-white">Step 6: Quality checks</span>
            </div>
          </nav>

          {/* Page title */}
          <h1 className="sg-page-header-title">
            Step 6: Quality checks
          </h1>

          {/* Progress indicator - spans full width */}
          <div className="w-full">
            <div className="sg-page-header-description" style={{ marginBottom: '10px' }}>
              <div className="relative">
                {/* Individual connectors between circles */}
                {/* Connector 1-2: Completed to Completed = White */}
                <div className="absolute top-4 h-1 bg-white rounded-full z-0" style={{ left: '32px', width: 'calc((100% - 64px) / 6)' }}></div>
                {/* Connector 2-3: Completed to Completed = White */}
                <div className="absolute top-4 h-1 bg-white rounded-full z-0" style={{ left: 'calc(32px + (100% - 64px) / 6)', width: 'calc((100% - 64px) / 6)' }}></div>
                {/* Connector 3-4: Completed to Completed = White */}
                <div className="absolute top-4 h-1 bg-white rounded-full z-0" style={{ left: 'calc(32px + 2 * (100% - 64px) / 6)', width: 'calc((100% - 64px) / 6)' }}></div>
                {/* Connector 4-5: Completed to Completed = White */}
                <div className="absolute top-4 h-1 bg-white rounded-full z-0" style={{ left: 'calc(32px + 3 * (100% - 64px) / 6)', width: 'calc((100% - 64px) / 6)' }}></div>
                {/* Connector 5-6: Completed to Current = White */}
                <div className="absolute top-4 h-1 bg-white rounded-full z-0" style={{ left: 'calc(32px + 4 * (100% - 64px) / 6)', width: 'calc((100% - 64px) / 6)' }}></div>
                {/* Connector 6-7: Current to Future = Grey */}
                <div className="absolute top-4 h-1 rounded-full z-0" style={{ left: 'calc(32px + 5 * (100% - 64px) / 6)', width: 'calc((100% - 64px) / 6)', background: 'rgba(227, 227, 227, 0.6)' }}></div>
                
                {/* Steps container */}
                <div className="relative flex justify-between items-center w-full z-10">
                  {/* Step 1: Name (Completed) - White with tick */}
                  <div className="flex flex-col items-center relative z-20">
                    <div className="w-8 h-8 rounded-full bg-white text-[var(--sg-blue-dark)] flex items-center justify-center font-bold text-sm mb-3 shadow-lg border-2 border-white">
                      ✓
                    </div>
                    <span className="text-white font-medium text-center text-sm">1. Name</span>
                  </div>
                  
                  {/* Step 2: Upload (Completed) - White with tick */}
                  <div className="flex flex-col items-center relative z-20">
                    <div className="w-8 h-8 rounded-full bg-white text-[var(--sg-blue-dark)] flex items-center justify-center font-bold text-sm mb-3 shadow-lg border-2 border-white">
                      ✓
                    </div>
                    <span className="text-white font-medium text-center text-sm">2. Upload</span>
                  </div>
                  
                  {/* Step 3: Preview (Completed) - White with tick */}
                  <div className="flex flex-col items-center relative z-20">
                    <div className="w-8 h-8 rounded-full bg-white text-[var(--sg-blue-dark)] flex items-center justify-center font-bold text-sm mb-3 shadow-lg border-2 border-white">
                      ✓
                    </div>
                    <span className="text-white font-medium text-center text-sm">3. Preview</span>
                  </div>
                  
                  {/* Step 4: Metadata (Completed) - White with tick */}
                  <div className="flex flex-col items-center relative z-20">
                    <div className="w-8 h-8 rounded-full bg-white text-[var(--sg-blue-dark)] flex items-center justify-center font-bold text-sm mb-3 shadow-lg border-2 border-white">
                      ✓
                    </div>
                    <span className="text-white font-medium text-center text-sm">4. Metadata</span>
                  </div>
                  
                  {/* Step 5: Summary (Completed) - White with tick */}
                  <div className="flex flex-col items-center relative z-20">
                    <div className="w-8 h-8 rounded-full bg-white text-[var(--sg-blue-dark)] flex items-center justify-center font-bold text-sm mb-3 shadow-lg border-2 border-white">
                      ✓
                    </div>
                    <span className="text-white font-medium text-center text-sm">5. Summary</span>
                  </div>
                  
                  {/* Step 6: Check (Current) - White with dot */}
                  <div className="flex flex-col items-center relative z-20">
                    <div className="w-8 h-8 rounded-full bg-white text-[var(--sg-blue-dark)] flex items-center justify-center font-bold text-sm mb-3 shadow-lg border-2 border-white">
                      <div className="w-3 h-3 rounded-full bg-[var(--sg-blue-dark)]"></div>
                    </div>
                    <span className="text-white font-medium text-center text-sm">6. Check</span>
                  </div>
                  
                  {/* Step 7: Finalise (Future) - Grey */}
                  <div className="flex flex-col items-center relative z-20">
                    <div className="w-8 h-8 rounded-full flex items-center justify-center font-bold text-sm mb-3" style={{ background: 'rgba(227, 227, 227, 0.6)', border: '2px solid rgba(227, 227, 227, 0.6)' }}>
                    </div>
                    <span className="text-center text-sm" style={{ color: 'rgba(227, 227, 227, 0.6)' }}>7. Finalise</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Hero tiles removed */}
        </div>
      </div>

      <div className="max-w-[1200px] mx-auto px-6 py-8">
        <div className="flex gap-8">
          {/* Sidebar - 25% width with sticky contents */}
          <div className="w-1/4 shrink-0">
            {/* Contents */}
            <div className="sg-contents-sticky">
              <h2 className="text-[24px] font-bold text-black leading-[32px] tracking-[0.15px] mb-4">
                Step summary
              </h2>
              
              <nav>
                <ul className="sg-contents-nav">
                  <li className="sg-contents-item">
                    <button
                      onClick={() => handleJumpLinkClick('view-on-data-gov-scot')}
                      className={`sg-contents-link w-full text-left ${isActiveSection('view-on-data-gov-scot') ? 'sg-contents-link-active' : ''}`}
                    >
                      View on data.gov.scot
                    </button>
                  </li>
                  <li className="sg-contents-item">
                    <button
                      onClick={() => handleJumpLinkClick('notify')}
                      className={`sg-contents-link w-full text-left ${isActiveSection('notify') ? 'sg-contents-link-active' : ''}`}
                    >
                      Notify
                    </button>
                  </li>
                  <li className="sg-contents-item">
                    <button
                      onClick={() => handleJumpLinkClick('save-for-later')}
                      className={`sg-contents-link w-full text-left ${isActiveSection('save-for-later') ? 'sg-contents-link-active' : ''}`}
                    >
                      Save for later
                    </button>
                  </li>
                </ul>
              </nav>
            </div>
          </div>

          {/* Main content - 75% width */}
          <div className="w-3/4">
            {/* View on data.gov.scot Section */}
            <section id="view-on-data-gov-scot" className="mb-12 pt-6">
              <div className="sg-section-separator">
                <h2 className="text-[24px] font-bold text-black leading-[32px] tracking-[0.15px] mb-2">
                  View on data.gov.scot
                </h2>
              </div>
              <div className="prose prose-lg max-w-none">
                {/* Empty as requested */}
              </div>
            </section>

            {/* Notify Section */}
            <section id="notify" className="mb-12 pt-6">
              <div className="sg-section-separator">
                <h2 className="text-[24px] font-bold text-black leading-[32px] tracking-[0.15px] mb-2">
                  Notify
                </h2>
              </div>
              <div className="prose prose-lg max-w-none">
                {/* Empty as requested */}
              </div>
            </section>

            {/* Save for later Section */}
            <section id="save-for-later" className="mb-12 pt-6">
              <div className="sg-section-separator">
                <h2 className="text-[24px] font-bold text-black leading-[32px] tracking-[0.15px] mb-2">
                  Save for later
                </h2>
              </div>
              <div className="prose prose-lg max-w-none">
                {/* Empty as requested */}
              </div>
            </section>

            {/* Back and Continue buttons - right aligned */}
            <div className="flex justify-end gap-4 pt-6">
              <button
                type="button"
                className="px-8 py-3 gap-2 border-2 border-[#5e5e5e] bg-white text-[#5e5e5e] hover:bg-[#f8f8f8] transition-colors duration-200 font-medium rounded-[4px] flex items-center"
                onClick={() => {
                  window.location.hash = '#/step5-summary';
                }}
              >
                <ArrowLeft className="w-4 h-4" />
                Back
              </button>
              <button
                type="button"
                className="sg-data-action-button px-8 py-3 gap-2"
                onClick={() => {
                  window.location.hash = '#/step7-finalise';
                }}
              >
                Continue
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}