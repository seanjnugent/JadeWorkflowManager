export function Hero() {
  return (
    <section className="sg-hero">
      <div className="sg-hero-container">
        <h1 className="sg-hero-title-homepage">
          Hi Alex,
        </h1>
        
        <div className="sg-hero-description">
          <p className="mb-0" style={{ maxWidth: '650px' }}>
            Welcome to the Workflow Manager platform - providing access to tools for creating, monitoring, and managing your workflows and runs.
          </p>
        </div>
      </div>
    </section>
  );
}